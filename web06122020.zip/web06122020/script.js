/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
// set to the size of device
var canvas, ctx, center_x, center_y, radius, bars,
        x_end, y_end, bar_height, bar_width,
        frequency_array;
bars = 200;
bar_width = 2;
function initPage() {
    audio = new Audio();
    context = new (window.AudioContext || window.webkitAudioContext)();
    analyser = context.createAnalyser();
    audio.src = "05 Interlude.mp3"; // the source path
    source = context.createMediaElementSource(audio);
    source.connect(analyser);
    analyser.connect(context.destination);
    frequency_array = new Uint8Array(analyser.frequencyBinCount);
    audio.play();
    animationLooper();
}
function updateVideoViz() {
    var v = document.getElementById('v');
    canvas = document.getElementById('renderer');
    var context = canvas.getContext('2d');
    back = document.getElementById('b');
    var backcontext = back.getContext('2d');

    var cw, ch;

    cw = v.clientWidth;
    ch = v.clientHeight;
    canvas.width = cw;
    canvas.height = ch;
    back.width = cw;
    back.height = ch;

    draw(v, context, backcontext, cw, ch);
}
function draw(v, c, bc, w, h) {
    if (v.paused || v.ended)
        return false;
    // First, draw it into the backing canvas
    ////bc.drawImage(v, 0, 0, w, h);
    // Grab the pixel data from the backing canvas
    var idata = bc.getImageData(0, 0, w, h);
    var data = idata.data;
    // Loop through the pixels, turning them grayscale
    for (var i = 0; i < data.length; i += 4) {
        var r = data[i];
        var g = data[i + 1];
        var b = data[i + 2];
        var brightness = (3 * r + 4 * g + b) >>> 3;
        data[i] = brightness;
        data[i + 1] = brightness;
        data[i + 2] = brightness;
    }
    idata.data = data;
    // Draw the pixels onto the visible canvas
    c.putImageData(idata, 0, 0);
    // Start over!

    //setTimeout(draw, 20, v, c, bc, w, h);
}
function animationLooper() {
    var clstrArray = getClstrArray();
    //alert("length = "+clstrArray.length);
    //if(clstrArray.length > 0){
    //   alert("animationLooper(): x = "+clstrArray[0].x);        
    //   center_x = clstrArray[0].x;
    //   center_y = clstrArray[0].y;
    //}
    // set to the size of device
    canvas = document.getElementById("renderer");
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    ctx = canvas.getContext("2d");
    // find the center of the window

    var back = document.getElementById('c');
    var bc = back.getContext('2d');
    //var idata = bc.getImageData(0, 0, canvas.width, canvas.height);
    //ctx.putImageData(idata, 0, 0,0,0,canvas.width,canvas.height);    
    ctx.drawImage(back, 0, 0,canvas.width,canvas.height);    
    
    radius = 25;
    //style the background
    //var gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    //gradient.addColorStop(0, "rgba(35, 7, 77, 1)");
    //gradient.addColorStop(1, "rgba(204, 83, 51, 1)");
    //ctx.fillStyle = gradient;
    //ctx.fillRect(0, 0, canvas.width, canvas.height);

    var aLength = clstrArray.length;
    for (var i = 0; i < aLength; i++) {
        center_x = clstrArray[i].x * rtrveWdthScleFctr();
        center_y = clstrArray[i].y * rtrveHghtScleFctr();
        radius = clstrArray[i].radius;
        animateCircles(ctx, center_x, center_y, radius);
    }
    center_x = canvas.width / 2;
    center_y = canvas.height / 2;



    animateCircles(ctx, center_x, center_y, radius);

    window.requestAnimationFrame(animationLooper);
}
function animateCircles(ctx, center_x, center_y, radius) {
//draw a circle
    ctx.beginPath();
    ctx.arc(center_x, center_y, radius, 0, 2 * Math.PI);
    ctx.stroke();
    analyser.getByteFrequencyData(frequency_array);
    for (var i = 0; i < bars; i++) {
//divide a circle into equal parts
        rads = Math.PI * 2 / bars;
        //bar_height = frequency_array[i] * 0.7;
        bar_height = frequency_array[i] * radius / 800;
// set coordinates
        x = center_x + Math.cos(rads * i) * (radius);
        y = center_y + Math.sin(rads * i) * (radius);
        x_end = center_x + Math.cos(rads * i) * (radius + bar_height);
        y_end = center_y + Math.sin(rads * i) * (radius + bar_height);
//draw a bar
        drawBar(x, y, x_end, y_end, bar_width, frequency_array[i]);
    }
}
// for drawing a bar
function drawBar(x1, y1, x2, y2, width, frequency) {
    var lineColor = "rgb(" + frequency + ", " + frequency + ", " + 205 + ")";
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = width;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
}

