/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var video = document.getElementById("videoelementid");

navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia || navigator.oGetUserMedia;

if (navigator.getUserMedia) {
    navigator.getUserMedia({video: true}, handleVideo, videoError);
}

function handleVideo(stream) {
    video.src = window.URL.createObjectURL(stream);
}

function videoError(e) {
    // do somethi`ng
}
var v, canvas, context, w, h;
var imgtag = document.getElementById('imgtag');
//var sel = document.getElementById('fileselect');

document.addEventListener('DOMContentLoaded', function () {
    v = document.getElementById('videoelementid');
    canvas = document.getElementById('canvasid1');
    context = canvas.getContext('2d');
    w = canvas.width;
    h = canvas.height;

}, false);


document.getElementById('capture').addEventListener('click', function (e) {
    draw(v, context, w, h);
    hideCamera();
});
function displayCamera() {
    var vcontainer = document.getElementById('vcontainerid');
    vcontainer.style.display = 'block';
}
function hideCamera() {
    //var vcontainer = document.getElementById('vcontainerid');
    //vcontainer.style.display = 'none';
}


