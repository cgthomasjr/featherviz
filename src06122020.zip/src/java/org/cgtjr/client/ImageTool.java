package org.cgtjr.client;



import com.google.gwt.user.client.ui.Image;

class ImageTool
{
   private  String fileName;
   private  int imageHeight;
   private  int imageWidth;
   private  int imagePixels[];
   private  Image image;

   ImageTool(String myFileName)
   {

   }
   int[] getImagePixels()
   {
      return imagePixels;
   }
   int getImageHeight()
   {
      return imageHeight;
   }
   int getImageWidth()
   {
      return imageWidth;
   }
   static int[][] rtrv2DPxls(Image myInputImage)
   {
      int imageWidth = 0;
      int imageHeight = 0;
      Image inputImage = myInputImage;
      int oneDPixels[] = null;
      int twoDPixels[][] = null;
      if(inputImage != null)
      {  
         while(imageWidth < 1 || imageHeight < 1)
         {
            imageWidth = inputImage.getWidth();  
            imageHeight = inputImage.getHeight();
         }
         oneDPixels = new int[imageWidth*imageHeight];
         twoDPixels = new int[imageWidth][imageHeight];

      }
      int oneDPixelTmp[] = rmvLeadBits(oneDPixels);
      twoDPixels = ArrayTool.retrieveTwoDArray(oneDPixelTmp,imageWidth,imageHeight);
      return twoDPixels;
   }

   static int[] rtrv1DPxls(String myFileName)
   {
      Image inputImage = null;
      int oneDPixels[] = null;
      int imageWidth;
      int imageHeight;

      String value = null;      

      if(value != null  )
      {
         myFileName = "file:"+myFileName;
      }else{
         myFileName = "ThemeSet.getDocumentBase()"+myFileName;
      }
      String baseImageDirPath = value;

      inputImage = UgotImage.createImage(myFileName);
      if(inputImage == null)
      {  
         System.err.println("ImageTool : file read error!");
         return null;
      }
      imageWidth = inputImage.getWidth();
      imageHeight = inputImage.getHeight();
      while(imageWidth < 1 || imageHeight < 1)
      {
         imageWidth = inputImage.getWidth();  
         imageHeight = inputImage.getHeight();
      }
      oneDPixels = new int[imageWidth*imageHeight];
      return oneDPixels;
   }
   static int[] rtrv1DPxls(Image myInputImage)
   {
      int imageWidth = 0;
      int imageHeight = 0;
      Image inputImage = myInputImage;
      int oneDPixels[] = null;

      if(inputImage != null)
      {  
         while(imageWidth < 1 || imageHeight < 1)
         {
            imageWidth = inputImage.getWidth();  
            imageHeight = inputImage.getHeight();
         }
         oneDPixels = new int[imageWidth*imageHeight];
      }      
      return oneDPixels;
   }
   static int[] rtrv1DPxls(Image myInputImage,int pixelData[])
   {
      int imageWidth = 0;
      int imageHeight = 0;
      Image inputImage = myInputImage;

      if(inputImage != null)
      {  
         while(imageWidth < 1 || imageHeight < 1)
         {
            imageWidth = inputImage.getWidth();  
            imageHeight = inputImage.getHeight();
         }
      }
      
      return pixelData;
   }
   static Image rtrvImage(int myPixelData[][])
   {
      int imageHeight = myPixelData.length;
      int imageWidth = myPixelData[0].length;
      int oneDArray[] = ArrayTool.retrieveOneDArray(myPixelData);
      Image outputImage = null;//(BufferedImage)UgotImage.createRGBImage(oneDArray,imageWidth,imageHeight,true);
      return outputImage;
   }
   static Image rtrvImage(int myPixelData[],int myWidth,int myHeight)
   {
      int imageHeight = myHeight;
      int imageWidth = myWidth;
      Image outputImage = null;//(Image)UgotImage.createRGBImage(myPixelData,imageWidth,imageHeight,true);
      return outputImage;
   }   
   static int[] rmvLeadBits(int myData[])
   {
      int myLength = myData.length;
      int aData[] = new int[myLength];
      for(int i=0;i<myLength;i++)
      {
         aData[i] = myData[i] & 0x00ffffff;
         //System.out.println("Filter.rmvLeadBits befoer:"+myData[i]+" , after:"+aData[i]);
      }
      return aData;
   }
   static int[] rmvLeadBits(double myData[])
   {
      int myLength = myData.length;
      int aData[] = new int[myLength];
      for(int i=0;i<myLength;i++)
      {
         aData[i] = ((int)myData[i]) & 0x00ffffff;
      }
      return aData;
   }
   static void wrtImageFile(int myData[],int myWidth,int myHeight)
   {
      wrtImageFile(myData,myWidth,myHeight,"newimage.jpg");
   }
   static void wrtImageFile(int myData[],int myWidth,int myHeight,String myFileName)
   {
      Image outputImage = (Image)UgotImage.createRGBImage(myData,myWidth,myHeight,true);
   }
   static Image wrtImageFile(String myFileName,int myPixelData[][])
   {
      int imageWidth = myPixelData[0].length;
      int imageHeight = myPixelData.length;
      int myPixelData1D[] = ArrayTool.retrieveOneDArray(myPixelData);
      return null;//wrtImageFile(myFileName,myPixelData1D,imageWidth,imageHeight);
   }
   /**
    * @deprecated 
    * @param myFileName
    * @param myPixelData
    * @param myWidth
    * @param myHeight
    * @return 
    */
   static Image wrtImage_File(String myFileName,int  myPixelData[],int myWidth,int myHeight)
   {
      return null;//outputImage;
   }   
   /**
    * @deprecated 
    * @param myFileName
    * @param myImage 
    */
   static void wrtImage_File(String myFileName,Image myImage)
   {
   }
   /**
    * @deprecated 
    * @param myFilename
    * @param myData 
    */
   static void wrtData_File(String myFilename,String myData)
   {
      
   } 
   /**
    * @deprecated 
    * @param fileName
    * @return 
    */
   static Image rdImage_File(String fileName)
   {
      return null;//
   }
   /**
    * @deprecated 
    * @param fileName
    * @return 
    */
   static Image rdImage_URL(String fileName)
   {
      return null;
   }
   static int[][] getTwoDImage(String fileName)
   {
      int rgbColors[] = null;
      int imageWidth = 0;
      int imageHeight = 0;
      int transparency = 0;
      int red = 0;
      int green = 0;
      int blue = 0;
      int imageLength = 0;
      int xCoordinate = 0;
      int yCoordinate = 0;
      int zCoordinate = 0;
      int imageHeightTmp = 0;
      
      Image inputImage = UgotImage.createImage(fileName);
      if(inputImage != null)
      {
         while(imageWidth < 1 || imageHeight < 1)
         {
            imageWidth = inputImage.getWidth();  
            imageHeight = inputImage.getHeight();
         }
         rgbColors = new int[imageWidth*imageHeight];
         imageLength = imageWidth * imageHeight;
         //UgotImage.handlepixels(inputImage,0,0,imageWidth,imageHeight,rgbColors);                   
      }
      return getTwoDImage(rgbColors,imageWidth,imageHeight);
   }
   static int[][] getTwoDImage(int aOneDImage[],int anImageWidth,int anImageHeight)
   {  
      int widthIndex  = 0;
      int heightIndex = 0;
      int myImageLength = anImageWidth * anImageHeight;
      int myTwoDImage[][] = new int[anImageHeight][anImageWidth];      

      for(int lengthIndex=0;lengthIndex<myImageLength;lengthIndex++)
      {                            
         myTwoDImage[heightIndex][widthIndex] = aOneDImage[lengthIndex];
         widthIndex++;
         heightIndex = lengthIndex / anImageWidth;
         if( (widthIndex % anImageWidth) == 0)
         {
            widthIndex = 0;
         }
      }
      return myTwoDImage;
   }
   void updtImgPixel(int myX,int myY,int myColor)
   {
      int myIndex = rtrvImgIndx(myX,myY);
      updtImgPixel(myIndex,myColor,imagePixels);
   }
   static void updtImgPixel(int myIndex,int myColor,int myPixels[])
   {
      myPixels[myIndex] = myColor;
   }
   int rtrvImgIndx(int myX,int myY)
   {
      int aWidth = getImageWidth();
      int anIndex = myY*aWidth+myX;
      return anIndex;
   }
   static int rtrvPixel(int myData[],int myWidth,int myLength,int myX,int myY)
   {
       int anIndex = rtrvIndex(myX,myY,myWidth);
       int data = myData[anIndex];
       return data;
   }
   static int rtrvIndex(int myX,int myY,int myWidth)
   {
      int aWidth = myWidth;
      int anIndex = myY*aWidth+myX;
      return anIndex;
   }
   static int rtrvIndex(int myX,int myY,int myWidth,int myHeight)
   {
      
      int aWidth = myWidth;
      int anIndex = myY*aWidth+myX;
      return anIndex;
   }   
   static int rtrvXPstn(int myIndex,int myImageWidth)
   {
      int x = myIndex % myImageWidth;
      return x;
   }
   static int rtrvYPstn(int myIndex,int myImageWidth)
   {      
      int y = myIndex / myImageWidth;
      return y;
   }
   int getXPstn(int myIndex)
   {
      int x = myIndex % getImageWidth();
      return x;
   }
   int getYPstn(int myIndex)
   {
      int y = myIndex / getImageWidth();
      return y;
   }
}