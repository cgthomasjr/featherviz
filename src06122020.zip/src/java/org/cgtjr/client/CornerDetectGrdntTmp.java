package org.cgtjr.client;

/**
 * The function CornerDetectGrdntTmp computes the corner features associated 
 * with gradient values.  The corner matrix is only a dimension of 2x2, a 
 * direct solution is obtain with the conversion to algebraic equation form; 
 * these functions provide less computational complexity. This formulation also 
 * solves the associated eigenvalues. 
 * @author cgthomasjr
 */
public class CornerDetectGrdntTmp  {

    private int gradientXSqrd;
    private int gradientYSqrd;
    private int gradientXY;

    private int cornerDataPixel[];

    private int threshold = 800;
    private int neighborHood[][];

    private double cornerMtrx[][];

    private boolean isCornerRegion[];
    private int cornerRegionIndx[];
    private int originalData[];
    private boolean checkRegion = true;
    private int cornerIndex[];
    private int cornerCount;
    private double maxEigenValue[];
    private double lclMaxEgnVls[];
    private int lclMaxIndex[];
    private int lclWndwDmnsn;
    private int fltrDmnsn;
    private int glblWndwWidth;
    private int glblWndwHeight;
    private double eigenValue1[];
    private double eigenValue2[];
    private double answerTmp2[];

    private boolean displayCorners = false;
    private int aLength;
    private TmprlGrdntFltrTmp tmprlGrdntFltrTmp;
    private YSclFltrTmp ySclFltrTmp;
    private GrdntFilterParserTmp grdntFilterParser;
    
    public CornerDetectGrdntTmp(YSclFltrTmp myYSclFltrTmp,TmprlGrdntFltrTmp myTmprlGrdntFltrTmp,GrdntFilterParserTmp myGrdntFilterParserTmp){
        ySclFltrTmp = myYSclFltrTmp;
        tmprlGrdntFltrTmp = myTmprlGrdntFltrTmp;
        grdntFilterParser = myGrdntFilterParserTmp;
    }
    public void initialize(int myImageWidth, int myImageHeight) {
        aLength = myImageHeight * myImageWidth;
        isCornerRegion = new boolean[aLength];            
        if(maxEigenValue == null){
          maxEigenValue = new double[aLength];            
        }        
        cornerCount = 0;
        lclWndwDmnsn = 9;
        fltrDmnsn = 3;
        glblWndwWidth = myImageWidth / lclWndwDmnsn;
        glblWndwHeight = myImageHeight / lclWndwDmnsn;
    }

    public boolean getDisplayCorners() {
        return displayCorners;
    }

    public void setDisplayCorners(boolean myDisplayCorners) {
        this.displayCorners = myDisplayCorners;
    }

    public int getLclWndwDmnsn() {
        return lclWndwDmnsn;
    }

    public int getGlblWndwWidth() {
        return glblWndwWidth;
    }

    public void setEigenThreshold(int myThreshold) {
        threshold = myThreshold;
    }

    public int getEigenThreshold() {
        return threshold;
    }

    public int[] getCornerData() {
        return cornerDataPixel;
    }

    public void setCornerData(int myPixelData[]) {
        cornerDataPixel = myPixelData;
    }

    public int getCornerRegionIndx(int myIndex1) {
        return cornerRegionIndx[myIndex1];
    }
    public int getCornerCount() {
        return cornerCount;
    }
    public void setCornerRegion(int i) {
        setCornerRegion(i, true);
    }
    public void filter(int myGrayValues[]) {
       int aLength = myGrayValues.length;
       for(int i=0;i<aLength;i++){
           filter(myGrayValues,i);
       }
    }
    public void filter(int myGrayValues[], int i) {
        cornerDetect(myGrayValues, i);
    }
    public void cornerDetect(int myPixelValues[], int i) {
        if (tmprlGrdntFltrTmp.getTemporalGradientValues(i) > tmprlGrdntFltrTmp.getTmprlGrdntThrshld()) {
            cornerMtrx = createCornerMatrix(i);
            solveEigenValues(cornerMtrx, i);
        }
    }
    private double[][] createCornerMatrix(int j) {
        double cornerMatrix[][] = new double[2][2];
        int imageWidth = ySclFltrTmp.getImageWidth();
        int imageHeight = ySclFltrTmp.getImageHeight();
        int aGradientHor[] = grdntFilterParser.getGrdntHrzntl();
        int aGradientVer[] = grdntFilterParser.getGrdntVrtcl();
         try{
           gradientXSqrd =
                    aGradientHor[j - imageWidth - 1] * aGradientHor[j - imageWidth - 1]
                    + aGradientHor[j - imageWidth] * aGradientHor[j - imageWidth]
                    + aGradientHor[j - imageWidth + 1] * aGradientHor[j - imageWidth + 1]
                    + aGradientHor[j - 1] * aGradientHor[j - 1]
                    + aGradientHor[j] * aGradientHor[j]
                    + aGradientHor[j + 1] * aGradientHor[j + 1]
                    + aGradientHor[j + imageWidth - 1] * aGradientHor[j + imageWidth - 1]
                    + aGradientHor[j + imageWidth] * aGradientHor[j + imageWidth]
                    + aGradientHor[j + imageWidth + 1] * aGradientHor[j + imageWidth + 1];

            gradientYSqrd =
                    aGradientVer[j - imageWidth - 1] * aGradientVer[j - imageWidth - 1]
                    + aGradientVer[j - imageWidth] * aGradientVer[j - imageWidth]
                    + aGradientVer[j - imageWidth + 1] * aGradientVer[j - imageWidth + 1]
                    + aGradientVer[j - 1] * aGradientVer[j - 1]
                    + aGradientVer[j] * aGradientVer[j]
                    + aGradientVer[j + 1] * aGradientVer[j + 1]
                    + aGradientVer[j + imageWidth - 1] * aGradientVer[j + imageWidth - 1]
                    + aGradientVer[j + imageWidth] * aGradientVer[j + imageWidth]
                    + aGradientVer[j + imageWidth + 1] * aGradientVer[j + imageWidth + 1];

            cornerMatrix[0][0] = gradientXSqrd;
            cornerMatrix[1][1] = gradientYSqrd;
         }catch(ArrayIndexOutOfBoundsException aiobe){
             
         }

        return cornerMatrix;
    }
    public void solveEigenValues(double myCrnrMtrx[][], int i) {
        double answer[] = solveEigenValues(myCrnrMtrx);

        double maxAnswer[] =  arrngeMaxValue(answer);

        if (maxAnswer[1] >= threshold && !isInCornerRegion3x3(i)) {
            maxEigenValue[i] = maxAnswer[1];
            updtCornerPixels(i);
            setCornerRegion(i);            
            cornerCount++;
        }else{
            maxEigenValue[i] = 0;
        }
        
    }

    public void setCheckRegion(boolean myCheckRegion) {
        checkRegion = myCheckRegion;
    }

    public int getCornerIndex(int myIndex) {
        return cornerIndex[myIndex];
    }

    public void setEigenValue(int myIndex, double myValue) {
        maxEigenValue[myIndex] = myValue;
    }

    public double getEigenValue(int myIndex) {
        return maxEigenValue[myIndex];
    }
    public double[] getEigenValue() {
        return maxEigenValue;
    }    
    
    public double getEigenValue1(int myIndex) {
        return eigenValue1[myIndex];
    }

    public double getEigenValue2(int myIndex) {
        return eigenValue2[myIndex];
    }

    private void setCornerRegion(int i, boolean myTorF) {
        try{
            int imageWidth = ySclFltrTmp.getImageWidth();
            isCornerRegion[i - imageWidth - 1] = myTorF;
            isCornerRegion[i - imageWidth] = myTorF;
            isCornerRegion[i - imageWidth + 1] = myTorF;
            isCornerRegion[i - 1] = myTorF;
            //isCornerRegion[i] = myTorF;
            isCornerRegion[i + 1] = myTorF;
            isCornerRegion[i + imageWidth - 1] = myTorF;
            isCornerRegion[i + imageWidth] = myTorF;
            isCornerRegion[i + imageWidth + 1] = myTorF;
        }catch(ArrayIndexOutOfBoundsException aiobe){
            
        }
    }

    private boolean isInCornerRegion(int myIndex1) {
        boolean inBounds = false;
        if (isCornerRegion[myIndex1] == true) {
            inBounds = true;;
        }
        return inBounds;
    }
    private boolean isInCornerRegion3x3(int myIndex){
        int imageWidth = ySclFltrTmp.getImageWidth();
        boolean isInRegion = isInCornerRegion(myIndex - imageWidth - 1)||
            isInCornerRegion(myIndex- imageWidth)||
            isInCornerRegion(myIndex - 1)||
            isInCornerRegion(myIndex)||
            isInCornerRegion(myIndex + 1)||
            isInCornerRegion(myIndex + imageWidth - 1)||
            isInCornerRegion(myIndex + imageWidth)||
            isInCornerRegion(myIndex + imageWidth + 1);
        return isInRegion;        
    }
    private double[] solveEigenValues(double aCornerMatrix[][]) {
        double answer[] = new double[2];
        double answerTmp1 = 0.0;
        double answerTmp2 = 0.0;
        int secOrdPart = 1;
        double firstOrdPart = -1 * (aCornerMatrix[0][0] + aCornerMatrix[1][1]);
        double constPart = aCornerMatrix[0][0] * aCornerMatrix[1][1] - aCornerMatrix[0][1] * aCornerMatrix[1][0];
        double sqrtPart = Math.sqrt(firstOrdPart * firstOrdPart - 4 * secOrdPart * constPart);
        answerTmp1 = (-1 * firstOrdPart + sqrtPart) / (2 * secOrdPart);
        answerTmp2 = (-1 * firstOrdPart - sqrtPart) / (2 * secOrdPart);
        answer[0] = answerTmp1;
        answer[1] = answerTmp2;
        return answer;
    }

    private double[] arrngeMaxValue(double myValue[]) {
        double answer[] = new double[2];

        if (myValue[0] >= myValue[1]) {
            answer[0] = myValue[0];
            answer[1] = myValue[1];
        } else {
            answer[0] = myValue[1];
            answer[1] = myValue[0];
        }
        return answer;
    }
    private void updtCornerPixels(int i) {
        updtCornerPixels(cornerDataPixel, i);
    }
    private void updtCornerPixels(int cornerDataPixel[], int i) {
        updtCornerPixels(cornerDataPixel,i,0x0000cc00);
    }
    private void updtCornerPixels(int cornerDataPixel[], int i,int aColor) {
        int imageWidth = ySclFltrTmp.getImageWidth();
        try{
            ySclFltrTmp.getImageDrawData().drawData(0x0000aa00, i - imageWidth - 1);
            ySclFltrTmp.getImageDrawData().drawData(0x0000aa00, i - imageWidth);
            ySclFltrTmp.getImageDrawData().drawData(0x0000aa00, i - imageWidth + 1);
            ySclFltrTmp.getImageDrawData().drawData(0x0000aa00, i - 1);
            ySclFltrTmp.getImageDrawData().drawData(0x0000aa00, i);
            ySclFltrTmp.getImageDrawData().drawData(0x0000aa00, i + 1);
            ySclFltrTmp.getImageDrawData().drawData(0x0000aa00, i + imageWidth - 1);
            ySclFltrTmp.getImageDrawData().drawData(0x0000aa00, i + imageWidth);
            ySclFltrTmp.getImageDrawData().drawData(0x0000aa00, i + imageWidth + 1);
        }catch(ArrayIndexOutOfBoundsException aiobe){
            
        }
    }
    private int getLclMaxIndex(int myIndex) {
        return lclMaxIndex[myIndex];
    }
    private double getLclMaxEgnVls(int myIndex) {
        return lclMaxEgnVls[myIndex];
    }
    public TmprlGrdntFltrTmp getTmprlGrdntFltrTmp() {
        return tmprlGrdntFltrTmp;
    }
    public void setTmprlGrdntFltrTmp(TmprlGrdntFltrTmp myTmprlGrdntFltrTmp) {
        this.tmprlGrdntFltrTmp = myTmprlGrdntFltrTmp;
    }

    public YSclFltrTmp getySclFltrTmp() {
        return ySclFltrTmp;
    }

    public void setySclFltrTmp(YSclFltrTmp myYSclFltrTmp) {
        this.ySclFltrTmp = myYSclFltrTmp;
    }

    public GrdntFilterParserTmp getGrdntFilterParser() {
        return grdntFilterParser;
    }

    public void setGrdntFilterParser(GrdntFilterParserTmp myGrdntFilterParser) {
        this.grdntFilterParser = myGrdntFilterParser;
    }
}