package org.cgtjr.client;

/**
 *
 * @author cgthomasjr
 */
class VIPrcssrImgDtaJS {

    native static void loadVdoJS()/*-{   
            var v = $doc.getElementById('v');
            if(v !== undefined && v !== null){
                v.addEventListener('play', function () {
                    @org.cgtjr.client.VIPrcssrImgDta::startPrcssing()();
                }, false);            
            }else{
                //$wnd.alert("loadVdoJS()... id = v is not defined!");
            }
    }-*/;

    native void crteJSCluster(ClusterHOGTrackerTmp myClusterHOGTrackerTmp) /*-{
       function JSPnt() {var x=0;var y=0;var z=0;var radius=0;var width=0;var height=0;}
       function updateBndryData(){
          var i = 0;
          var elmnts = new Array();
          var aLength = myClusterHOGTrackerTmp.@org.cgtjr.client.ClusterHOGTrackerTmp::rtrveRectBndryCnt()();
          for(i = 0;i<aLength;i++)
          {
            aJSPnt = new JSPnt(); 
            aJSPnt.x = myClusterHOGTrackerTmp.@org.cgtjr.client.ClusterHOGTrackerTmp::rtrveCntrX(I)(i);
            aJSPnt.y = myClusterHOGTrackerTmp.@org.cgtjr.client.ClusterHOGTrackerTmp::rtrveCntrY(I)(i);
            //aJSPnt.z = myClusterHOGTrackerTmp.@org.cgtjr.client.ClusterHOGTrackerTmp::rtrveCrdnteZ(I)(i);
            aJSPnt.width = myClusterHOGTrackerTmp.@org.cgtjr.client.ClusterHOGTrackerTmp::rtrveWidth(I)(i);
            aJSPnt.height = myClusterHOGTrackerTmp.@org.cgtjr.client.ClusterHOGTrackerTmp::rtrveHeight(I)(i);            
            aJSPnt.radius = myClusterHOGTrackerTmp.@org.cgtjr.client.ClusterHOGTrackerTmp::rtrveMaxLength(I)(i);            
            elmnts[i] = aJSPnt;
          }
          $doc.updateVizData(elmnts);
       }
       updateBndryData();               
    }-*/;
}