package org.cgtjr.client;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author clayton g thomas jr
 */
class RectBndryGlblHOGTree extends TreeSet {

    private int xMax;
    private int xMin;
    private int yMax;
    private int yMin;
    private int zMax;
    private int zMin;
    private int color;
    private int xSum;
    private int ySum;
    private int zSum;
    private int xAvg;
    private int yAvg;
    private int zAvg;
    private int boundaryID;
    private int maxTrackID = -1;
    private float maxMagnitude;
    private HashMap mathVectorMap;
    private HOGPosition cntrHOGPosition;
    private double globalHogDstnceThrshld = 80000000000.0;//Global HOG?
    private CentroidHGPstn centroidPos;
    private int imageWidth;
    private int imageHeight;
    private double trnsltnPhase;
    private double trnsltnMgntde;
    private double chrctrstcScale;
    private double rotationAngle;

    int getGlblTrnsltnDstnceThrshld() {
        return glblTrnsltnDstnceThrshld;
    }

    void setGlblTrnsltnDstnceThrshld(int myGlblTrnsltnDstnceThrshld) {
        this.glblTrnsltnDstnceThrshld = myGlblTrnsltnDstnceThrshld;
    }
    private double rotationAngleSum;
    private double distanceSum;
    private double scaleSum;
    private Kinematics kinematicData;
    private int minWidth = 4;
    private int minHeight = 4;
    private int glblTrnsltnDstnceThrshld = 50;
    private double xDistanceSum;
    private double yDistanceSum;
    
    RectBndryGlblHOGTree() {
        super();
        cntrHOGPosition = new HOGPosition();  
        centroidPos = new CentroidHGPstn();
        
        mathVectorMap = new HashMap();

        xMax = -Integer.MAX_VALUE;
        yMax = -Integer.MAX_VALUE;

        xMin = Integer.MAX_VALUE;
        yMin = Integer.MAX_VALUE;

        kinematicData = new Kinematics();
    }    
    RectBndryGlblHOGTree(HOGPosition myHOGPosition) {
        super(new YBndryComparator());
        mathVectorMap = new HashMap();
        cntrHOGPosition = new HOGPosition();        
        centroidPos = new CentroidHGPstn();
        xMax = -Integer.MAX_VALUE;
        yMax = -Integer.MAX_VALUE;

        xMin = Integer.MAX_VALUE;
        yMin = Integer.MAX_VALUE;

        setXAvg((int) myHOGPosition.getX());//This may need updating
        setYAvg((int) myHOGPosition.getY());//This may need updating
        centroidPos.updateCentroid(myHOGPosition);
        
        //System.err.println("RectBndryHOGArrayList : possible error"); 
        HistogramOG ah[][] = myHOGPosition.getHog();
        System.out.println("RectBndryGlblHOGTree : gradient by index= "+ah[0][0].getGradientByIndex(0));
        System.out.println("RectBndryGlblHOGTree : gradient by angle = "+ah[0][0].getGradientByAngle(45));
        System.out.println("RectBndryGlblHOGTree : max gradient = "+ah[0][0].getMaxGradient());
        
        System.out.println("RectBndryGlblHOGTree: "+myHOGPosition.getHog());
        updtBndry(myHOGPosition);
    }
    RectBndryGlblHOGTree(HOGPosition myHOGPosition,int myImageWidth,int myImageHeight) {
        super(new YBndryComparator());
        mathVectorMap = new HashMap();
        cntrHOGPosition = new HOGPosition();        
        centroidPos = new CentroidHGPstn(myImageWidth,myImageHeight);
        xMax = -Integer.MAX_VALUE;
        yMax = -Integer.MAX_VALUE;

        xMin = Integer.MAX_VALUE;
        yMin = Integer.MAX_VALUE;

        setXAvg((int) myHOGPosition.getX());//This may need updating
        setYAvg((int) myHOGPosition.getY());//This may need updating
        centroidPos.updateCentroid(myHOGPosition);
        
        //System.err.println("RectBndryHOGArrayList : possible error");        
        updtBndry(myHOGPosition);
    }   
    void updateBoundaryRfrnce(HOGPosition myHOGPosition) {
        myHOGPosition.setTrackBoundary(this);
    }

    void updateHOGGridID(HOGPosition myHOGPosition) {
        myHOGPosition.setGridID(boundaryID);
    }

    int getBoundaryID() {
        return boundaryID;
    }

    void setBoundaryID(int myBoundaryID) {
        this.boundaryID = myBoundaryID;
    }

    void updateXSum(int myXSum) {
        xSum += myXSum;
    }

    void updateYSum(int myYSum) {
        ySum += myYSum;
    }

    void updateZSum(int myZSum) {
        zSum += myZSum;
    }

    void updateXAvg(int myX) {
        xSum = xAvg + myX;
        xAvg = xSum / 2;
    }

    void updateYAvg(int myY) {
        ySum = yAvg + myY;
        yAvg = ySum / 2;
    }

    void updateZAvg(int myZ) {
        zSum = zAvg + myZ;
        zAvg = zSum / 2;
    }

    int getXAvg() {
        return xAvg;
    }

    int getYAvg() {
        return yAvg;
    }

    int getZAvg() {
        return zAvg;
    }

    int getXSum() {
        return xSum;
    }

    void setXSum(int xSum) {
        this.xSum = xSum;
    }

    int getYSum() {
        return ySum;
    }

    void setYSum(int ySum) {
        this.ySum = ySum;
    }

    int getZSum() {
        return zSum;
    }

    void setZSum(int zSum) {
        this.zSum = zSum;
    }

    int getXMax() {
        return xMax;
    }

    void setXMax(int xMax) {
        this.xMax = xMax;
    }

    int getXMin() {
        return xMin;
    }

    int getXWidth(){
        return getXMax()-getXMin();
    }
    int getMaxLength(){
        int aLength = 0;
        int xWidth = getXWidth();
        int yHeight = getYHeight();
        if(xWidth > yHeight){
            aLength = xWidth;
        }else{
            aLength = yHeight;
        }
        return aLength;
    }
    
    void setXMin(int xMin) {
        this.xMin = xMin;
    }

    int getYMax() {
        return yMax;
    }
    void setYMax(int yMax) {
        this.yMax = yMax;
    }

    int getYMin() {
        return yMin;
    }

    void setYMin(int yMin) {
        this.yMin = yMin;
    }
    int getYHeight(){
        return getYMax()-getYMin();
    }
    int retrieveCenterX() {
        int aCenterX = (int) ((getXMax() + getXMin()) / 2);
        return aCenterX;
    }

    int retrieveCenterY() {
        int aCenterY = (int) ((getYMax() + getYMin()) / 2);
        return aCenterY;
    }

    void setColor(int myColor) {
        color = myColor;
    }

    int getColor() {
        return color;
    }

    public boolean add(Object myObject) {
        HOGPosition aHOGPosition = (HOGPosition) myObject;
        return updtBndry(aHOGPosition);
        //return super.add(myObject);
    }

    void mergeBndry(RectBndryGlblHOGTree myRectBndryGlblHOGTree) {
    //TODO: this method could be replaced with direct modification of max & min boundary values
        Iterator anIterator = myRectBndryGlblHOGTree.iterator();
        while(anIterator.hasNext()){
            HOGPosition aHOGPosition = (HOGPosition) anIterator.next();
            updtBndry(aHOGPosition);
        }
    }
    boolean updtBndry(HOGPosition myHOGPosition) {
        //super.add(myHOGPosition);
        int xPos = (int)myHOGPosition.getX();
        int yPos = (int)myHOGPosition.getY();
        if (xPos >= xMax) {
            setXMax(xPos);
        }
        if (yPos >= yMax) {
            setYMax(yPos);
        }
        if (xPos <= xMin) {
            setXMin(xPos);
        }
        if (yPos <= yMin) {
            setYMin(yPos);
        }

        updateXAvg((int)Math.round(myHOGPosition.getX()));
        updateYAvg((int)Math.round(myHOGPosition.getY()));
        updateBoundaryRfrnce(myHOGPosition);
        insertTrackID(myHOGPosition);
        cntrHOGPosition.addHOG(myHOGPosition);
        cntrHOGPosition.setX((getXMax()+getXMin())/2);
        cntrHOGPosition.setY((getYMax()+getYMin())/2); 
        
        centroidPos.updateCentroid(myHOGPosition);        
     
        if(centroidPos.getTrackBoundary() == null){
           centroidPos.setTrackBoundary(this);
        }
        if(cntrHOGPosition.getTrackBoundary() == null){
           cntrHOGPosition.setTrackBoundary(this);
        }
        
        return super.add(myHOGPosition);
    }
    void insertTrackID(HOGPosition myHOGPosition) {
        int x = (int)myHOGPosition.getX();
        int y = (int)myHOGPosition.getY();
        String trackID = "";

        MathVector aHOGMathVector = MathVector.createUnitVector(x, y, 0);
        HOGPosition aHOGPosition = myHOGPosition.rtrveHOGMatch();
        if (aHOGPosition != null) {
            RectBndryGlblHOGTree trackerBoundary = (RectBndryGlblHOGTree) aHOGPosition.getTrackBoundary();
            
            if(trackerBoundary != null){             
               trackID = "" + trackerBoundary.getBoundaryID();
            }else{
               trackID = "-1";
               //System.out.println("RectBndryHOGTree : trackerBoundary = null");                
            }
            if(mathVectorMap == null) 
            {
                System.err.println("RectBndryHOGTree : trackerBoundary = null");
            }
            MathVector aMathVector = (MathVector) mathVectorMap.get(trackID);

            if (aMathVector != null) {
                aMathVector.add(aHOGMathVector);
            } else {
                mathVectorMap.put(trackID, aHOGMathVector);
            }
        }
    }    
    void updateTrackID(){
        Set aKeySet = mathVectorMap.keySet();
        Iterator anIterator = aKeySet.iterator();
        float magnitude = 0;
        while (anIterator.hasNext()) {
            String aTrackID = (String)anIterator.next();
            MathVector aMathVector = (MathVector)mathVectorMap.get(aTrackID);
            magnitude = aMathVector.getMagnitude();
            
            if(magnitude >= maxMagnitude){
                maxMagnitude = magnitude;
                maxTrackID = Integer.parseInt(aTrackID);
            }            
        }    
        if(maxTrackID != -1){
            boundaryID = maxTrackID;
            maxTrackID = -1;
        }        
    }    
    void updateTrackIDViaGlblHOG(TreeMap myTreeMap, int myImageWidth, int myImageHeight){
        
        if(myTreeMap == null){
            return;
        }
        CentroidHGPstn aHOGPosition1 = getCentroidHGPstn();
        CentroidHG aCentroidHG = aHOGPosition1.getCentroidHG();
        double aMaxDistance1 = aCentroidHG.rtrveCntrdFtreMaxDstnce();
        
        RectBndryGlblHOGTree aRectBndryHOGArrayTree = null;

        Iterator anIterator2 = null;
        Integer aGroupKey = null;
        HOGPosition aGlblHOGPosition1 = getCntrHOGPosition();
        HOGPosition matchedHOGPosition = null;
        double ecldnDstnce = Double.MAX_VALUE;
        int matchedIndex = 0;

        Set aSet = myTreeMap.keySet();
        Iterator anIterator1 = aSet.iterator();
        //System.out.println("RectBndryGlblHOGTree: HOG1, "+getBoundaryID()+", "+aGlblHOGPosition1.getX()+", "+aGlblHOGPosition1.getY()+", color = "+getColor());
        while (anIterator1.hasNext()) {
            aGroupKey = (Integer) anIterator1.next();
            aRectBndryHOGArrayTree = (RectBndryGlblHOGTree) myTreeMap.get(aGroupKey);
            
            CentroidHGPstn aHOGPosition2 = aRectBndryHOGArrayTree.getCentroidHGPstn();
            CentroidHG aCentroidHG2 = aHOGPosition2.getCentroidHG();
            double aMaxDistance2 = aCentroidHG2.rtrveCntrdFtreMaxDstnce();
            //double aScaleDiff = Math.abs(aMaxDistance2 - aMaxDistance1)/(aMaxDistance2+aMaxDistance1);
            HOGPosition aGlblHOGPosition2 = aRectBndryHOGArrayTree.getCntrHOGPosition();
            //Update code ... ?
            double hogEcldnDstnceTmp = HistogramOG.compareHog1x1BinDiff
                    (aGlblHOGPosition1.getHog(),aGlblHOGPosition2.getHog(),aMaxDistance1,aMaxDistance2);
            double aTrnsltnDistance = CentroidHG.cmpteTrnsltnDstnce(aCentroidHG, aCentroidHG2);
            //TODO:check for scale difference
            //Note: hogDstnceThrshld should vary with scale
            //System.out.println("RectBndryGlblHOGTree: HOG2, "+aRectBndryHOGArrayTree.getBoundaryID()+", "+aGlblHOGPosition2.getX()+", "+aGlblHOGPosition2.getY()+", color = "+aRectBndryHOGArrayTree.getColor());
            //System.out.println("RectBndryGlblHOGTree: test 1: hogEcldnDstnceTmp = "+hogEcldnDstnceTmp+", ecldnDstnce = "+ecldnDstnce+". translation dist. = "+aTrnsltnDistance+", glblTrnsltnDstnceThrshld = "+glblTrnsltnDstnceThrshld);
            //aScaleDiff <= .34 && aGlblHOGPosition2.rtrveHOGMatch() == null &&
            if( hogEcldnDstnceTmp <= globalHogDstnceThrshld && hogEcldnDstnceTmp <= ecldnDstnce && aTrnsltnDistance < glblTrnsltnDstnceThrshld) {
                //System.out.println("REctBndryGlblHOGTree: Possible match ..."+getBoundaryID()+" & "+aRectBndryHOGArrayTree.getBoundaryID());
                //System.out.println("RectBndryGlblHOGTree: aTrnsltnDistance = "+aTrnsltnDistance+", glblTrnsltnDstnceThrshld = "+glblTrnsltnDstnceThrshld);
                matchedHOGPosition = aRectBndryHOGArrayTree.getCntrHOGPosition();
                matchedIndex = matchedHOGPosition.getPositionIndex();
                ecldnDstnce = hogEcldnDstnceTmp;
                if(matchedHOGPosition != null && matchedHOGPosition.getIsConnected() == false){
                   //System.out.println("REctBndryGlblHOGTree: Final match ..."+getBoundaryID()+" & "+aRectBndryHOGArrayTree.getBoundaryID() +", color "+aRectBndryHOGArrayTree.getColor());
                   //HOGPosition aHOGPositionTmp = aGlblHOGPosition1.rtrveHOGMatch();
                   //if(aHOGPositionTmp != null){
                   //   aHOGPositionTmp.connectHOGMatch(null);
                   //}
                   aGlblHOGPosition1.connectHOGMatch(matchedHOGPosition);                                      
                   setColor(aRectBndryHOGArrayTree.getColor());                   
                }                 
            }            
        }                     
    }   
    void updateTrackIDViaCHG(TreeMap aTreeMap){
        
        if(aTreeMap == null){
            return;
        }
        
        RectBndryGlblHOGTree aRectBndryHOGArrayTree = null;

        Iterator anIterator2 = null;
        Integer aGroupKey = null;
        CentroidHGPstn aCntrdHGPstn1 = getCentroidHGPstn();
        CentroidHGPstn matchedCntrdPstn = null;
        //CentroidHGPstn aCentroidPosition1 = getCentroidHGPstn();
        //CentroidHGPstn matchedCentroidHGPstn = null;
        
        double ecldnDstnce = Double.MAX_VALUE;
        int matchedIndex = 0;

        Set aSet = aTreeMap.keySet();
        Iterator anIterator1 = aSet.iterator();
        double ecldnDstnceTmp = 0;
        while (anIterator1.hasNext()) {
            aGroupKey = (Integer) anIterator1.next();
            aRectBndryHOGArrayTree = (RectBndryGlblHOGTree) aTreeMap.get(aGroupKey);
            //CentroidHGPstn aCentroidHGPstn2 = aRectBndryHOGArrayTree.getCentroidHGPstn();
            CentroidHGPstn aCentroidPosition2 = aRectBndryHOGArrayTree.getCentroidHGPstn();
            //ecldnDstnceTmp = CentroidHG.compareHog1x1BinDiff
            ecldnDstnceTmp = CentroidHG.computeBinDiffViaCompare2
                    (aCntrdHGPstn1.getCentroidHG(),aCentroidPosition2.getCentroidHG());
            //System.out.println("RectBndryGlblHOGTree: test 1: ecldnDstnceTmp = "+ecldnDstnceTmp+", ecldnDstnce = "+ecldnDstnce+", hogDstnceThrshld = "+hogDstnceThrshld);
            if (ecldnDstnceTmp <= globalHogDstnceThrshld && ecldnDstnceTmp <= ecldnDstnce) {
                matchedCntrdPstn = aCentroidPosition2;
                matchedIndex = aCentroidPosition2.getPositionIndex();
                ecldnDstnce = ecldnDstnceTmp;
            }            
        }          
        if (matchedCntrdPstn != null) {
            //System.out.println("REctBndryGlblHOGTree: Found match ...");
            aCntrdHGPstn1.connectHOGMatch(matchedCntrdPstn);
            RectBndryGlblHOGTree aRectBndryGlblHOGTree = (RectBndryGlblHOGTree)matchedCntrdPstn.getTrackBoundary();
            setRotationAngleSum(aRectBndryGlblHOGTree.getRotationAngleSum());
            setDistanceSum(aRectBndryGlblHOGTree.getDistanceSum());
            setScaleSum(aRectBndryGlblHOGTree.getScaleSum());            
        }  else{
            //System.err.println("RectBndryGlblHOGTree: no match!!! ecldnDstnceTmp = "+ecldnDstnceTmp+", ecldnDstnce = "+ecldnDstnce+", hogDstnceThrshld = "+hogDstnceThrshld);            
        }          
    }       
    void updateTrackInfo() {
        HOGPosition aHOGPosition = null;
        Iterator anIterator2 = iterator();
        while (anIterator2.hasNext()) {
            aHOGPosition = (HOGPosition) anIterator2.next();
            System.out.println("feature location : " + aHOGPosition.getX() + "," + aHOGPosition.getY());
            HOGPosition aHOGMatch = aHOGPosition.rtrveHOGMatch();
            if (aHOGMatch != null) {
                RectBndryGlblHOGTree aRectBndryHOGArrayList = (RectBndryGlblHOGTree) aHOGMatch.getTrackBoundary();
                boundaryID = aRectBndryHOGArrayList.getBoundaryID();
            }
        }
    }
    void drawSquare(int clrdCmpnnts[], int myWidth, int myHeight, int myColor) {
        int width = myWidth;
        int height = myHeight;
        //color = myColor;
        LineDraw.drawLine(xMin, yMin, xMax, yMin, clrdCmpnnts, width, height, myColor);
        LineDraw.drawLine(xMin, yMin, xMin, yMax, clrdCmpnnts, width, height, myColor);
        LineDraw.drawLine(xMax, yMin, xMax, yMax, clrdCmpnnts, width, height, myColor);
        LineDraw.drawLine(xMin, yMax, xMax, yMax, clrdCmpnnts, width, height, myColor);
    }
    void updataCentroidHG(){
        CentroidHG aCentroidHG = centroidPos.getCentroidHG();
        int pnt[] = aCentroidHG.getCentroid();
        centroidPos.setX(pnt[0]);
        centroidPos.setY(pnt[1]);        
        aCentroidHG.updateCentroidHG();   
        aCentroidHG.updateHOG();
    }
    void drawCentroidPnt(int clrdCmpnnts[], int myWidth, int myColor) {
        int width = myWidth;
        int color = myColor;
        CentroidHG aCentroidHG = centroidPos.getCentroidHG();
        //aCentroidHG.updateCentroidHG();//This code should be modified to check if already updated
        //aCentroidHG.updateHOG();
        
        int aCentroid[] = aCentroidHG.getCentroid();
        int aX = aCentroid[0];
        int aY = aCentroid[1];
        
        int anIndex = ImageTool.rtrvIndex(aX, aY, myWidth);
        //System.out.println("RectBndryGlblHOGTree.drawCentroid(): x = "+ aX+", y = "+aY);    

        clrdCmpnnts[anIndex+myWidth+1] = 0x00ff0000;
        clrdCmpnnts[anIndex+myWidth] = 0x00ff0000;           
        clrdCmpnnts[anIndex+myWidth-1] = 0x00ff0000;      
        clrdCmpnnts[anIndex-1] = 0x00ff0000;       
        clrdCmpnnts[anIndex] = 0x00ff00a00;        
        clrdCmpnnts[anIndex+1] = 0x00ff0000;           
        clrdCmpnnts[anIndex-myWidth+1] = 0x00ff0000;
        clrdCmpnnts[anIndex-myWidth] = 0x00ff0000;           
        clrdCmpnnts[anIndex-myWidth-1] = 0x00ff0000;        
    }    
    void drawGlblHOGTrnsltn(int myPixelData[], int myImageWidth,int myImageHeight,int myColor) {
        int anImageWidth = myImageWidth;
        int anImageHeight = myImageHeight;
        //int anIndex1 = myHOGPosition1.getPositionIndex();
        //int anIndex2 = myHOGPosition2.getPositionIndex();
        HOGPosition aHOGPosition1 = getCntrHOGPosition();
        HOGPosition aHOGPosition2 = aHOGPosition1.rtrveHOGMatch();
        
        if( aHOGPosition2 == null){
            return;
        }
        
        int x1 = (int)aHOGPosition1.getX();
        int y1 = (int)aHOGPosition1.getY();
        int x2 = (int)aHOGPosition2.getX();
        int y2 = (int)aHOGPosition2.getY();

        //trnsltnMgntde = PntTool.getDistance(x1, y1, x1+x1-x2,y1+y1-y2);
        trnsltnMgntde = PntTool.getDistance(x1, y1, x2,y2);
        trnsltnPhase = Math.atan2(y1-y2,x1-x2);
        distanceSum +=  trnsltnMgntde;
        
        int aPixelData[] = myPixelData;
        //System.out.println("RectBndryGlblHOGTree draw : x1 = "+x1+", y1 = "+y1+", x2 = "+x2+", y2 = "+y2);
        //ArrowCrtr.drawArrow(x1, y1, x2, y2, myPixelData, anImageWidth, anImageHeight, 0x0050e60d, 0x0050e60d);
        ArrowCrtr.drawArrow(x1, y1, x1+(int)(0.5*(x1-x2)), y1+(int)(0.5*(y1-y2)), aPixelData, anImageWidth, anImageHeight, myColor,myColor);
    }
    void drawCntrdTrnsltn(int myPixelData[], int myImageWidth,int myImageHeight,int myColor) {
        int anImageWidth = myImageWidth;
        int anImageHeight = myImageHeight;
        //int anIndex1 = myHOGPosition1.getPositionIndex();
        //int anIndex2 = myHOGPosition2.getPositionIndex();
        CentroidHGPstn aCentroidPosition1 = getCentroidHGPstn();
        CentroidHGPstn aCentroidPosition2 = aCentroidPosition1.rtrveHOGMatch();
        
        if(aCentroidPosition1 == null || aCentroidPosition2 == null){
            //System.out.println("RectBndryGlblHOGTree: null found");
            return;
        }
        
        int x1 = (int)aCentroidPosition1.getX();
        int y1 = (int)aCentroidPosition1.getY();
        int x2 = (int)aCentroidPosition2.getX();
        int y2 = (int)aCentroidPosition2.getY();

        trnsltnMgntde = PntTool.getDistance(x1, y1, x1+x1-x2,y1+y1-y2);
        trnsltnPhase = Math.atan2(y1-y2,x1-x2);
        distanceSum += trnsltnMgntde;
        int aPixelData[] = myPixelData;
        //System.out.println("RectBndryGlblHOGTree draw : x1 = "+x1+"y1 = "+y1+", x2 = "+x2+", y2 = "+y2+", x1-x2 = "+(x1-x2)+", y1-y2 = "+(y1-y2));
        ArrowCrtr.drawArrow(x1, y1, x2, y2, myPixelData, anImageWidth, anImageHeight, 0x0050e60d, 0x0050e60d);
        //ArrowCrtr.drawArrow(x1, y1, x1+x1-x2, y1+y1-y2, aPixelData, anImageWidth, anImageHeight, myColor,myColor);
    }
    void drawGlblHOGAngle(int myPixelData[], int myImageWidth,int myImageHeight) {
        int anImageWidth = myImageWidth;
        int anImageHeight = myImageHeight;

        HOGPosition aHOGPosition1 = getCntrHOGPosition();
        
        if(aHOGPosition1 == null){
            return;
        }
        
        int x1 = (int)aHOGPosition1.getX();
        int y1 = (int)aHOGPosition1.getY();
        HistogramOG aHOG[][] = aHOGPosition1.getHog();
        double anAngle = aHOG[0][0].getAngleWghtAvg();
        double aGradient = aHOG[0][0].getGradientAvg();
        int x2 = (int)(50*Math.cos(anAngle));
        int y2 = -(int)(50*Math.sin(anAngle));        

        int aPixelData[] = myPixelData;
        System.out.println("HOGCornerDetect draw angle : aGradient = "+aGradient+", anAngle = "+anAngle);        
        System.out.println("HOGCornerDetect draw angle : x1 = "+x1+"y1 = "+y1+", x2 = "+x2+", y2 = "+y2);
        //ArrowCrtr.drawArrow(x1, y1, x2, y2, myPixelData, anImageWidth, anImageHeight, 0x0050e60d, 0x0050e60d);
        ArrowCrtr.drawArrow(x1, y1, x1+x2, y1+y2, aPixelData, anImageWidth, anImageHeight, 0x00ff00ff,0x00ff00ff);
    }
    void drawGlblHOGOrnttn(int myPixelData[], int myImageWidth,int myImageHeight) {
        int anImageWidth = myImageWidth;
        int anImageHeight = myImageHeight;

        HOGPosition aHOGPosition1 = getCntrHOGPosition();
        CentroidHGPstn aCntrdHGPstn1 = getCentroidHGPstn();        
        
        if(aHOGPosition1 == null){
            return;
        }
        CentroidHG aCentroidHG = aCntrdHGPstn1.getCentroidHG();        
        double glblHOG[] = aCentroidHG.computeOrientation();
        int x1 = (int)aHOGPosition1.getX();
        int y1 = (int)aHOGPosition1.getY();
        //HistogramOG aHOG[][] = aHOGPosition1.getHog();
        //double glblHOG[] = aHOG[0][0].computeOrientation();
        
        int x2 = (int)glblHOG[0];
        int y2 = -(int)glblHOG[1];        

        int aPixelData[] = myPixelData;
             
        //System.out.println("RectBndryGlblHOGTree draw angle : x1 = "+x1+"y1 = "+y1+", x2 = "+x2+", y2 = "+y2);
        //ArrowCrtr.drawArrow(x1, y1, x2, y2, myPixelData, anImageWidth, anImageHeight, 0x0050e60d, 0x0050e60d);
        ArrowCrtr.drawLine(x1, y1, x1+x2, y1+y2, aPixelData, anImageWidth, anImageHeight, 0x00ff00ff,0x00ff00ff);
    }    
    void drawMaxGrdntAngle(int myPixelData[], int myImageWidth,int myImageHeight,int myColor) {
        int anImageWidth = myImageWidth;
        int anImageHeight = myImageHeight;

        HOGPosition aHOGPosition1 = getCntrHOGPosition();
        
        if(aHOGPosition1 == null){
            return;
        }
        
        int x1 = (int)aHOGPosition1.getX();
        int y1 = (int)aHOGPosition1.getY();
        
        HistogramOG aHOG[][] = aHOGPosition1.getHog();
        
        double aMaxGradient = aHOG[0][0].getMaxGradient();        
        double aMaxGradientAngle = aHOG[0][0].getMaxGradientAngle();      
        int aMaxGradientAngleIndex = aHOG[0][0].getMaxGradientBinIndex();
        double anAngle = aHOG[0][0].getAngleByIndex(aMaxGradientAngleIndex);
        
        //System.out.println("RectBndryGlbHOGTree: gradient index = "+aMaxGradientAngleIndex+",index anAngle = "+anAngle+", max gradient angle index = "+aMaxGradientAngleIndex+", max angle =  "+aMaxGradientAngle);
        
        rotationAngle = aMaxGradientAngle;
        int aMaxGradientX1 = (int)(aMaxGradient*Math.cos(aMaxGradientAngle));
        int aMaxGradientY1 = -(int)(aMaxGradient*Math.sin(aMaxGradientAngle));
                
        int x2 = (int)aMaxGradientX1;
        int y2 = -(int)aMaxGradientY1;        

        int aPixelData[] = myPixelData;
             
        //System.out.println("RectBndryGlblHOGTree draw angle : x1 = "+x1+"y1 = "+y1+", x2 = "+x2+", y2 = "+y2);
        //ArrowCrtr.drawArrow(x1, y1, x2, y2, myPixelData, anImageWidth, anImageHeight, 0x0050e60d, 0x0050e60d);
        ArrowCrtr.drawArrow(x1, y1, x1+x2, y1+y2, aPixelData, anImageWidth, anImageHeight, myColor,myColor);
    }     
    void drawMaxCntrdHOG(int myPixelData[], int myImageWidth,int myImageHeight) {
        int anImageWidth = myImageWidth;
        int anImageHeight = myImageHeight;

        CentroidHGPstn aHOGPosition1 = getCentroidHGPstn();
        CentroidHG aCentroidHG = aHOGPosition1.getCentroidHG();
        
        if(aHOGPosition1 == null || aCentroidHG == null){
            return;
        }
        
        int x1 = (int)retrieveCenterX();
        int y1 = (int)retrieveCenterY();
        
        double aGrdntHistogram[] = aCentroidHG.getGrdntHistogram();
        
        double aMaxGradient = aCentroidHG.getMaxGradient();        
        double aMaxGradientAngle = aCentroidHG.getMaxGradientAngle();        
        int aMaxGradientX1 = (int)(aMaxGradient*Math.cos(aMaxGradientAngle));
        int aMaxGradientY1 = -(int)(aMaxGradient*Math.sin(aMaxGradientAngle));
                
        int x2 = (int)aMaxGradientX1;
        int y2 = -(int)aMaxGradientY1;        

        int aPixelData[] = myPixelData;
             
        //System.out.println("RectBndryGlblHOGTree draw angle : x1 = "+x1+"y1 = "+y1+", x2 = "+x2+", y2 = "+y2);
        //ArrowCrtr.drawArrow(x1, y1, x2, y2, myPixelData, anImageWidth, anImageHeight, 0x0050e60d, 0x0050e60d);
        ArrowCrtr.drawArrow(x1, y1, x1+x2, y1+y2, aPixelData, anImageWidth, anImageHeight, 0x0000ffff,0x0000ffff);
    }  
    double cmpteChrctrstcScale(int myImageWidth, int myImageHeight) {
        int anImageWidth = myImageWidth;
        int anImageHeight = myImageHeight;
        //int aScale = 1000 * size() / (anImageWidth*anImageHeight);
        CentroidHGPstn aHOGPosition1 = getCentroidHGPstn();
        CentroidHG aCentroidHG = aHOGPosition1.getCentroidHG();
        
        if(aHOGPosition1 == null || aCentroidHG == null){
            return 0;
        }                
        chrctrstcScale = aCentroidHG.computeChrctrstcScale(myImageWidth,myImageHeight);
        return chrctrstcScale;    
    }      
    void setXAvg(int myXAvg) {
        this.xAvg = myXAvg;
    }
    void setYAvg(int myYAvg) {
        this.yAvg = myYAvg;
    }
    void setZAvg(int myZAvg) {
        this.zAvg = myZAvg;
    }
    HOGPosition getCntrHOGPosition() {
        return cntrHOGPosition;
    }
    void setCntrHOGPosition(HOGPosition myCntrHOGPosition) {
        this.cntrHOGPosition = myCntrHOGPosition;
    }        
    CentroidHGPstn getCentroidHGPstn(){
        return centroidPos;
    }
    double getTrnsltnPhase() {
        return trnsltnPhase;
    }
    void setTrnsltnPhase(double trnsltnPhase) {
        this.trnsltnPhase = trnsltnPhase;
    }

    double getTrnsltnMgntde() {
        return trnsltnMgntde;
    }

    void setTrnsltnMgntde(double trnsltnMgntde) {
        this.trnsltnMgntde = trnsltnMgntde;
    }

    double getChrctrstcScale() {
        return chrctrstcScale;
    }

    void setChrctrstcScale(double chrctrstcScale) {
        this.chrctrstcScale = chrctrstcScale;
    }

    double getRotationAngle() {
        CentroidHGPstn aCentroidPStn = getCentroidHGPstn();
        CentroidHG aCentroidHG = aCentroidPStn.getCentroidHG();
        int anIndex = aCentroidHG.rtrveGrdntIndexViaDstnce();
        rotationAngle = aCentroidHG.getAngleByIndex(anIndex);
        return rotationAngle;
    }

    void setRotationAngle(double rotationAngle) {
        this.rotationAngle = rotationAngle;
    }

    double getRotationAngleSum() {
        return rotationAngleSum;
    }

    void setRotationAngleSum(double myRotationAngleSum) {
        this.rotationAngleSum = myRotationAngleSum;
    }

    double getDistanceSum() {
        return distanceSum;
    }
    void setDistanceSum(double myDistanceSum) {
        this.distanceSum = myDistanceSum;
    }
    double getScaleSum() {
        return scaleSum;
    }

    void setScaleSum(double myScaleSum) {
        this.scaleSum = myScaleSum;
    }
    double computeRotationSum() {

        //int anIndex1 = myHOGPosition1.getPositionIndex();
        //int anIndex2 = myHOGPosition2.getPositionIndex();
        HOGPosition aHOGPosition1 = getCntrHOGPosition();
        HOGPosition aHOGPosition2 = aHOGPosition1.rtrveHOGMatch();
        
        if(aHOGPosition1 == null || aHOGPosition2 == null){
            //System.err.println("RectBndryGlblHOGTree null detected: HOGPosition1 = "+aHOGPosition1+", HOGPosition2 = " +aHOGPosition2);
            return rotationAngleSum;
        }
        
        RectBndryGlblHOGTree aRectBndryGlblHOGTree1 = (RectBndryGlblHOGTree)aHOGPosition1.getTrackBoundary();
        RectBndryGlblHOGTree aRectBndryGlblHOGTree2 = (RectBndryGlblHOGTree)aHOGPosition2.getTrackBoundary();

        double anAngle1 =  aRectBndryGlblHOGTree1.getRotationAngle();
        double anAngle2 =  aRectBndryGlblHOGTree2.getRotationAngle();
        double scale1   =  aRectBndryGlblHOGTree1.getChrctrstcScale();
        double scale2   =  aRectBndryGlblHOGTree2.getChrctrstcScale();
        double scale = (scale2+scale1)/2;
        
        //System.out.println("RectBndryGlblHOGTree : anAngle1 = "+anAngle1+", anAngle2 = "+anAngle2);
        rotationAngleSum += scale*(anAngle1 - anAngle2);
        double aRotation[] = {0,0,rotationAngleSum};
        //kinematicData.setRotation(aRotation);                
        return rotationAngleSum;
    }
    double computeRotationSum2() {

        //int anIndex1 = myHOGPosition1.getPositionIndex();
        //int anIndex2 = myHOGPosition2.getPositionIndex();
        CentroidHGPstn aCntrdHGPstn1 = getCentroidHGPstn();
        CentroidHGPstn aCntrdHGPstn2 = aCntrdHGPstn1.rtrveHOGMatch();
        
        if(aCntrdHGPstn1 == null || aCntrdHGPstn2 == null){
            System.err.println("RectBndryGlblHOGTree null detected: CntrdHGPstn1 = "+aCntrdHGPstn1+", CntrdHGPstn2 = " +aCntrdHGPstn2);
            return rotationAngleSum;
        }        
        
        //RectBndryGlblHOGTree aRectBndryGlblHOGTree1 = (RectBndryGlblHOGTree)aCntrdHGPstn1.getTrackBoundary();
        //RectBndryGlblHOGTree aRectBndryGlblHOGTree2 = (RectBndryGlblHOGTree)aCntrdHGPstn2.getTrackBoundary();
              
        double glblHOG1[] = aCntrdHGPstn1.getCentroidHG().computeOrientation2();
        double glblHOG2[] = aCntrdHGPstn2.getCentroidHG().computeOrientation2();
        
        double anAngle1 =  Math.atan2(glblHOG1[1],glblHOG1[0]);
        double anAngle2 =  Math.atan2(glblHOG2[1],glblHOG2[0]);
        
        //System.out.println("RectBndryGlblHOGTree : anAngle1 = "+anAngle1+", anAngle2 = "+anAngle2);
        rotationAngleSum += Math.abs(anAngle1 - anAngle2);
        double aRotation[] = {0,0,rotationAngleSum};
        System.out.println("rotation = "+rotationAngleSum);
        //kinematicData.setRotation(aRotation);                
        return rotationAngleSum;
    }
    double computeRotationSum3() {
        //int anIndex1 = myHOGPosition1.getPositionIndex();
        //int anIndex2 = myHOGPosition2.getPositionIndex();
        HOGPosition aHOGPosition1 = getCntrHOGPosition();
        HOGPosition aHOGPosition2 = aHOGPosition1.rtrveHOGMatch();
        
        if(aHOGPosition1 == null || aHOGPosition2 == null){
            System.err.println("RectBndryGlblHOGTree null detected: HOGPosition1 = "+aHOGPosition1+", HOGPosition2 = " +aHOGPosition2);
            return rotationAngleSum;
        }
        
        RectBndryGlblHOGTree aRectBndryGlblHOGTree1 = (RectBndryGlblHOGTree)aHOGPosition1.getTrackBoundary();
        RectBndryGlblHOGTree aRectBndryGlblHOGTree2 = (RectBndryGlblHOGTree)aHOGPosition2.getTrackBoundary();

        double anAngle1 =  aRectBndryGlblHOGTree1.getCentroidHGPstn().getCentroidHG().getMaxRealDstnceAngle();
        double anAngle2 =  aRectBndryGlblHOGTree2.getCentroidHGPstn().getCentroidHG().getMaxRealDstnceAngle();
        double scale1   =  aRectBndryGlblHOGTree1.getChrctrstcScale();
        double scale2   =  aRectBndryGlblHOGTree2.getChrctrstcScale();
        double scale = (scale2+scale1)/2;
        
        if(anAngle1 <= Math.PI/4 && anAngle2 >= 7*Math.PI/4){
            anAngle1 = anAngle1+2*Math.PI;
        }else if((anAngle2 <= Math.PI/4 && anAngle1 >= 7*Math.PI/4)){
            anAngle2 = anAngle2+2*Math.PI;            
        }
        double angleDiff = Math.abs(anAngle1 - anAngle2);
        System.out.println("RectBndryGlblHOGTree : anAngle1 = "+anAngle1+", anAngle2 = "+anAngle2+", angleDiff = "+angleDiff);

        if(angleDiff <= Math.PI/2){
           rotationAngleSum += 360*(anAngle1 - anAngle2)/(2*Math.PI);
        }
        double aRotation[] = {0,0,rotationAngleSum};
        //kinematicData.setRotation(aRotation);                
        return rotationAngleSum;
    }
    double computeScaleSum() {
        HOGPosition aHOGPosition1 = getCntrHOGPosition();
        HOGPosition aHOGPosition2 = aHOGPosition1.rtrveHOGMatch();
        
        if(aHOGPosition1 == null || aHOGPosition2 == null){
            System.err.println("RectBndryGlblHOGTree null detected: HOGPosition1 = "+aHOGPosition1+", HOGPosition2 = " +aHOGPosition2);
            return 0;
        }
        
        RectBndryGlblHOGTree aRectBndryGlblHOGTree1 = (RectBndryGlblHOGTree)aHOGPosition1.getTrackBoundary();
        RectBndryGlblHOGTree aRectBndryGlblHOGTree2 = (RectBndryGlblHOGTree)aHOGPosition2.getTrackBoundary();

        double aScale1 =  aRectBndryGlblHOGTree1.getCentroidHGPstn().getCentroidHG().getMaxDstnce();
        double aScale2 =  aRectBndryGlblHOGTree2.getCentroidHGPstn().getCentroidHG().getMaxDstnce();
        scaleSum += (.03*(aScale1 - aScale2));
        return scaleSum;
    }     
    double computeDistanceSum() {

        CentroidHGPstn aCntrdHGPstn1 = getCentroidHGPstn();
        CentroidHGPstn aCntrdHGPstn2 = aCntrdHGPstn1.rtrveHOGMatch();
        
        if(aCntrdHGPstn1 == null || aCntrdHGPstn2 == null){
            System.err.println("RectBndryGlblHOGTree null detected: CntrdHGPstn1 = "+aCntrdHGPstn1+", CntrdHGPstn2 = " +aCntrdHGPstn2);
            return rotationAngleSum;
        }
        
        //RectBndryGlblHOGTree aRectBndryGlblHOGTree1 = (RectBndryGlblHOGTree)aCntrdHGPstn1.getTrackBoundary();
        //RectBndryGlblHOGTree aRectBndryGlblHOGTree2 = (RectBndryGlblHOGTree)aCntrdHGPstn2.getTrackBoundary();
              
        double glblHOG1[] = aCntrdHGPstn1.getCentroidHG().computeOrientation();
        double glblHOG2[] = aCntrdHGPstn2.getCentroidHG().computeOrientation();
        
        double anAngle1 =  Math.atan2(glblHOG1[1],glblHOG1[0]);
        double anAngle2 =  Math.atan2(glblHOG2[1],glblHOG2[0]);
        
        //System.out.println("RectBndryGlblHOGTree : anAngle1 = "+anAngle1+", anAngle2 = "+anAngle2);
        rotationAngleSum += Math.abs(anAngle1 - anAngle2);
        double aRotation[] = {0,0,rotationAngleSum};
        //kinematicData.setRotation(aRotation);                
        return rotationAngleSum;
    }
    double computeXSum() {

        //int anIndex1 = myHOGPosition1.getPositionIndex();
        //int anIndex2 = myHOGPosition2.getPositionIndex();
        HOGPosition aHOGPosition1 = getCntrHOGPosition();
        HOGPosition aHOGPosition2 = aHOGPosition1.rtrveHOGMatch();
        
        if(aHOGPosition1 == null || aHOGPosition2 == null){
            //System.err.println("RectBndryGlblHOGTree null detected: HOGPosition1 = "+aHOGPosition1+", HOGPosition2 = " +aHOGPosition2);
            return rotationAngleSum;
        }
        
        RectBndryGlblHOGTree aRectBndryGlblHOGTree1 = (RectBndryGlblHOGTree)aHOGPosition1.getTrackBoundary();
        RectBndryGlblHOGTree aRectBndryGlblHOGTree2 = (RectBndryGlblHOGTree)aHOGPosition2.getTrackBoundary();

        double aX1 =  aRectBndryGlblHOGTree1.retrieveCenterX();
        double aX2 =  aRectBndryGlblHOGTree2.retrieveCenterX();
        //System.out.println("RectBndryGlblHOGTree : anAngle1 = "+anAngle1+", anAngle2 = "+anAngle2);
        xDistanceSum += 1*(aX1 - aX2);
        double aRotation[] = {0,0,rotationAngleSum};
                
        return xDistanceSum;
    }        
    double computeYSum() {

        //int anIndex1 = myHOGPosition1.getPositionIndex();
        //int anIndex2 = myHOGPosition2.getPositionIndex();
        HOGPosition aHOGPosition1 = getCntrHOGPosition();
        HOGPosition aHOGPosition2 = aHOGPosition1.rtrveHOGMatch();
        
        if(aHOGPosition1 == null || aHOGPosition2 == null){
            //System.err.println("RectBndryGlblHOGTree null detected: HOGPosition1 = "+aHOGPosition1+", HOGPosition2 = " +aHOGPosition2);
            return rotationAngleSum;
        }
        
        RectBndryGlblHOGTree aRectBndryGlblHOGTree1 = (RectBndryGlblHOGTree)aHOGPosition1.getTrackBoundary();
        RectBndryGlblHOGTree aRectBndryGlblHOGTree2 = (RectBndryGlblHOGTree)aHOGPosition2.getTrackBoundary();

        double aY1 =  aRectBndryGlblHOGTree1.retrieveCenterY();
        double aY2 =  aRectBndryGlblHOGTree2.retrieveCenterY();
        //System.out.println("RectBndryGlblHOGTree : anAngle1 = "+anAngle1+", anAngle2 = "+anAngle2);
        yDistanceSum += 1*(aY1 - aY2);
                
        return yDistanceSum;
    }            
    double computeScaleSum(int myImageWidth,int myImageHeight) {

        //int anIndex1 = myHOGPosition1.getPositionIndex();
        //int anIndex2 = myHOGPosition2.getPositionIndex();
        CentroidHGPstn aCntrdHGPstn1 = getCentroidHGPstn();
        CentroidHGPstn aCntrdHGPstn2 = aCntrdHGPstn1.rtrveHOGMatch();
        
        if(aCntrdHGPstn1 == null || aCntrdHGPstn2 == null){
            //System.err.println("RectBndryGlblHOGTree null detected: CntrdHGPstn1 = "+aCntrdHGPstn1+", CntrdHGPstn2 = " +aCntrdHGPstn2);
            return scaleSum;
        }
        
        //RectBndryGlblHOGTree aRectBndryGlblHOGTree1 = (RectBndryGlblHOGTree)aCntrdHGPstn1.getTrackBoundary();
        //RectBndryGlblHOGTree aRectBndryGlblHOGTree2 = (RectBndryGlblHOGTree)aCntrdHGPstn2.getTrackBoundary();
              
        double aScale1 = aCntrdHGPstn1.getCentroidHG().computeChrctrstcScale(myImageWidth,myImageHeight);
        double aScale2 = aCntrdHGPstn2.getCentroidHG().computeChrctrstcScale(myImageWidth,myImageHeight);
        
        //System.out.println("RectBndryGlblHOGTree : anAngle1 = "+anAngle1+", anAngle2 = "+anAngle2);
        scaleSum += (aScale1 - aScale2);
       
        return scaleSum;
    }    

    int getMinWidth() {
        return minWidth;
    }

    void setMinWidth(int minWidth) {
        this.minWidth = minWidth;
    }

    int getMinHeight() {
        return minHeight;
    }

    void setMinHeight(int minHeight) {
        this.minHeight = minHeight;
    }    
    boolean bndrySizeCheck(int myWidth, int myHeight) {
        int aWidth = getXMax() - getXMin();
        int aHeight = getYMax() - getYMin();
        if (aWidth >= myWidth && aHeight >= myHeight) {
            return true;
        } else {
            return false;
        }
    }    
}