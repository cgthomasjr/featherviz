package org.cgtjr.client;


public class HOGClusterTrackPhotoJS {

    public HOGClusterTrackPhotoJS() {
    }

    public native static void loadPhotoJS() /*-{
            var prcssbttn = $doc.getElementById('prcssbttnid');
            if(prcssbttn !== undefined && prcssbttn !== null){                  
                //$wnd.alert("pgi.value = "+pgi.value+", prcssbttn.id = "+prcssbttn.id);
                prcssbttn.addEventListener('click', function () {
                    @org.cgtjr.client.HOGClusterTrackPhoto::processData()();
                }, false);            
            }
    }-*/;
    public native static void loadSequenceJS() /*-{
            var prcsssqncebttn = $doc.getElementById('prcsssqncebttnid');
            if(prcsssqncebttn !== undefined && prcsssqncebttn !== null){                  
                //$wnd.alert("pgi.value = "+pgi.value+", prcsssqncebttn.id = "+prcsssqncebttn.id);
                prcsssqncebttn.addEventListener('click', function () {
                    @org.cgtjr.client.HOGClusterTrackPhoto::prcssSqunceData()();
                }, false);            
            }
    }-*/;   
    public native static void addUpdteBttnLstnr() /*-{
            var updteparambttn = $doc.getElementById('updtebttnid');
            if(updteparambttn !== undefined && updteparambttn !== null){                  
                //$wnd.alert("pgi.value = "+pgi.value+", prcsssqncebttn.id = "+prcsssqncebttn.id);
                updteparambttn.addEventListener('click', function () {
                    @org.cgtjr.client.HOGClusterTrackPhoto::updteGOHPrmtrs()();
                }, false);            
            }
    }-*/;    
    public native static void insrtGOHPrmtrsJS() /*-{
            var updteparambttn = $doc.getElementById('updtebttnid');
            if(updteparambttn !== undefined && updteparambttn !== null){                  
               //$wnd.alert("insrtGOHPrmtrsJS()... test ...");
               @org.cgtjr.client.HOGClusterTrackPhoto::insrtGOHPrmtrs()();
            }
    }-*/;         
}
