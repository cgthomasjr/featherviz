package org.cgtjr.client;

import com.google.gwt.user.client.ui.Label;

/**
 *
 * @author cgthomasjr
 */
class ConsoleLabel {

    private static Label logLabel;

    static Label getLogLabel() {
        if (logLabel == null) {
            logLabel = new Label();            
        }
        return logLabel;
    }

    static void setLogLabel(Label logLabel) {
        ConsoleLabel.logLabel = logLabel;
    }

    static void print(String myText) {
        logLabel.setText(logLabel.getText() + "\n" + myText);
    }
    static native void printInfo(String text)    
    /*-{
    console.log(text);
    }-*/;        
}

