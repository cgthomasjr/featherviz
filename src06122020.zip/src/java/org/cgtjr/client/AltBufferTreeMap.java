package org.cgtjr.client;

import java.util.TreeMap;

/**
 *
 * @author cgthomasjr
 */
class AltBufferTreeMap {
    private static int count;
    private static TreeMap altBuffer0;
    private static TreeMap altBuffer1; 
    private static int frameNumber;
    
    static void setAltBuffer(TreeMap myTreeMap){
        count =  YSclFltrTmp.getFrameIndex()%2;
        if(count == 0){
            altBuffer0 = myTreeMap;
        }else{
            altBuffer1 = myTreeMap;
        }
    }
    static TreeMap getAltBuffer(){
        count = YSclFltrTmp.getFrameIndex()%2;
        if(count == 1){
           return altBuffer0;
        }else{
           return altBuffer1;
        }
    }
}
