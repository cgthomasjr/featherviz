package org.cgtjr.client;

/**
 *
 * @author cgthomasjr
 */
class Gaussian2D {
    private double meanX;
    private double meanY;
    private double x;
    private double y;
    
    private double sigma;

    Gaussian2D(double myMeanX,double myMeanY,double mySigma){
        meanX = myMeanX;
        meanY = myMeanY;
        sigma = mySigma;
    }
    double getMeanX() {
        return meanX;
    }

    void setMeanX(double meanX) {
        this.meanX = meanX;
    }

    double getMeanY() {
        return meanY;
    }

    void setMeanY(double meanY) {
        this.meanY = meanY;
    }

    double getSigma() {
        return sigma;
    }

    void setSigma(double stndrdDvtn) {
        this.sigma = stndrdDvtn;
    }
    
    double computeGssn(double myX,double myY){
        double x2 = (myX-meanX)*(myX-meanX);
        double y2 = (myY-meanY)*(myY-meanY);
        
        double answer = Math.exp(-(x2+y2)/(2*sigma*sigma));
        return answer;
    }
}