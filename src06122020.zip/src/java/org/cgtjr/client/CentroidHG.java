package org.cgtjr.client;

import java.util.ArrayList;
/**
 * 
 * @author cgthomasjr
 */
class CentroidHG {
    private int centroid[];
    private double[] cntrdHistogram;
    private double[] grdntHistogram;    
    private double[] cntrdDstnces;
    private int numberOfBins;
    private double binSize;
    private double maxBinAngle;
    private double maxRealGrdntAngle;
    private double maxRealDstnceAngle;    
    private double maxGradient;
    private int maxGradientBinIndex;
    private double angleWghtedSum;
    private double gradientSum;
    private double angleWghtdAvg;
    private int totalCount;
    private double gradientAvg;
    private double glblVctrX;
    private double glblVctrY;    
    private int avgX;
    private int avgY;
    private int sumX;
    private int sumY;
    private ArrayList hogPosArrayList; 
    private int imageWidth;
    private int imageHeight;
    private int totalGradient;
    private int maxDstnceBinIndex;
    private double maxDstnce;    
    private static double rotationAngleSum;
    private double scaleFactor;
    
    /**
     * @param nbins -- number of bins (one for each orientation)
     */
    CentroidHG(int nbins) {
        numberOfBins = nbins;
        cntrdHistogram = new double[nbins];
        grdntHistogram = new double[nbins];
        cntrdDstnces = new double[nbins];
        
        this.binSize = 2.0*Math.PI/nbins;
        centroid = new int[2];
        hogPosArrayList = new ArrayList();
    }
    CentroidHG(int myWidth,int myHeight) {
        this(8);
        centroid = new int[2];
        hogPosArrayList = new ArrayList();        
        imageWidth = myWidth;
        imageHeight = myHeight;
        scaleFactor = Math.max(myWidth,myHeight);
    }
    CentroidHG() {
        this(8);
        centroid = new int[2];
        hogPosArrayList = new ArrayList();        
    }
    static CentroidHG[][] retrieveHOGGrid(int myXBlocks,int myYBlocks){
        CentroidHG HOGGrid[][] = new CentroidHG[myXBlocks][myYBlocks];
        return HOGGrid;
    }
    private void cntrdHGInsert(double phi, double gradient) {
       cntrdHGInsert(phi, gradient,1.0);        
    }
    private void cntrdHGInsert(double phi, double gradient,double myScale) {
        //System.out.println("HistogramOG.insert(): insert local hog .............................................");        
        double aPhiAngle = phi;//+binSize/2.0;
    
        //TODO: remove code.  Previous conflict with temporal gradient threshold!!!!!
        //gradient = (gradient <= 20) ?  0: gradient ;        
        //if(gradient == 0){
        //}

        if(aPhiAngle > 2 * Math.PI){
            aPhiAngle = aPhiAngle - 2*Math.PI;
        }else if(aPhiAngle < 0){
            aPhiAngle = 2*Math.PI + aPhiAngle;
        }        
        
        int binIndex = (int)((aPhiAngle)/binSize);        
        
        double scaledGradient = gradient*myScale;
        cntrdHistogram[binIndex] += scaledGradient;    
        totalGradient+=scaledGradient;
        updateMaxDstnce(cntrdHistogram[binIndex],aPhiAngle);

    }
    private void hogInsert(double phi, double gradient,double myScale) {
  
        double aPhiAngle = phi+binSize/2.0;
        
        if(aPhiAngle > 2 * Math.PI){
            aPhiAngle = aPhiAngle - 2*Math.PI;
        }else if(aPhiAngle < 0){
            aPhiAngle = 2*Math.PI + aPhiAngle;
        }        
       
        int binIndex = (int)((aPhiAngle)/binSize);        
        
        double scaledGradient = gradient*myScale;
        grdntHistogram[binIndex] += scaledGradient;     
        totalGradient+=scaledGradient;        
        updateMaxGradientAngle(grdntHistogram[binIndex],binIndex,aPhiAngle);
        updteAngleViaWghtdAvg(aPhiAngle,scaledGradient);
    }    
   
    private void updteAngleViaWghtdAvg(double myPhiAngle,double myGradient){
        angleWghtedSum += myPhiAngle*myGradient;
        gradientSum += myGradient;  
        angleWghtdAvg = angleWghtedSum/gradientSum;
        gradientAvg = gradientSum/totalCount;
    }
    void updateCentroid(HOGPosition myHOGPosition){
        int aX = (int)myHOGPosition.getX();
        int aY = (int)myHOGPosition.getY();

        totalCount++; 
        hogPosArrayList.add(myHOGPosition);        
        sumX +=  aX; 
        sumY +=  aY;
        avgX = sumX/totalCount;
        avgY = sumY/totalCount;
        centroid[0] = avgX;
        centroid[1] = avgY;
    }
    void updateCentroidHG(){    
        int aSize = hogPosArrayList.size();
        for(int i=0;i<aSize;i++){
            HOGPosition aHOGPosition = (HOGPosition)hogPosArrayList.get(i);
            int aX = (int)aHOGPosition.getX();
            int aY = (int)aHOGPosition.getY();
            double anAngle = computeAngle(aX,aY);
            double aMag = computeMag(aX,aY);
            
            cntrdHGInsert(anAngle, aMag);
            updteMaxCntrdDstnce(anAngle,aMag);
        }
    }
    void updateHOG(){    
        int centroidX = centroid[0];
        int centroidY = centroid[1];
        double sigma = 80;
        Gaussian2D aGaussian2D = new Gaussian2D(centroidX,centroidY,sigma);
        int aSize = hogPosArrayList.size();
        for(int i=0;i<aSize;i++){
            HOGPosition aHOGPosition = (HOGPosition)hogPosArrayList.get(i);
            HistogramOG aHistogramOG[][] = (HistogramOG[][])aHOGPosition.getHog();
            int aX = (int)aHOGPosition.getX();
            int aY = (int)aHOGPosition.getY();
            double aScale = aGaussian2D.computeGssn(aX,aY);
            //System.out.println("CentroidHG: histogram value = "+aHistogramOG[0][0]);
            //aClusterGlblTrackFltr : binddHistogramOG(aHistogramOG[0][0],aScale);
            addHistogramOG(aHistogramOG[0][0],1);
        }
    }
    private double computeAngle(int myX,int myY){        
        int aY = myY-centroid[1];
        int aX = myX-centroid[0];        
        double anAngle = 0;
        if(aY >= 0){
           anAngle = Math.atan2(aY,aX);            
        }else{
           anAngle = 2*Math.PI+Math.atan2(aY,aX); 
        }
        //System.out.println("CentroidHG : x = "+aX+", y = "+aY+", anAngle = "+anAngle);
        return anAngle;
    }
    private double computeMag(int myX,int myY){
        int aY = centroid[1];
        int aX = centroid[0];   
        double aMagnitude = PntTool.getDistance(aX, aY, myX, myY);
        return aMagnitude;
    }
            
    double getAngleWghtAvg(){
        System.out.println("HistogramOG: angleWghtAvg = "+angleWghtdAvg);
        return angleWghtdAvg;
    }
    double getGradientAvg(){
        System.out.println("HistogramOG: gradientAvg = "+gradientAvg);
        return gradientAvg;
    }      
    private double computeMaxGradient() {
        double max = 0.0;
        for(int i=0;i<numberOfBins;i++) {
            if(cntrdHistogram[i] > max) max = cntrdHistogram[i];
        }
        return max;
    }
    private void updateMaxRealAngle(double myMaxGradient,double myRealAngle){
        if(myMaxGradient > maxGradient){
            maxGradient = myMaxGradient;
            maxRealGrdntAngle = myRealAngle;
        }
    }
    private void updateMaxGradientAngle(double myMaxGradient,int myGradientBinIndex,double myRealAngle){
        if(myMaxGradient > maxGradient){
            maxGradient = myMaxGradient;
            maxGradientBinIndex = myGradientBinIndex;
            maxBinAngle = getAngleByIndex(myGradientBinIndex);
            maxRealGrdntAngle = myRealAngle;
        }
    }
    private void updteMaxCntrdDstnce(double phi,double myMgntde){
        double aPhiAngle = phi;//+binSize/2.0;
        if(aPhiAngle > 2 * Math.PI ){
            aPhiAngle = aPhiAngle - 2*Math.PI;
        }else if(aPhiAngle < 0){
            aPhiAngle = 2*Math.PI + aPhiAngle;
        }        
        
        int binIndex = (int)((aPhiAngle)/binSize);
        if(myMgntde > cntrdDstnces[binIndex]){
            cntrdDstnces[binIndex] = myMgntde;
        }
    }
    private void updateMaxDstnce(double myDistance,double myPhiAngle){        
        double angleDiff = Math.abs(maxRealDstnceAngle - myPhiAngle); 
        if(myDistance > maxDstnce){
            maxDstnce = myDistance;
            maxRealDstnceAngle = myPhiAngle;             
        }        
    }
    double rtrveCntrdFtreMaxDstnce(){
        return cntrdDstnces[maxDstnceBinIndex];
    }
    int rtrveGrdntIndexViaDstnce(){
        int maxGradIndex1 = getMaxGradientBinIndex();
        double aMaxGrdnt1 = getMaxGradient();
        double aGrdnt1 = getGrdntMagByIndex(maxGradIndex1);        
                
        int maxGradIndex2 = rtrvePlus180Index(maxGradIndex1);
        double aGrdnt2 = getGrdntMagByIndex(maxGradIndex2);
        
        int maxGradIndex3 = rtrveMaxDstnceBinIndex(maxGradIndex1,maxGradIndex2);

        return maxGradIndex3;       
    }
    private int rtrvePlus180Index(int myIndex1){
        int anIndex2 = 0;
        int indexPlus180 = numberOfBins/2;
        if(myIndex1 + indexPlus180 <  numberOfBins){
            anIndex2 = myIndex1 + indexPlus180;
        }else{
            anIndex2 = myIndex1 - indexPlus180;        
        }
        return anIndex2;        
    }
    private int rtrveMaxDstnceBinIndex(int myIndex1,int myIndex2){
        int anIndex = 0;
        //System.out.println("CentroidHG: cntrdDstnces["+myIndex1+"] = "+cntrdDstnces[myIndex1]+", cntrdDstnces["+myIndex2+"] = "+cntrdDstnces[myIndex2]);
        if(cntrdDstnces[myIndex1] >= cntrdDstnces[myIndex2]){
            anIndex = myIndex1;
        }else if(cntrdDstnces[myIndex1] < cntrdDstnces[myIndex2]){
            anIndex = myIndex2;
        }
        return anIndex;
    }    
    double getMaxGradient()
    {
        return maxGradient;
    }
    int getMaxGradientBinIndex(){
        return maxGradientBinIndex;
    }
    void setMaxGradientBinIndex(int myIndex){
        maxGradientBinIndex = myIndex;
    }    
    double getMaxGradientAngle(){
        return maxBinAngle;
    }
    double getAngleByIndex(int myBinIndex) {
        return myBinIndex * binSize;
    }  
    double getDistMagByIndex(int bin) {
        return cntrdHistogram[bin];
    }    
    double getGrdntMagByIndex(int bin) {
        return grdntHistogram[bin];
    }
    double getGradientByAngle(double phi) {
        double aPhiAngle = phi;   
        if(aPhiAngle > 2 * Math.PI){
            aPhiAngle = aPhiAngle - 2*Math.PI;
        }else if(aPhiAngle < 0){
            aPhiAngle = 2*Math.PI+phi;
        }          
        int binIndex;
        binIndex = (int)(aPhiAngle/binSize);        
        return cntrdHistogram[binIndex];
    }
    private double computeBinAngle(double myAngle){
        double aPhiAngle = myAngle;
        if(myAngle < 0){
            aPhiAngle = 2*Math.PI+myAngle;
        }
        int binIndex = (int)(aPhiAngle/binSize);
        double angle = (binIndex*binSize);
        return angle;            
    }
    double[] getCntrdHistogram() {
        return cntrdHistogram;
    }
    double[] getGrdntHistogram() {
        return grdntHistogram;
    }    
    int getNumberOfBins() {
        return numberOfBins;
    }
    double getBinSize() {
        return binSize;
    }
    private void addHistogramOG(HistogramOG myHistogramOG,double myScale){
        int nmbrBins = myHistogramOG.getNumberOfBins();

        for(int i=0;i<nmbrBins;i++){
            double anAngle = myHistogramOG.getAngleByIndex(i);
            double aGradient = myHistogramOG.getGradientByIndex(i);
            hogInsert(anAngle,aGradient,myScale);         
        }
    }    
    double[] computeOrientation(){
        int aMaxGradientIndex = rtrveGrdntIndexViaDstnce();
        return computeOrientation(aMaxGradientIndex);
    }    
    double[] computeOrientation2(){
        int aMaxGradientIndex = getMaxGradientBinIndex();
        return computeOrientation(aMaxGradientIndex);
    }        
    double[] computeOrientation(int myIndex){
        int nmbrBins = getNumberOfBins();
        int aMaxGradientIndex = myIndex;
        int leftIndex = aMaxGradientIndex+1;
        int rightIndex = aMaxGradientIndex-1;    
        
        if(leftIndex >= nmbrBins){
            leftIndex = leftIndex - nmbrBins;
        }
        if(rightIndex < 0){
            rightIndex = nmbrBins + rightIndex;
        }        
        double aMaxGradient = getMaxGradient();        
        double aMaxGradientAngle = getAngleByIndex(aMaxGradientIndex);        
        int aMaxGradientX1 = (int)(aMaxGradient*Math.cos(aMaxGradientAngle));
        int aMaxGradientY1 = -(int)(aMaxGradient*Math.sin(aMaxGradientAngle));
        
        double aLeftGradient = getDistMagByIndex(leftIndex);
        double aLeftAngle = getAngleByIndex(leftIndex);        
        int aLeftGradientX1 = (int)(aLeftGradient*Math.cos(aLeftAngle));
        int aLeftGradientY1 = -(int)(aLeftGradient*Math.sin(aLeftAngle));
        
        double aRightGradient = getDistMagByIndex(rightIndex);
        double aRightAngle = getAngleByIndex(rightIndex);        
        int aRightGradientX1 = (int)(aRightGradient*Math.cos(aRightAngle));
        int aRightGradientY1 = -(int)(aRightGradient*Math.sin(aRightAngle));        
        
        int totalX = aMaxGradientX1+aLeftGradientX1+aRightGradientX1;      
        int totalY = aMaxGradientY1+aLeftGradientY1+aRightGradientY1;             
        
        glblVctrX = totalX;
        glblVctrY = totalY;
            //}   
        double aGlblVctr[] = {glblVctrX,glblVctrY};
        return aGlblVctr;
    }
    private double[] compute180OrientationOld(){       
        int nmbrBins = getNumberOfBins()/2;
        for(int i=0;i<nmbrBins;i++){
            double anAngle = getAngleByIndex(i);
            double aGradient = getDistMagByIndex(i);
            int x1 = (int)(aGradient*Math.cos(anAngle));
            int y1 = -(int)(aGradient*Math.sin(anAngle));             

            glblVctrX += x1;
            glblVctrY += y1;
            
        }   
        double aGlblVctr[] = {glblVctrX,glblVctrY};
        return aGlblVctr;
    }
    double getGlblVctrX(){
        return glblVctrX;
    }
    double getGlblVctrY(){
        return glblVctrY;
    }
    double compareBins8(CentroidHG myHOG2) {
        return compareBins8(this,myHOG2);
    }    
    static double compareBins8(CentroidHG myHOG1, CentroidHG myHOG2) {;
        int anIndexDiff = computeIndexDiffViaDstnce(myHOG1, myHOG2);
        
        int anIndex0 = rtrveBinOffSet(0,anIndexDiff,8);        
        int anIndex1 = rtrveBinOffSet(1,anIndexDiff,8);
        int anIndex2 = rtrveBinOffSet(2,anIndexDiff,8);
        int anIndex3 = rtrveBinOffSet(3,anIndexDiff,8);
        int anIndex4 = rtrveBinOffSet(4,anIndexDiff,8);
        int anIndex5 = rtrveBinOffSet(5,anIndexDiff,8);
        int anIndex6 = rtrveBinOffSet(6,anIndexDiff,8);
        int anIndex7 = rtrveBinOffSet(7,anIndexDiff,8);
        
        double hogDiff0 = computeHogBinDiff(myHOG1, myHOG2, anIndex0, 0);
        double hogDiff1 = computeHogBinDiff(myHOG1, myHOG2, anIndex1, 1);
        double hogDiff2 = computeHogBinDiff(myHOG1, myHOG2, anIndex2, 2);
        double hogDiff3 = computeHogBinDiff(myHOG1, myHOG2, anIndex3, 3);
        double hogDiff4 = computeHogBinDiff(myHOG1, myHOG2, anIndex4, 4);
        double hogDiff5 = computeHogBinDiff(myHOG1, myHOG2, anIndex5, 5);
        double hogDiff6 = computeHogBinDiff(myHOG1, myHOG2, anIndex6, 6);
        double hogDiff7 = computeHogBinDiff(myHOG1, myHOG2, anIndex7, 7);
        
        double sumHOGDiff = hogDiff0 * hogDiff0 + hogDiff1 * hogDiff1 + hogDiff2 * hogDiff2 + hogDiff3 * hogDiff3
                + hogDiff4 * hogDiff4 + hogDiff5 * hogDiff5 + hogDiff6 * hogDiff6 + hogDiff7 * hogDiff7;
        return sumHOGDiff;
    }
    static double computeBinDiffViaCompare(CentroidHG myHOG1, CentroidHG myHOG2) {
        int hog1MaxIndex = myHOG1.getMaxGradientBinIndex();        
        int hog2MaxIndex = myHOG2.getMaxGradientBinIndex();
        int hogIndexDiff1 = hog2MaxIndex - hog1MaxIndex;
        int hogIndexDiff2 = 0;
        
        double binDiff = 0;
        
        double aDiff1 =  computeBinsDiff8(myHOG1, myHOG2,hogIndexDiff1);
        
        int aDiff1Plus4 = rtrveBinOffSet(hog2MaxIndex,4,8);
        hogIndexDiff2 = hog1MaxIndex - aDiff1Plus4;
        
        double aDiff2 = computeBinsDiff8(myHOG1, myHOG2,hogIndexDiff2);
            
        if(aDiff1 <= aDiff2){
            binDiff = aDiff1;
        }else{
            hog1MaxIndex = hog2MaxIndex;
            myHOG1.setMaxGradientBinIndex(hog2MaxIndex); 
            binDiff = aDiff2;
        }

        double glblHOG1[] = myHOG1.computeOrientation2();
        double glblHOG2[] = myHOG2.computeOrientation2();
        
        double anAngle1 =  Math.atan2(glblHOG1[1],glblHOG1[0]);
        double anAngle2 =  Math.atan2(glblHOG2[1],glblHOG2[0]);
        
        rotationAngleSum += Math.abs(anAngle1 - anAngle2);
        
        return binDiff;
    }    
    static double computeBinDiffViaCompare2(CentroidHG myHOG1, CentroidHG myHOG2) {
        int hog1MaxIndex = myHOG1.getMaxGradientBinIndex();        
        int hog2MaxIndex = myHOG2.getMaxGradientBinIndex();
        int hogIndexDiff1 = hog2MaxIndex - hog1MaxIndex;
        
        double binDiff = Math.abs(hogIndexDiff1);
        
        if(binDiff == 4){
            hog1MaxIndex = hog2MaxIndex;
            myHOG1.setMaxGradientBinIndex(hog2MaxIndex); 
        }
        
        double glblHOG1[] = myHOG1.computeOrientation2();
        double glblHOG2[] = myHOG2.computeOrientation2();
        
        double anAngle1 =  Math.atan2(glblHOG1[1],glblHOG1[0]);
        double anAngle2 =  Math.atan2(glblHOG2[1],glblHOG2[0]);
        
        rotationAngleSum += Math.abs(anAngle1 - anAngle2);

        return binDiff;
    }    
    static double computeAngleDiffViaCompare(CentroidHG myHOG1, CentroidHG myHOG2) {

        int hog1MaxIndex = myHOG1.getMaxGradientBinIndex();        
        int hog2MaxIndex = myHOG2.getMaxGradientBinIndex();
        int hogIndexDiff = hog2MaxIndex - hog1MaxIndex;
        double angleDiff = 0;
        
        double aDiff1 =  computeBinsDiff8(myHOG1, myHOG2,hogIndexDiff);
        
        int aDiff1Plus4 = rtrveBinOffSet(hog1MaxIndex,hogIndexDiff+4,8);
        
        double aDiff2 =  computeBinsDiff8(myHOG1, myHOG2,aDiff1Plus4);
                
        if(aDiff1 <= aDiff2){
            double angle1[] = myHOG1.computeOrientation(hog1MaxIndex);
            double angle2[] = myHOG2.computeOrientation(hog2MaxIndex);  
            angleDiff = angle2[0]-angle1[0];
        }else{
            double angle1[] = myHOG1.computeOrientation(hog1MaxIndex);
            double angle2[] = myHOG2.computeOrientation(hogIndexDiff+4);   
            angleDiff = angle2[0]-angle1[0];
        }     
        return angleDiff;
    }      
    static double compareDiffBins8(CentroidHG myHOG1, CentroidHG myHOG2) {
        int anIndexDiff = computeHogBinIndexDiff(myHOG1, myHOG2);
        double aDiff1 =  computeBinsDiff8(myHOG1, myHOG2,anIndexDiff);
        double aDiff2 =  computeBinsDiff8(myHOG1, myHOG2,anIndexDiff+4);
        if(aDiff1 <= aDiff2){
            return aDiff1;
        }else{
            return aDiff2;
        }
    }
    static double computeBinsDiff8(CentroidHG myHOG1, CentroidHG myHOG2,int myIndexDiff){
        int anIndex0 = rtrveBinOffSet(0,myIndexDiff,8);        
        int anIndex1 = rtrveBinOffSet(1,myIndexDiff,8);
        int anIndex2 = rtrveBinOffSet(2,myIndexDiff,8);
        int anIndex3 = rtrveBinOffSet(3,myIndexDiff,8);
        int anIndex4 = rtrveBinOffSet(4,myIndexDiff,8);
        int anIndex5 = rtrveBinOffSet(5,myIndexDiff,8);
        int anIndex6 = rtrveBinOffSet(6,myIndexDiff,8);
        int anIndex7 = rtrveBinOffSet(7,myIndexDiff,8);
        
        double hogDiff0 = computeHogBinDiff(myHOG1, myHOG2, anIndex0, 0);
        double hogDiff1 = computeHogBinDiff(myHOG1, myHOG2, anIndex1, 1);
        double hogDiff2 = computeHogBinDiff(myHOG1, myHOG2, anIndex2, 2);
        double hogDiff3 = computeHogBinDiff(myHOG1, myHOG2, anIndex3, 3);
        double hogDiff4 = computeHogBinDiff(myHOG1, myHOG2, anIndex4, 4);
        double hogDiff5 = computeHogBinDiff(myHOG1, myHOG2, anIndex5, 5);
        double hogDiff6 = computeHogBinDiff(myHOG1, myHOG2, anIndex6, 6);
        double hogDiff7 = computeHogBinDiff(myHOG1, myHOG2, anIndex7, 7);
        
        double sumHOGDiff = hogDiff0 * hogDiff0 + hogDiff1 * hogDiff1 + hogDiff2 * hogDiff2 + hogDiff3 * hogDiff3
                + hogDiff4 * hogDiff4 + hogDiff5 * hogDiff5 + hogDiff6 * hogDiff6 + hogDiff7 * hogDiff7;        
        return sumHOGDiff;
    }    
    private static double computeHogBinDiff(CentroidHG myHOG1, CentroidHG myHOG2, int myIndex1, int myIndex2) {
        double hogDiff1 = myHOG1.getGrdntMagByIndex(myIndex1);
        double hogDiff2 = myHOG2.getGrdntMagByIndex(myIndex2);
        double hogDiff = hogDiff1 - hogDiff2;
        return hogDiff;
    }  
    private static double computeHogBinDiff2(CentroidHG myHOG1, CentroidHG myHOG2, int myIndex1, int myIndex2) {
        double hogDiff1 = myHOG1.getGrdntMagByIndex(myIndex1);
        double hogDiff2 = myHOG2.getGrdntMagByIndex(myIndex2);
        double hogDiff = hogDiff1 - hogDiff2;
        return hogDiff;
    }  
    static int computeHogBinIndexDiff(CentroidHG myHOG1, CentroidHG myHOG2) {
        int hog1MaxIndex = myHOG1.getMaxGradientBinIndex();
        int hog2MaxIndex = myHOG2.getMaxGradientBinIndex();
        int hogIndexDiff = hog2MaxIndex - hog1MaxIndex;
        return hogIndexDiff;
    }   
    static int computeHogBinIndexDiff2(CentroidHG myHOG1, CentroidHG myHOG2) {
        int hog1MaxIndex = myHOG1.getMaxGradientBinIndex();
        int hog2MaxIndex = myHOG2.getMaxGradientBinIndex();
        int hogIndexDiff = hog2MaxIndex - hog1MaxIndex;
        return hogIndexDiff;
    }    
    static int computeIndexDiffViaDstnce(CentroidHG myHOG1, CentroidHG myHOG2) {
        int hog1MaxIndex = myHOG1.rtrveGrdntIndexViaDstnce();
        int hog2MaxIndex = myHOG2.rtrveGrdntIndexViaDstnce();
        int hogIndexDiff = hog2MaxIndex - hog1MaxIndex;

        return hogIndexDiff;
    }    
    static int rtrveBinOffSet(int myIndex,int myIndexDiff,int myNumberBins){        
        int aTotal = myIndex + myIndexDiff;
        
        if(aTotal < 0){
            aTotal = myNumberBins + aTotal;
        }else if(aTotal >= myNumberBins){
            aTotal = aTotal - myNumberBins;
        }
        return aTotal;
    }
    static double compareHog1x1BinDiff(CentroidHG myHOG1[][], CentroidHG myHOG2[][]) {
        double hogDiff00 = compareBins8(myHOG1[0][0], myHOG2[0][0]);
        double sumSquaredHOGDiff = hogDiff00;        
        return sumSquaredHOGDiff;
    }    
    static double compareHog1x1BinDiff(CentroidHG myHOG1, CentroidHG myHOG2) {
        double hogDiff00 = compareBins8(myHOG1, myHOG2);
        double sumSquaredHOGDiff = hogDiff00;        
        return sumSquaredHOGDiff;
    }    
    int getAvgX() {
        return avgX;
    }

    void setAvgX(int xAvgPOs) {
        this.avgX = xAvgPOs;
    }

    int getAvgY() {
        return avgY;
    }

    void setAvgY(int yAvgPos) {
        this.avgY = yAvgPos;
    }
    int[] getCentroid(){
        return centroid;
    }
    double getMaxRealAngle(){
        return maxRealGrdntAngle;
    }
    int getTotalCount(){
       return totalCount;   
    }
    int getChrctrstcScale(){
        return getTotalCount();
    }
    private int getImageWidth(){
        return imageWidth;
    }
    private int getImageHeight(){
        return imageHeight;
    }
    double getTotalGradient(){
        return totalGradient;
    }

    double getMaxDstnce() {
        return maxDstnce;
    }

    void setMaxDstnce(double myMaxDstnce) {
        this.maxDstnce = myMaxDstnce;
    }

    double getMaxRealDstnceAngle() {
        return maxRealDstnceAngle;
    }

    void setMaxRealDstnceAngle(double myMaxRealDstnceAngle) {
        this.maxRealDstnceAngle = myMaxRealDstnceAngle;
    }
    
    double computeChrctrstcScale(int myWidth,int myHeight){       
        double aScaleCount = (10000.0)*(totalCount*numberOfBins)/(double)(myWidth*myHeight);        
        return aScaleCount;
    }
    static double cmpteTrnsltnDstnce(CentroidHG myCentroidHG1,CentroidHG myCentroidHG2){
        int centroid1[] = myCentroidHG1.getCentroid();
        int centroid2[] = myCentroidHG2.getCentroid();        
        
        double aDistance = PntTool.getDistance(centroid1[0], centroid1[1], centroid2[0], centroid2[1]);
        return aDistance;
    }
}