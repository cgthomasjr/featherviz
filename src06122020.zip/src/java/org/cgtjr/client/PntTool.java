package org.cgtjr.client;
/**
 *
 * @author clayton g thomas jr
 */
class PntTool {

    static float getDistance(float x1, float y1, float x2, float y2) {
        float distance = 0.0f;

        distance = (float) Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        //System.out.println("Point.getDistance(): x1="+x1+" x2 = "+x2+"y1="+y1+" y2 = "+y2+"z1="+z1+" z2 = "+z2);
        return distance;
    }

    static float getDistance(float x1, float y1, float z1, float x2, float y2, float z2) {
        float distance = 0.0f;
        distance = (float) Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1) + (z2 - z1) * (z2 - z1));
        //System.out.println("Point.getDistance(): x1="+x1+" x2 = "+x2+"y1="+y1+" y2 = "+y2+"z1="+z1+" z2 = "+z2);
        return distance;
    }

    static double getDistance(double x1, double y1, double z1, double x2, double y2, double z2) {
        double distance = 0.0;
        try {
            distance = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1) + (z2 - z1) * (z2 - z1));
            //System.out.println("Point.getDistance(): x1="+x1+" x2 = "+x2+"y1="+y1+" y2 = "+y2+"z1="+z1+" z2 = "+z2);
            return distance;
        } catch (ArithmeticException ae) {
            //System.out.println("Point.getDistance() : ArithmeticException" );
            return (float) Integer.MAX_VALUE;
        }
    }

    static double getDistance(double x1, double y1, double x2, double y2) {
        double distance = 0.0f;
        distance = (float) Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
        //System.out.println("Point.getDistance(): x1="+x1+" x2 = "+x2+"y1="+y1+" y2 = "+y2+"z1="+z1+" z2 = "+z2);
        return distance;
    }

    static boolean withinDistance(double x1, double y1, double z1, double x2, double y2, double z2, double myRadius) {
        boolean hasCollision = false;
        double distance = getDistance(x1, y1, z1, x2, y2, z2);
        if (distance <= myRadius) {
            hasCollision = true;
        }
        return hasCollision;
    }
}
