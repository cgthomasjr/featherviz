package org.cgtjr.client;

import java.util.ArrayList;

/**
 *
 * @author cgthomasjr
 */
class Kinematics {

    private double translation[];
    private double velocity[];
    private double accelleration[];
    private double postion[];
    
    private double rotation[];    
    private double rotationVlcty[];
    private double rotationAcclrtn[];
    private double rotationPstn[];
    
    private long time;
    
    private static ArrayList kinematicArrayList;
    
    Kinematics(){
        translation = new double[3];
        velocity = new double[3];
        accelleration = new double[3];
        rotation = new double[3];
        rotationVlcty = new double[3];
        rotationAcclrtn = new double[3];
        kinematicArrayList = new ArrayList();
    }
    double[] getTranslation() {
        return translation;
    }
    void setTranslation(double[] myTranslation) {
        this.translation = myTranslation;
    }

    double[] getVelocity() {
        return velocity;
    }

    void setVelocity(double[] myVelocity) {
        this.velocity = myVelocity;
    }

    double[] getAccelleration() {
        return accelleration;
    }

    void setAccelleration(double[] myAccelleration) {
        this.accelleration = myAccelleration;
    }

    double[] getRotation() {
        return rotation;
    }

    void setRotation(double[] rotation) {
        this.rotation = rotation;
    }

    double[] getRotationVlcty() {
        return rotationVlcty;
    }

    void setRotationVlcty(double[] myRotationVlcty) {
        this.rotationVlcty = myRotationVlcty;
    }

    double[] getRotationAcclrtn() {
        return rotationAcclrtn;
    }

    void setRotationAcclrtn(double[] myRotationAcclrtn) {
        this.rotationAcclrtn = myRotationAcclrtn;
    }
    void add(Object myObject){
        
        int aSize = kinematicArrayList.size();
        if(aSize < 100){
           kinematicArrayList.add(myObject);    
        }else{
           kinematicArrayList.remove(0);
           kinematicArrayList.add(myObject);   
        }       
    }
}