package org.cgtjr.client;

/**
 *
 * @author clayton g thomas jr
 */
import com.google.gwt.canvas.dom.client.ImageData;


interface FrameParserImgDta {

    void parse();

    void bgnFrames();

    void endFrames();

    void strtPrsng();

    void fnshPrsng();

    void setInputImage(ImageData anImage);
    void setOutputImage(ImageData anImage);

    ImageData getOutputImage();

    int getTopOffset();

    void setTopOffset(int startIndex);

    int getBottomOffset();

    void setBottomOffset(int stopIndex);
}