package org.cgtjr.client;

import com.google.gwt.canvas.dom.client.Context2d;
import com.google.gwt.canvas.dom.client.ImageData;
import com.google.gwt.dom.client.CanvasElement;
import com.google.gwt.dom.client.InputElement;
import com.google.gwt.user.client.DOM;


import java.util.ArrayList;

public class HOGClusterTrackPhoto {

    public HOGClusterTrackPhoto() {
    }
    public static void processData() {
        HOGClusterTrack aClusterTrackFltr = new HOGClusterTrack();
        aClusterTrackFltr.getClusterHOGTrackerTmp().setMaxClusterDistance(GOHParams.getClstrDstnce());
        aClusterTrackFltr.getCornerDetectGrdntTmp().setDisplayCorners(GOHParams.isDsplyCrnrs());
        aClusterTrackFltr.getClusterHOGTrackerTmp().setDisplayBoundary(GOHParams.isDsplyBndry());
        aClusterTrackFltr.getClusterHOGTrackerTmp().setDisplayHOG(GOHParams.isDsplyHOG());
        
        aClusterTrackFltr.getTmprlGrdntFilter().setTmprlGrdntThrshld(GOHParams.getTmprlGrdntThrshld());
        aClusterTrackFltr.getCornerDetectGrdntTmp().setEigenThreshold(GOHParams.getEgnThrshld());        
        
        ImageRndrrImgDta anImgRndrr;
        anImgRndrr = new ImageRndrrImgDta(aClusterTrackFltr);
        anImgRndrr.setStartOffset(0);
        anImgRndrr.setStopOffset(0);
        
        ArrayList anImgArryLst;
        anImgArryLst = new ArrayList();

        ImgPlyrCnvs anImgPlyrCnvs;

        anImgPlyrCnvs = new ImgPlyrCnvs(anImgArryLst);
        anImgPlyrCnvs.setRndrr(anImgRndrr);

        CanvasElement aCanvasElement1 = (CanvasElement) DOM.getElementById("canvasid1").cast();
        CanvasElement aCanvasElement2 = (CanvasElement) DOM.getElementById("canvasid2").cast();
        CanvasElement aCanvasElementOP = (CanvasElement) DOM.getElementById("canvasidop").cast();
        int aWidth = aCanvasElement1.getWidth();
        int aHeight = aCanvasElement1.getHeight();
        Context2d aContext2d1 = aCanvasElement1.getContext2d();
        Context2d aContext2d2 = aCanvasElement2.getContext2d();
        Context2d aContext2dOP = aCanvasElementOP.getContext2d();

        ImageData anImageData1 = aContext2d1.getImageData(0, 0, aWidth, aHeight);
        ImageData anImageData2 = aContext2d2.getImageData(0, 0, aWidth, aHeight);

        anImgArryLst.add(anImageData1);
        
        anImgPlyrCnvs.setOffScrnImg(aContext2dOP);
        //TODO: anImgArryLst should pass to process() instead of constructor
        anImgPlyrCnvs.process();
    }
    public static void insrtGOHPrmtrs(){
       InputElement anInputElement1 = (InputElement) DOM.getElementById("tmprlgrdntid").cast();
       InputElement anInputElement2 = (InputElement) DOM.getElementById("egnvlethrshldid").cast();       
       InputElement anInputElement3 = (InputElement) DOM.getElementById("clstrdstnceid").cast();              
       InputElement anInputElement4 = (InputElement) DOM.getElementById("objctdstnceid").cast();                     
       
       InputElement anInputElement5 = (InputElement) DOM.getElementById("dsplygrdntid").cast();
       InputElement anInputElement6 = (InputElement) DOM.getElementById("dsplycrnrsid").cast();        
       InputElement anInputElement7 = (InputElement) DOM.getElementById("dsplytrnsltnid").cast();               
       InputElement anInputElement8 = (InputElement) DOM.getElementById("dsplybndryid").cast();                          
       InputElement anInputElement9 = (InputElement) DOM.getElementById("dsplyhogid").cast();                          
       
       anInputElement1.setPropertyString("value",""+GOHParams.getTmprlGrdntThrshld());
       anInputElement2.setValue(""+GOHParams.getEgnThrshld());
       anInputElement3.setValue(""+GOHParams.getClstrDstnce());
       anInputElement4.setValue(""+GOHParams.getObjctDstnce());
       
       anInputElement5.setChecked(GOHParams.isDsplyGrdnts());
       anInputElement6.setChecked(GOHParams.isDsplyCrnrs());
       anInputElement7.setChecked(GOHParams.isDsplyTrnsltn());
       anInputElement8.setChecked(GOHParams.isDsplyBndry());
       anInputElement9.setChecked(GOHParams.isDsplyHOG());        
      
    }
    public static void updteGOHPrmtrs(){
       InputElement anInputElement1 = (InputElement) DOM.getElementById("tmprlgrdntid").cast();
       InputElement anInputElement2 = (InputElement) DOM.getElementById("egnvlethrshldid").cast();       
       InputElement anInputElement3 = (InputElement) DOM.getElementById("clstrdstnceid").cast();              
       InputElement anInputElement4 = (InputElement) DOM.getElementById("objctdstnceid").cast();  
       InputElement anInputElement10 = (InputElement) DOM.getElementById("id").cast();  
       
       
       InputElement anInputElement5 = (InputElement) DOM.getElementById("dsplygrdntid").cast();                            
       InputElement anInputElement6 = (InputElement) DOM.getElementById("dsplycrnrsid").cast();        
       InputElement anInputElement7 = (InputElement) DOM.getElementById("dsplytrnsltnid").cast();               
       InputElement anInputElement8 = (InputElement) DOM.getElementById("dsplybndryid").cast();                          
       InputElement anInputElement9 = (InputElement) DOM.getElementById("dsplyhogid").cast();          
       
       String tmprlGrdntVle = anInputElement1.getValue();
       String egnvleThrshldVle = anInputElement2.getValue();
       String clstrDstnceVle = anInputElement3.getValue();
       String objctDstnceVle = anInputElement4.getValue();
       String dsplyGrdntVle =  ""+anInputElement5.isChecked();
       String dsplyCrnrsVle =  ""+anInputElement6.isChecked();
       String dsplyTrnsltnVle =  ""+anInputElement7.isChecked(); 
       String dsplyBndryVle = ""+anInputElement8.isChecked();  
       String dsplyHOGVle =  ""+anInputElement9.isChecked();         
       
       int tmprlGrdnt = Integer.parseInt(tmprlGrdntVle);
       int egnvleThrshld = Integer.parseInt(egnvleThrshldVle);
       int clstrDstnce = Integer.parseInt(clstrDstnceVle);
       int objctDstnce = Integer.parseInt(objctDstnceVle);
       boolean dsplyGrdnt = Boolean.parseBoolean(dsplyGrdntVle);
       boolean dsplyCrnrs = Boolean.parseBoolean(dsplyCrnrsVle);
       boolean dsplyTrnsltn = Boolean.parseBoolean(dsplyTrnsltnVle); 
       boolean dsplyBndry = Boolean.parseBoolean(dsplyBndryVle);  
       boolean dsplyHOG = Boolean.parseBoolean(dsplyHOGVle);         
       
       GOHParams.setTmprlGrdntThrshld(tmprlGrdnt);
       GOHParams.setClstrDstnce(clstrDstnce);
       GOHParams.setEgnThrshld(egnvleThrshld);
       GOHParams.setObjctDstnce(objctDstnce);       
       GOHParams.setDsplyGrdnts(dsplyGrdnt);          
       GOHParams.setDsplyCrnrs(dsplyCrnrs);   
       GOHParams.setDsplyTrnsltn(dsplyTrnsltn);
       GOHParams.setDsplyBndry(dsplyBndry);       
       GOHParams.setDsplyHOG(dsplyHOG);         
    }
    public static void prcssSqunceData() {
        HOGClusterTrack aClusterTrackFltr = new HOGClusterTrack();
        aClusterTrackFltr.getClusterHOGTrackerTmp().setMaxClusterDistance(GOHParams.getClstrDstnce());
        aClusterTrackFltr.getCornerDetectGrdntTmp().setDisplayCorners(GOHParams.isDsplyCrnrs());
        aClusterTrackFltr.getClusterHOGTrackerTmp().setDisplayTrnsltn(GOHParams.isDsplyTrnsltn());
        aClusterTrackFltr.getCornerDetectGrdntTmp().setEigenThreshold(GOHParams.getObjctDstnce());        
        aClusterTrackFltr.getClusterHOGTrackerTmp().setDisplayHOG(GOHParams.isDsplyHOG());        
        
        ImageRndrrImgDta anImgRndrr;
        anImgRndrr = new ImageRndrrImgDta(aClusterTrackFltr);
        anImgRndrr.setStartOffset(0);
        anImgRndrr.setStopOffset(0);
        
        ArrayList anImgArryLst;
        anImgArryLst = new ArrayList();

        ImgPlyrCnvs anImgPlyrCnvs;
        anImgPlyrCnvs = new ImgPlyrCnvs(anImgArryLst);
        anImgPlyrCnvs.setRndrr(anImgRndrr);

        CanvasElement aCanvasElement1 = (CanvasElement) DOM.getElementById("canvasid1").cast();
        CanvasElement aCanvasElement2 = (CanvasElement) DOM.getElementById("canvasid2").cast();
        CanvasElement aCanvasElement3 = (CanvasElement) DOM.getElementById("canvasid3").cast();
        CanvasElement aCanvasElement4 = (CanvasElement) DOM.getElementById("canvasid4").cast();
        
        
        CanvasElement aCanvasElementOP = (CanvasElement) DOM.getElementById("canvasidop").cast();
        int aWidth = aCanvasElement1.getWidth();
        int aHeight = aCanvasElement1.getHeight();
        Context2d aContext2d1 = aCanvasElement1.getContext2d();
        Context2d aContext2d2 = aCanvasElement2.getContext2d();
        Context2d aContext2d3 = aCanvasElement3.getContext2d();
        Context2d aContext2d4 = aCanvasElement4.getContext2d();

        Context2d aContext2dOP = aCanvasElementOP.getContext2d();

        ImageData anImageData1 = aContext2d1.getImageData(0, 0, aWidth, aHeight);
        ImageData anImageData2 = aContext2d2.getImageData(0, 0, aWidth, aHeight);
        ImageData anImageData3 = aContext2d3.getImageData(0, 0, aWidth, aHeight);
        ImageData anImageData4 = aContext2d4.getImageData(0, 0, aWidth, aHeight);

        anImgArryLst.add(anImageData1);
        
        anImgArryLst.add(anImageData2);
        anImgArryLst.add(anImageData3);
        anImgArryLst.add(anImageData4);
        
        anImgPlyrCnvs.setOffScrnImg(aContext2dOP);
        anImgPlyrCnvs.process();
    }    
}
