package org.cgtjr.client;
/**
 *
 * @author cgthomasjr
 */
class DataArray {
    private int vData[];
    private int iWidth;
    private int iHeight;

    DataArray(){
    
    }
    DataArray(int mySize) {
        vData = new int[mySize];
    }
    void initialize(int mySize){
        vData = new int[mySize];
    }
    int[] getVData() {
        return vData;
    }

    void setVData(int[] myVData) {
        this.vData = myVData;
    }
    void setVData(int i,int myData)
    {
        this.vData[i] = myData;
    }

    int getIWidth() {
        return iWidth;
    }

    void setIWidth(int iWidth) {
        this.iWidth = iWidth;
    }

    int getIHeight() {
        return iHeight;
    }

    void setIHeight(int iHeight) {
        this.iHeight = iHeight;
    }
}