package org.cgtjr.client;

import com.google.gwt.canvas.dom.client.ImageData;
import java.util.ArrayList;

class ImgParserArrayList implements FrameParserImgDta//extends Filter //implements ImageObserver
{
    public static final String type = "ImageParser";
    private ImageData inputImage;
    private ImageData outputImage;
    private int rgbColors[];
    private int imageLength;
    private int imageWidth = 0;
    private int imageHeight = 0;
    private ImageFilter prsdImageFilter;
    private static boolean isInitialized;
    private int topOffset;
    private int bottomOffset;
    private int startOffSet;
    private int stopOffSet;
    private ArrayList rgbArrayList;

    public ImgParserArrayList(ImageData myInputImage, ImageFilter myImageFilter) {
        prsdImageFilter = myImageFilter;
        inputImage = myInputImage;
    }

    ImgParserArrayList(String fileName, ImageFilter myImageFilter) {
        prsdImageFilter = myImageFilter;
        //inputImage = UgotImage.createImage(fileName);
    }

    ImgParserArrayList(ImageFilter myImageFilter) {
        prsdImageFilter = myImageFilter;
        rgbArrayList = new ArrayList();
        System.out.println("ImgParser ... constructor");
    }

    public void setInputImage(ImageData anImage) {
        //System.out.println("ImgParser.setInputImage: width = "+anImage.getWidth(null));
        inputImage = anImage;
        rgbArrayList.add(anImage);
    }

    public void bgnFrames() {

    }

    public void parse() {
        int imgData[] = null;
        int myRGBColors[] = rgbColors;
        if (myRGBColors != null) {
            
            prsdImageFilter.initialize(imageWidth, imageHeight);
            prsdImageFilter.setImputPxlData(myRGBColors);
            for (int j = startOffSet; j < imageLength - stopOffSet; j++) {
                prsdImageFilter.filter(myRGBColors, j);
            }
            prsdImageFilter.finish();
            imgData = prsdImageFilter.getFltrdData();

            outputImage = UgotImage.createImageData(imgData, imageWidth, imageHeight, outputImage);
        } 
    }

    public ImageData getOutputImage() {
        return outputImage;
    }
    public void endFrames() {
    }
    public void fnshPrsng() {
    }

    public void strtPrsng() {
    }

    public int getTopOffset() {
        return topOffset;
    }

    public void setTopOffset(int startIndex) {
        this.topOffset = startIndex;
    }

    public int getBottomOffset() {
        return bottomOffset;
    }

    public void setBottomOffset(int stopIndex) {
        this.bottomOffset = stopIndex;
    }
    public boolean isEmptyList(){
        return rgbArrayList.isEmpty();
    }

    public void setOutputImage(ImageData anImage) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}