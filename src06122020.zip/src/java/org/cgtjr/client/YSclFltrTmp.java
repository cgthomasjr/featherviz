package org.cgtjr.client;
/**
 * The YSclFltrTmp (Gray Scale Filter) class is responsible for converting an 
 * an image to gray scale.  The rules require both width and height.  Currently 
 * 1x1, 3x3, and 5x5 block sizes are supported.  This approach has been
 * optimized to deal only with orthogonal regions. 
 * The class YSclFltrTmp provides encapsulation of the gray values
 * associated with the image.  The methods convert rgb images to
 * gray scale images using a 5x5 block size.  The original image array
 * remains the same.
 * @author clayton g thomas jr
 */
public class YSclFltrTmp extends ImageFilter {

    private int grayValues[];

    public YSclFltrTmp() {
    }    
    public void initialize(int myImageWidth, int myImageHeight) {
        super.initialize(myImageWidth, myImageHeight);
        this.intlzeYsclFltr(myImageWidth, myImageHeight);
    }
    private void intlzeYsclFltr(int myImageWidth, int myImageHeight){
        if(grayValues == null){
           grayValues = new int[myImageWidth*myImageHeight];
        }     
    }    
    public void filter5x5(int myOriginalValues[], int i) {
        super.filter(myOriginalValues, i);
        gryFltr5x5(myOriginalValues, i);
    }
    public void filter5x5(int myOriginalValues[]) {
        int aLength = myOriginalValues.length;   
        for(int j = 0;j<aLength;j++){
           super.filter(myOriginalValues, j);
           gryFltr5x5(myOriginalValues, j);
        }
    }
    public void filter3x3(int myOriginalValues[], int i) {
        gryFltr3x3(myOriginalValues, i);
    }
    public void gryFltr3x3(int myX, int myY) {
        int anIndex = rtrvIndex(myX, myY);
        gryFltr3x3(anIndex);
    }
    public void gryFltr3x3(int i) {
        gryFltr3x3(getInptPxlData(), i);
    }
    /**
     * The function converts a 3x3 block of rgb pixels values into
     * gray scale values.
     * @param originalValues
     * @param i 
     */    
    public void gryFltr3x3(int originalValues[], int i) {
        int imageWidth = getImageWidth();

        try{
            grayValues[i - imageWidth - 1] = (short)ColorSpectra.convertRGBToY(originalValues[i - imageWidth - 1]);
            grayValues[i - imageWidth] = (short)ColorSpectra.convertRGBToY(originalValues[i - imageWidth]);
            grayValues[i - imageWidth + 1] = (short)ColorSpectra.convertRGBToY(originalValues[i - imageWidth + 1]);
            grayValues[i - 1] = (short)ColorSpectra.convertRGBToY(originalValues[i - 1]);
            grayValues[i] = (short)ColorSpectra.convertRGBToY(originalValues[i]);
            grayValues[i + 1] = (short)ColorSpectra.convertRGBToY(originalValues[i + 1]);
            grayValues[i + imageWidth - 1] = (short)ColorSpectra.convertRGBToY(originalValues[i + imageWidth - 1]);
            grayValues[i + imageWidth] = (short)ColorSpectra.convertRGBToY(originalValues[i + imageWidth]);
            grayValues[i + imageWidth + 1] = (short)ColorSpectra.convertRGBToY(originalValues[i + imageWidth + 1]);
        }catch(ArrayIndexOutOfBoundsException aiobe){
            //aiobe.getMessage();
        }        
    }
    public int gryFltr1x1(int myOriginalValues[], int i) {             
        try {
            grayValues[i] = ColorSpectra.convertRGBToY(myOriginalValues[i]);
            getImageDrawData().updatePixels(grayValues, i);
        } catch (ArrayIndexOutOfBoundsException aiobe) {
            //aiobe.getMessage();
        }
        return grayValues[i];
    }
    public void filter(int myOriginalValues[]) { 
        gryFltr1x1(myOriginalValues);
    }
    public void gryFltr1x1(int myOriginalValues[]) {        
        int aLength = myOriginalValues.length;

        for(int j = 0;j<aLength;j++){
           gryFltr1x1(myOriginalValues, j);           
        }
    }
    /**
     * @deprecated 
     * @param originalValues
     * @param i 
     */
    public void gryFltr_5x5(int originalValues[], int i) {
        int imageWidth = getImageWidth();
        try {

            grayValues[i - 2 * imageWidth - 2] = (short)ColorSpectra.convertRGBToY(originalValues[i - 2 * imageWidth - 2]);
            grayValues[i - 2 * imageWidth - 1] = (short)ColorSpectra.convertRGBToY(originalValues[i - 2 * imageWidth - 1]);
            grayValues[i - 2 * imageWidth] = (short)ColorSpectra.convertRGBToY(originalValues[i - 2 * imageWidth]);
            grayValues[i - 2 * imageWidth + 1] = (short)ColorSpectra.convertRGBToY(originalValues[i - 2 * imageWidth + 1]);
            grayValues[i - 2 * imageWidth + 2] = (short)ColorSpectra.convertRGBToY(originalValues[i - 2 * imageWidth + 2]);

            grayValues[i - imageWidth - 2] = (short)ColorSpectra.convertRGBToY(originalValues[i - imageWidth - 2]);
            grayValues[i - imageWidth - 1] = (short)ColorSpectra.convertRGBToY(originalValues[i - imageWidth - 1]);
            grayValues[i - imageWidth] = (short)ColorSpectra.convertRGBToY(originalValues[i - imageWidth]);
            grayValues[i - imageWidth + 1] = (short)ColorSpectra.convertRGBToY(originalValues[i - imageWidth + 1]);
            grayValues[i - imageWidth + 2] = (short)ColorSpectra.convertRGBToY(originalValues[i - imageWidth + 2]);

            grayValues[i - 2] = (short)ColorSpectra.convertRGBToY(originalValues[i - 2]);
            grayValues[i - 1] = (short)ColorSpectra.convertRGBToY(originalValues[i - 1]);
            grayValues[i] = (short)ColorSpectra.convertRGBToY(originalValues[i]);
            grayValues[i + 1] = (short)ColorSpectra.convertRGBToY(originalValues[i + 1]);
            grayValues[i + 2] = (short)ColorSpectra.convertRGBToY(originalValues[i + 2]);

            grayValues[i + imageWidth - 2] = (short)ColorSpectra.convertRGBToY(originalValues[i + imageWidth - 2]);
            grayValues[i + imageWidth - 1] = (short)ColorSpectra.convertRGBToY(originalValues[i + imageWidth - 1]);
            grayValues[i + imageWidth] = (short)ColorSpectra.convertRGBToY(originalValues[i + imageWidth]);
            grayValues[i + imageWidth + 1] = (short)ColorSpectra.convertRGBToY(originalValues[i + imageWidth + 1]);
            grayValues[i + imageWidth + 2] = (short)ColorSpectra.convertRGBToY(originalValues[i + imageWidth + 2]);

            grayValues[i + 2 * imageWidth - 2] = (short)ColorSpectra.convertRGBToY(originalValues[i + 2 * imageWidth - 2]);
            grayValues[i + 2 * imageWidth - 1] = (short)ColorSpectra.convertRGBToY(originalValues[i + 2 * imageWidth - 1]);
            grayValues[i + 2 * imageWidth] = (short)ColorSpectra.convertRGBToY(originalValues[i + 2 * imageWidth]);
            grayValues[i + 2 * imageWidth + 1] = (short)ColorSpectra.convertRGBToY(originalValues[i + 2 * imageWidth + 1]);
            grayValues[i + 2 * imageWidth + 2] = (short)ColorSpectra.convertRGBToY(originalValues[i + 2 * imageWidth + 2]);
            //grayValues = originalValues;
            //System.out.println("ClrCnvrtFlter:grayValue = grayValues["+i+"]"+grayValues[i]);
        } catch (ArrayIndexOutOfBoundsException aiobe) {
        }
    } 
    public void gryFltr5x5(int originalValues[], int i) {
        int imageWidth = getImageWidth();
        try {
            for(int j=-2;j<=2;j++){
                for(int k=-2;k<=2;k++){
                   grayValues[i - j * imageWidth - k] = ColorSpectra.convertRGBToY(originalValues[i - j * imageWidth - k]);
                }
            }
        } catch (ArrayIndexOutOfBoundsException aiobe) {
        }
    }      
    public int[] rtrvFltrdData3x3(int myX, int myY) {
        return rtrvPixels3x3(myX, myY, grayValues);
    }
    /**
     * The function getGryVls returns an array of pixels with gray scale value.
     * @return 
     */    
    public int[] getGryVls() {
        return grayValues;
    }
    /**
     * The function getGryVls returns an integer pixel gray scale value.
     * @return 
     */    
    public int getGryVls(int myIndex) {
        return grayValues[myIndex];
    }    
    /**
     * @deprecated
     * @param myGryVls 
     */      
    public void setGry_Vls(int myGryVls[]) {
        
        grayValues = myGryVls;
    }
}