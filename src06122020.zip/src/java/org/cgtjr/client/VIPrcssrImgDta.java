package org.cgtjr.client;

import com.google.gwt.canvas.dom.client.Context2d;
import com.google.gwt.canvas.dom.client.ImageData;
import com.google.gwt.dom.client.CanvasElement;
import com.google.gwt.dom.client.VideoElement;
import com.google.gwt.user.client.DOM;
import com.google.gwt.user.client.Timer;

/**
 *
 * @author cgthomasjr
 */
class VIPrcssrImgDta {

    private FrameParserImgDta videoParser;    
    private HOGClusterTrack imageFilters;
    private VideoElement cv;
    private Context2d context;
    private Context2d backcontext;
    private int cw;
    private int ch;
    
    private VIPrcssrImgDta() {
        imageFilters = new HOGClusterTrack();

        imageFilters.getClusterHOGTrackerTmp().setMaxClusterDistance(GOHParams.getClstrDstnce());
        imageFilters.getClusterHOGTrackerTmp().setDisplayHOG(GOHParams.isDsplyHOG());
        imageFilters.getCornerDetectGrdntTmp().setDisplayCorners(GOHParams.isDsplyCrnrs());
        imageFilters.getClusterHOGTrackerTmp().setDisplayTrnsltn(GOHParams.isDsplyTrnsltn());
        imageFilters.getCornerDetectGrdntTmp().setEigenThreshold(GOHParams.getObjctDstnce());

        imageFilters.getTmprlGrdntFilter().setTmprlGrdntThrshld(GOHParams.getTmprlGrdntThrshld());

        videoParser = new ImgFrmeParserImgDta(imageFilters);     
    }

    ClusterHOGTrackerTmp rtrveClusterHOGTrackerTmp() {
        return imageFilters.getClusterHOGTrackerTmp();
    }

    static void startPrcssing() {
        final VIPrcssrImgDta aVIPrcssr = new VIPrcssrImgDta();

        aVIPrcssr.initializeData();
        Timer t = new Timer() {
            @Override
            public void run() {
                aVIPrcssr.processData();;
            }
        };
        t.scheduleRepeating(1);
    }

    private void initializeData() {
        CanvasElement canvas = DOM.getElementById("c").cast();
        VideoElement aCV = DOM.getElementById("v").cast();
        setCV(aCV);
        int aCW = aCV.getClientWidth();
        setCW(aCW);
        int aCH = aCV.getClientHeight();
        setCH(aCH);
        
        canvas.setWidth(aCW);
        canvas.setHeight(aCH);
        Context2d aContext = (Context2d) canvas.getContext("2d");
        setContext(aContext);
        
        CanvasElement back = DOM.getElementById("b").cast();
        Context2d aBackContext = (Context2d) back.getContext("2d");
        setBackcontext(aBackContext);
        back.setWidth(aCW);
        back.setHeight(aCH);
    }
    
    private boolean processData() {
        VideoElement myCV = getCV();
        if (myCV.isPaused()) {
            return false;
        }
        int aCW = getCW();
        int aCH = getCH();
        Context2d aBackContext = getBackContext();
        aBackContext.drawImage(myCV, 0, 0, aCW, aCH);
        ImageData idata = aBackContext.getImageData(0, 0, aCW, aCH);
        FrameParserImgDta aVideoParser = getVideoParser();
        aVideoParser.setInputImage(idata);
        aVideoParser.setOutputImage(idata);
        aVideoParser.bgnFrames();
        aVideoParser.parse();
        aVideoParser.endFrames();
        ImageData outputImage = aVideoParser.getOutputImage();
        Context2d aContext = getContext();
        aContext.putImageData(outputImage, 0, 0);
        return true;
    }

    int rtrveRectBndryCnt() {
        return imageFilters.getClusterHOGTrackerTmp().rtrveRectBndryCnt();
    }

    int rtrveCntrX(int myIndex) {
        return imageFilters.getClusterHOGTrackerTmp().rtrveCntrX(myIndex);
    }

    int rtrveCntrY(int myIndex) {
        return imageFilters.getClusterHOGTrackerTmp().rtrveCntrY(myIndex);
    }
    
    double rtrveCrdnteX(int i, int j) {
        return 0;
    }
    double rtrveCrdnteY(int i, int j) {

        return 0;
    }

    double rtrveCrdnteZ(int i, int j) {
        return 0;
    }

    VideoElement getCV() {
        return cv;
    }

    private void setCV(VideoElement cv) {
        this.cv = cv;
    }

    private Context2d getContext() {
        return context;
    }

    private void setContext(Context2d myContext) {
        this.context = myContext;
    }

    private Context2d getBackContext() {
        return backcontext;
    }

    private void setBackcontext(Context2d myBackContext) {
        this.backcontext = myBackContext;
    }

    private int getCW() {
        return cw;
    }

    private void setCW(int cw) {
        this.cw = cw;
    }

    private int getCH() {
        return ch;
    }

    private void setCH(int ch) {
        this.ch = ch;
    }
    private FrameParserImgDta getVideoParser() {
        return videoParser;
    }
    private void setVideoParser(FrameParserImgDta muVideoParser) {
        this.videoParser = muVideoParser;
    }    
}