package org.cgtjr.client;

import com.google.gwt.core.client.EntryPoint;


/**
 * Main entry point.
 *
 * @author cgthomasjr
 */
public class MainEntryPoint implements EntryPoint {

    /**
     * Creates a new instance of MainEntryPoint
     */
    public MainEntryPoint() {
    }

    /**
     * The entry point method, called automatically by loading a module that
     * declares an implementing class as an entry-point
     */
    
    public void onModuleLoad() {
        VIPrcssrImgDtaJS.loadVdoJS();
        HOGClusterTrackPhotoJS.insrtGOHPrmtrsJS();
        HOGClusterTrackPhotoJS.addUpdteBttnLstnr();        
        HOGClusterTrackPhotoJS.loadPhotoJS();
        HOGClusterTrackPhotoJS.loadSequenceJS();        
    }            
}