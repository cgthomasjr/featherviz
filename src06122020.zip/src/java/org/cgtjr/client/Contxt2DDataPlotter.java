package org.cgtjr.client;

import com.google.gwt.canvas.dom.client.Context2d;
import com.google.gwt.canvas.dom.client.CssColor;

import com.google.gwt.dom.client.CanvasElement;
import com.google.gwt.user.client.DOM;

/**
 *
 * @author cgthomasjr
 */
class Contxt2DDataPlotter //extends Canvas
{
    private double maxX;
    private double maxY;
    private double maxR;
    private double maxS;    
    private double xVel[];
    private double yVel[];    
    private double rVel[];
    private double sVel[];
    
    private double xVelAvg[];
    private double yVelAvg[];    
    private double rVelAvg[];
    private double sVelAvg[];    
    
    private int frameCnt;
    private int bufferSize = 700;
    
    public static Contxt2DDataPlotter dataPlotter;
    
    private Contxt2DDataPlotter(){
        xVel = new double[bufferSize];
        yVel = new double[bufferSize];
        rVel = new double[bufferSize];                       
        sVel = new double[bufferSize];
        
        xVelAvg = new double[bufferSize];
        yVelAvg = new double[bufferSize];
        rVelAvg = new double[bufferSize];                       
        sVelAvg = new double[bufferSize];                               

    }
    static Contxt2DDataPlotter getDataPlotter(){
        if(dataPlotter == null)
            dataPlotter = new Contxt2DDataPlotter();
        return dataPlotter;
    }
    void updateXVel(double myXVel){
        xVel[bufferSize-1] = myXVel;
        updateXVelAvg(xVel);
    }
    void updateYVel(double myYVel){        
        yVel[bufferSize-1] = myYVel;        
        updateYVelAvg(yVel);
    }
    void updateRVel(double myRVel){
        rVel[bufferSize-1] = myRVel;
        updateRVelAvg(rVel);
    }    
    void updateSVel(double mySVel){
        sVel[bufferSize-1] = mySVel;
        updateSVelAvg(sVel);
    }        
    private void updateXVelAvg(double myXVel[]){
        xVelAvg[bufferSize-1] = (myXVel[bufferSize-1]+
                                myXVel[bufferSize-2]+
                                myXVel[bufferSize-3])/3;
    }
    private void updateYVelAvg(double myYVel[]){        
        yVelAvg[bufferSize-1] = (myYVel[bufferSize-1]+
                                myYVel[bufferSize-2]+
                                myYVel[bufferSize-3])/3;        
    }
    private void updateRVelAvg(double myRVel[]){
        rVelAvg[bufferSize-1] = (myRVel[bufferSize-1]+
                                myRVel[bufferSize-2]+
                                myRVel[bufferSize-3])/3;
    }    
    private void updateSVelAvg(double mySVel[]){
        sVelAvg[bufferSize-1] = (mySVel[bufferSize-1]+
                                mySVel[bufferSize-2]+
                                mySVel[bufferSize-3])/3;        
    }    
    void repaint(){
        CanvasElement aCanvas = DOM.getElementById("plot_id").cast();
        Context2d aContext2d = aCanvas.getContext2d();
        paintPnts(aContext2d);
    }
    private void paintPnts(Context2d g){           
        double scale = 1;
        int rngeshft = 75;
        int domain1 = 0;
        int domain2 = 0;
        CanvasElement aCanvas = g.getCanvas();       
        g.clearRect(0,0,aCanvas.getWidth(),aCanvas.getHeight());
        for(int i=1;i<bufferSize;i++){            
           int r1 = (int)(scale*rVel[i-1])+rngeshft;
           int r2 = (int)(scale*rVel[i])+rngeshft;  
           g.setFillStyle("cyan");
           drawLine(g,"cyan",i-1,r1,i,r2);
            
           int x1 = (int)(scale*xVel[i-1])+rngeshft;
           int x2 = (int)(scale*xVel[i])+rngeshft;
           drawLine(g,"red",i-1,x1,i,x2);
           
           int y1 = (int)(scale*yVel[i-1])+rngeshft;
           int y2 = (int)(scale*yVel[i])+rngeshft;
           g.setFillStyle("green");
           drawLine(g,"green",i-1,y1,i,y2);

           xVel[i-1] = xVel[i];
           yVel[i-1] = yVel[i];
           rVel[i-1] = rVel[i];                      
           xVelAvg[i-1] = xVelAvg[i];
           yVelAvg[i-1] = yVelAvg[i];
           rVelAvg[i-1] = rVelAvg[i];                      
        }
    }
    private void drawLine(Context2d context1,String myColor,int x1,int y1, int x2, int y2){
       context1.beginPath();
       context1.setLineWidth(1);
       context1.setStrokeStyle(CssColor.make(myColor));
       context1.moveTo(x1,y1);
       context1.lineTo(x2,y2);
       context1.stroke();
       context1.closePath();       

    }
    private void shiftArrays(){
        for(int i=1;i<bufferSize;i++){
           xVel[i-1]= xVel[i];
           yVel[i-1]= yVel[i];
           rVel[i-1]= rVel[i];           
        }
    }
}