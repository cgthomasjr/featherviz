package org.cgtjr.client;

import com.google.gwt.canvas.dom.client.ImageData;

class ImgArryParser implements FrameParserImgDta
{

    private static final String type = "ImageParser";
    private ImageData inputImage;
    private ImageData outputImage;
    private int rgbColors[];
    private int imageLength;
    private int imageWidth = 0;
    private int imageHeight = 0;
    private ImageFilter prsdImageFilter;
    private static boolean isInitialized;
    private int topOffset;
    private int bottomOffset;
    private int startOffSet;
    private int stopOffSet;
    
    public ImgArryParser(ImageData myInputImage, ImageFilter myImageFilter) {
        prsdImageFilter = myImageFilter;
        inputImage = myInputImage;
    }

    public ImgArryParser(String fileName, ImageFilter myImageFilter) {
        prsdImageFilter = myImageFilter;
        //inputImage = UgotImage.createImage(fileName);
    }

    public ImgArryParser(ImageFilter myImageFilter) {
        prsdImageFilter = myImageFilter;
    }

    public void setInputImage(ImageData anImage) {
        inputImage = anImage;
    }

    public void bgnFrames() {
        if (isInitialized == true) {
            return;
        }
        
        imageWidth = 0;
        imageHeight = 0;
        int transparency = 0;

        if (inputImage != null) {
            imageWidth = inputImage.getWidth();
            imageHeight = inputImage.getHeight();
            int c = 0;
            //System.out.println("ImageParser: test a = ");
            while (imageWidth <= 1 || imageHeight <= 1) {                
                imageWidth = inputImage.getWidth();
                imageHeight = inputImage.getHeight();
                assert (imageWidth > 1 && imageHeight > 1) :
                "ImageArryParser: err c = "+c;
                c++;                
            }
            rgbColors = new int[imageWidth * imageHeight];
            imageLength = imageWidth * imageHeight;
        }
        startOffSet = topOffset*imageWidth;
        stopOffSet = bottomOffset*imageWidth;
        UgotImage.handlepixels(inputImage, 0, 0, imageWidth, imageHeight, rgbColors);
    }

    public void parse() {

        prsdImageFilter.initialize(imageWidth, imageHeight);
        prsdImageFilter.setImputPxlData(rgbColors);

            prsdImageFilter.filter(rgbColors,0);
        prsdImageFilter.finish();
        int imgData[] = prsdImageFilter.getFltrdData();
        outputImage = UgotImage.createImageData(imgData, imageWidth, imageHeight, inputImage);
    }

    public void setOutputImage(ImageData anImage) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public ImageData getOutputImage() {
        return outputImage;
    }

    public void endFrames() {
    }

    public void fnshPrsng() {
    }

    public void strtPrsng() {
    }

    public int getTopOffset() {
        return topOffset;
    }

    public void setTopOffset(int startIndex) {
        this.topOffset = startIndex;
    }

    public int getBottomOffset() {
        return bottomOffset;
    }

    public void setBottomOffset(int stopIndex) {
        this.bottomOffset = stopIndex;
    }    
}