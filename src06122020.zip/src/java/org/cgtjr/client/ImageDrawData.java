package org.cgtjr.client;
/**
 * 
 * @author cgthomasjr
 */
class ImageDrawData {

    private boolean isPixelDrawn[];
    private int imagePixels[];
    private int bgPixelColor;
    private int reservedColor1;
    private int reservedColor2;
    private int reservedColor3;
    private int reservedColor4;
    private int imageWidth;
    private int imageHeight;

    ImageDrawData(int myWidth, int myHeight) {
        imageWidth = myWidth;
        imageHeight = myHeight;
        imagePixels = new int[myWidth * myHeight];
        bgPixelColor = 0x00000000;
        reservedColor1 = 0xf1234567;
        reservedColor2 = 0xf1234567;
        reservedColor3 = 0xf1234567;
        reservedColor4 = 0xf1234567;
    }

    void updatePixels(int myImagePixels[], int myIndex) {
            imagePixels[myIndex] = myImagePixels[myIndex];     
    }

    void updatePixels(int myImagePixels[], int myX, int myY, int myWidth1, int myWidth2) {
        int index1 = ImageTool.rtrvIndex(myX, myY, myWidth1);
        int index2 = ImageTool.rtrvIndex(myX, myY, myWidth2);
        if (myX >= 0 && myY >= 0 && myX < imageWidth && myY < imageHeight && imagePixels[index1] == bgPixelColor) {
            imagePixels[index1] = myImagePixels[index2];
        }
    }

    void drawData(int myColor, int myIndex) {
        try {
            imagePixels[myIndex] = myColor;
        } catch (java.lang.ArrayIndexOutOfBoundsException aiobe) {
            //System.out.println(aiobe.getMessage());
        }
    }

    void drawData(int myColor, int myX, int myY) {
        if (myX >= 0 && myY >= 0 && myX < imageWidth && myY < imageHeight) {
        int anIndex = ImageTool.rtrvIndex(myX, myY, imageWidth);
            try {
                imagePixels[anIndex] = myColor;
            } catch (java.lang.ArrayIndexOutOfBoundsException aiobe) {
                //System.out.println(aiobe.getMessage());
            }
        }
    }

    void drawData(int myColor, int myX, int myY, int myWidth) {
        if (myX >= 0 && myY >= 0 && myX < imageWidth && myY < imageHeight) {
            int anIndex = ImageTool.rtrvIndex(myX, myY, imageWidth);
            try {
                imagePixels[anIndex] = myColor;
            } catch (java.lang.ArrayIndexOutOfBoundsException aiobe) {
                //System.out.println(aiobe.getMessage());
            }
        }
    }

    void drawDataViaCondition(int myColor, int myIndex) {
        try {
            if (imagePixels[myIndex] != reservedColor1
                    && imagePixels[myIndex] != reservedColor2 && imagePixels[myIndex] != reservedColor3
                    && imagePixels[myIndex] != reservedColor4) {

                imagePixels[myIndex] = myColor;
            }
        } catch (java.lang.ArrayIndexOutOfBoundsException aiobe) {
            //System.out.println(aiobe.getMessage());
        }
    }

    int getReservedColor1() {
        return reservedColor1;
    }

    void setReservedColor1(int reservedColor1) {
        this.reservedColor1 = reservedColor1;
    }

    int getReservedColor2() {
        return reservedColor2;
    }

    void setReservedColor2(int reservedColor2) {
        this.reservedColor2 = reservedColor2;
    }

    int getReservedColor3() {
        return reservedColor3;
    }

    void setReservedColor3(int reservedColor3) {
        this.reservedColor3 = reservedColor3;
    }

    int getReservedColor4() {
        return reservedColor4;
    }

    void setReservedColor4(int reservedColor4) {
        this.reservedColor4 = reservedColor4;
    }

    void setPixelColor(int myColor) {
        bgPixelColor = myColor;
    }

    int getPixelColor() {
        return bgPixelColor;
    }

    int[] getImagePixels() {
        return imagePixels;
    }
}