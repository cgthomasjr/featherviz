package org.cgtjr.client;
/**
 * 
 * @author cgthomasjr
 */
class CentroidHGPstn {
    private CentroidHG centroidHG;
    private int positionIndex = 0;
    private double x;
    private double y;
    private CentroidHGPstn matchedHOGPosition;
    private int gridID;
    private Object trackBoundary;

    CentroidHGPstn(CentroidHG histogram, int myX,int myY) {
        this.centroidHG = histogram;
        int aX =  myX;
        int aY =  myY;        
        setX(aX);
        setY(aY);
    }    
    
    CentroidHGPstn(CentroidHG histogram, int positionIndex) {
        this.centroidHG = histogram;
        this.positionIndex = positionIndex;
    }
    CentroidHGPstn(double myX,double myY) {
        this.centroidHG = new CentroidHG(); 
        setX(myX);
        setY(myY);                
    }    

    CentroidHGPstn() {
        this.centroidHG = new CentroidHG(); 
    }    
    CentroidHGPstn(double myX,double myY,int myImageWidth,int myImageHeight) {
        this.centroidHG = new CentroidHG(myImageWidth,myImageHeight);      
        setX(myX);
        setY(myY);                
    }    

    CentroidHGPstn(int myImageWidth,int myImageHeight) {
        this.centroidHG = new CentroidHG(); 
    }     
    Object getTrackBoundary() {
        return trackBoundary;
    }

    void setTrackBoundary(Object myTrackBoundary) {
        this.trackBoundary = myTrackBoundary;
    }
    
    int getGridID() {
        return gridID;
    }
    void setGridID(int myGridID) {
        this.gridID = myGridID;
    }    
    void connectHOGMatch(CentroidHGPstn myHOGPosition){
        matchedHOGPosition = myHOGPosition;
    }
    CentroidHGPstn rtrveHOGMatch(){
        return matchedHOGPosition;
    }
   
    double getX() {
        return x;
    }
    void setX(double aX) {
        this.x = aX;
    }
    double getY() {
        return y;
    }
    void setY(double aY) {
        this.y = aY;
    }
    CentroidHG getCentroidHG() {
        return centroidHG;
    }
    void setCentroidHG(CentroidHG histogram) {
        this.centroidHG = histogram;
    }

    int getPositionIndex() {
        return positionIndex;
    }
    void setPositionIndex(int positionIndex) {
        this.positionIndex = positionIndex;
    }
    static double cmpteTrnsltnDstnce(CentroidHGPstn myHOGPosition1, CentroidHGPstn myHOGPosition2,int myImageWidth) {
        int anImageWidth = myImageWidth;
        int anIndex1 = myHOGPosition1.getPositionIndex();
        int anIndex2 = myHOGPosition2.getPositionIndex();
        int x1 = ImageTool.rtrvXPstn(anIndex1, anImageWidth);
        int y1 = ImageTool.rtrvYPstn(anIndex1, anImageWidth);
        int x2 = ImageTool.rtrvXPstn(anIndex2, anImageWidth);
        int y2 = ImageTool.rtrvYPstn(anIndex2, anImageWidth);
        double aDistance = PntTool.getDistance(x1, y1, x2, y2);
        return aDistance;
    }
    void addCentroidHG(CentroidHGPstn myHOGPosition){
        CentroidHG aCentroidHG = myHOGPosition.getCentroidHG();
    }
    void updateCentroid(CentroidHGPstn myHOGPosition){
        CentroidHG aCentroidHG = myHOGPosition.getCentroidHG();
    }    
    void updateCentroid(CentroidHG myCentroidHG){
        CentroidHG aCentroidHG = myCentroidHG;
    }
    void updateCentroid(HOGPosition myHOGPosition){
        centroidHG.updateCentroid(myHOGPosition);
    }   
    public String toString() {
        return getClass().getName() + ", histogram=" + centroidHG + ", positionIndex=" + positionIndex + '}';
    }    
}