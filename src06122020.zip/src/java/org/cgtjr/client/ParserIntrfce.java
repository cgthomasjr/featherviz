package org.cgtjr.client;
/**
 *
 * @author cgthomasjr
 */
interface ParserIntrfce {
    void setParser(FrameParserImgDta myParser);
}