package org.cgtjr.client;


class Line extends AngleLine
{
   Line()
   {
      super();
   }
   Line(float xPos, float yPos,float zPos)
   {      
      super(xPos,yPos,zPos);
   }
}