package org.cgtjr.client;

/**
 *
 * @author cgthomasjr
 */
public class JSOGBndry {    
    native void crteJSArray() /*-{
       var aLength = this.@cgtjr.academics.dsktpgui.awtswng.client.JSQuadElmnts::rtrvSize()();
       $wnd.alert("crteJSArray(): array length = "+aLength);
       function JSPnt() {x=0;y=0;z=0;}
       var i = 0;
       var j = 0;
       var elmnts = new Array();
       for(i = 0;i<aLength;i++)
       {
            elmnts[i] = new Array();
            for(j=0;j<4;j++)
            {
               aJSPnt = new JSPnt(); 
              
               aJSPnt.x = this.@cgtjr.academics.dsktpgui.awtswng.client.JSQuadElmnts::rtrveCrdnteX(II)(i,j);
               aJSPnt.y = this.@cgtjr.academics.dsktpgui.awtswng.client.JSQuadElmnts::rtrveCrdnteY(II)(i,j);
               aJSPnt.z = this.@cgtjr.academics.dsktpgui.awtswng.client.JSQuadElmnts::rtrveCrdnteZ(II)(i,j);
               elmnts[i][j] = aJSPnt;
            }
       }
       $wnd.alert("JSQuadElmnts test, length ="+elmnts.length);
       $doc.main3(elmnts);       
    }-*/;    
}