package org.cgtjr.client;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

/**
 * The ClusterHOGTrackerTmp class creates oriented gradients from clusters.
 * A cluster is a group of feature points within the same boundary. A list of 
 * oriented gradients and clusters are stored in corresponding data structures.
 *
 * @author clayton g thomas jr
 */
public class ClusterHOGTrackerTmp {

    private final int colorList[] = {0x774F38, 0xF1D4AF, 0x1A2611, 0x000000ff, 0x00ff0000, 0x0000ff00, 0x00ff00ff, 0x00ffff00, 0x0000ffff, 0x00ff4000, 0x0000ff40, 0x004000ff};
    private ImageDrawData imagePixelData;
    private double clusterMaxDistance = 5;
    private int trackerID;
        
    private TreeMap aTreeMap;
    private TreeMap globalHogTreeMapPast;

    private boolean displayDigit = false;
    private boolean isAnnotateOn = false;
    private boolean displayBoundary = true;
    private boolean displayHOG;
    private boolean displayTrnsltn;
    
    private CornerDetectGrdntTmp cornerDetectGrdntTmp;
    private TmprlGrdntFltrTmp tmprlGrdntFltrTmp;
    private YSclFltrTmp ySclFltrTmp;
    private GrdntFilterParserTmp grdntFilterParser;
    private HOGCornerDetectorTmp hogCornerDetectorTmp;
    
    /**
     * The constructor ClusterHOGTrackerTmp requires a data structure containing
     * local oriented gradients which are associated with corner features. 
     * @param myHOGCornerDetectorTmp 
     */
    public ClusterHOGTrackerTmp(HOGCornerDetectorTmp myHOGCornerDetectorTmp) {
        hogCornerDetectorTmp = myHOGCornerDetectorTmp;
        cornerDetectGrdntTmp = hogCornerDetectorTmp.getCornerDetectGrdntTmp();
        ySclFltrTmp = cornerDetectGrdntTmp.getySclFltrTmp();
        grdntFilterParser = cornerDetectGrdntTmp.getGrdntFilterParser();
        tmprlGrdntFltrTmp = cornerDetectGrdntTmp.getTmprlGrdntFltrTmp();
    }

    public void initialize(int myImageWidth, int myImageHeight) {
        aTreeMap = new TreeMap();
        imagePixelData = ySclFltrTmp.getImageDrawData();
    }
    /**
     * The filter function is responsible for processing the the
     * corner features into clusters.  
     * @param dataValues - the parameter is an integer array containing pixel data
     * @param i - this parameter is the integer index number for the array.
     */
    public void filter(int dataValues[], int i) {
        clusterHOG(dataValues, i);
    }
    /**
     * The filter function is responsible for processing the the
     * corner features into clusters.  
     * @param myDataValues 
     */
    public void filter(int myDataValues[]) {
        int aLength = myDataValues.length;
        for (int i = 0; i < aLength; i++) {
            clusterHOG(myDataValues, i);
        }
        displayData();
    }
    /**
     * The clusterHOG function is responsible for processing the the
     * corner features into clusters.  
     * @param dataValues - the parameter is an integer array containing pixel data
     * @param i - this parameter is the integer index number for the array.
     */
    public void clusterHOG(int dataValues[], int i) {
        if (cornerDetectGrdntTmp.getEigenValue(i) >= cornerDetectGrdntTmp.getEigenThreshold() && tmprlGrdntFltrTmp.getTemporalGradientValues(i) > tmprlGrdntFltrTmp.getTmprlGrdntThrshld()) {
            insertHOG(i);
        }
    }

    public double getClusterMaxDistance() {
        return clusterMaxDistance;
    }

    public void setMaxClusterDistance(double myClusterMaxDistance) {
        this.clusterMaxDistance = myClusterMaxDistance;
    }

    public boolean getDisplayDigit() {
        return displayDigit;
    }

    public boolean getIsAnnotateOn() {
        return isAnnotateOn;
    }

    public void setIsAnnotateOn(boolean myIsAnnotateOn) {
        this.isAnnotateOn = myIsAnnotateOn;
    }

    public void setDisplayDigit(boolean myDisplayDigit) {
        this.displayDigit = myDisplayDigit;
    }

    private void insertHOG(int i) {
        int x = ySclFltrTmp.rtrvXPstn(i);
        int y = ySclFltrTmp.rtrvYPstn(i);
        HOGPosition aHOGPosition = hogCornerDetectorTmp.getHOGPosition(i);
        aHOGPosition.setX(x);
        aHOGPosition.setY(y);
        insertHOG(aHOGPosition);
    }

    private void insertHOG(HOGPosition myHOGPosition) {
        RectBndryGlblHOGTree aRectBndryHOGArrayList = null;
        Set aSet = aTreeMap.keySet();
        RectBndryGlblHOGTree tmpRectBndryHOGArrayList = null;
        boolean isInDstnce = false;

        if (aSet.isEmpty()) {
            aRectBndryHOGArrayList = new RectBndryGlblHOGTree(myHOGPosition, ySclFltrTmp.getImageWidth(), ySclFltrTmp.getImageHeight());
            Integer anIteger = new Integer(trackerID);
            aRectBndryHOGArrayList.setBoundaryID(trackerID);

            int colorIndex = trackerID % (colorList.length);
            int aColor = colorList[colorIndex];
            aRectBndryHOGArrayList.setColor(aColor);
            aTreeMap.put(anIteger, aRectBndryHOGArrayList);
            isInDstnce = true;
            trackerID++;
            return;
        } else {
            Iterator anIterator = aSet.iterator();
            try {
                while (anIterator.hasNext()) {
                    Integer aGroupKey = (Integer) anIterator.next();
                    aRectBndryHOGArrayList = (RectBndryGlblHOGTree) aTreeMap.get(aGroupKey);
                    isInDstnce = isInDistance(aRectBndryHOGArrayList, myHOGPosition);
                    if (aRectBndryHOGArrayList != null && isInDstnce == true) {
                        //ConsoleLabel.printInfo("InDistance : " + ImageFilter.frameIndex + ". aTreeMap hasNext = " + aTreeMap.keySet().iterator().hasNext());
                        if (tmpRectBndryHOGArrayList == null) {
                            aRectBndryHOGArrayList.add(myHOGPosition);
                            tmpRectBndryHOGArrayList = aRectBndryHOGArrayList;
                        } else {
                            tmpRectBndryHOGArrayList.mergeBndry(aRectBndryHOGArrayList);
                            aTreeMap.remove(aGroupKey);
                        }
                        isInDstnce = false;
                    }
                }
            } catch (java.util.ConcurrentModificationException cme) {
                //System.err.println(getClass().getName()+" ," + cme.getMessage());
            }
        }
        if (tmpRectBndryHOGArrayList == null) {
            Integer aLastKey = (Integer) aTreeMap.lastKey();
            aRectBndryHOGArrayList = new RectBndryGlblHOGTree(myHOGPosition, ySclFltrTmp.getImageWidth(), ySclFltrTmp.getImageHeight());
            Integer anIteger = new Integer(trackerID);
            aRectBndryHOGArrayList.setBoundaryID(trackerID);

            int colorIndex = trackerID % (colorList.length);
            int aColor = colorList[colorIndex];
            aRectBndryHOGArrayList.setColor(aColor);

            aTreeMap.put(anIteger, aRectBndryHOGArrayList);
            trackerID++;

        }
        //TODO: create parameter and constant for max ID ...
        if (trackerID >= 19900) {
            trackerID = 0;
        }

        AltBufferTreeMap.setAltBuffer(aTreeMap);
    }

    /**
     * @deprecated @param myRectBndryGlblHOGTree1
     * @param myRectBndryGlblHOGTree2
     */
    private void mergeBoundaries(RectBndryGlblHOGTree myRectBndryGlblHOGTree1, RectBndryGlblHOGTree myRectBndryGlblHOGTree2) {
        /*
         Consider checking size prior to merge
         myRectBndryGlblHOGTree1.size();
         myRectBndryGlblHOGTree2.size();
         */
    }

    private boolean isInDistance(RectBndryGlblHOGTree myRectBndryHOGArrayList, HOGPosition myHOGPosition) {
        HOGPosition aHOGPosition = null;
        Iterator anIterator = myRectBndryHOGArrayList.iterator();
        while (anIterator.hasNext()) {
            aHOGPosition = (HOGPosition) anIterator.next();
            if (isInDistance(aHOGPosition, myHOGPosition)) {
                return true;
            }
        }
        return false;
    }

    private boolean isInDistance(RectBndryGlblHOGTree myRectBndryHOGArrayList, Point aPoint2) {
        Point aPoint = null;
        Iterator anIterator = myRectBndryHOGArrayList.iterator();
        while (anIterator.hasNext()) {
            aPoint = (Point) anIterator.next();
            if (isInDistance(aPoint, aPoint2)) {
                return true;
            }
        }
        return false;
    }

    private boolean isInAvrgeDistance(RectBndryGlblHOGTree myRectBndryHOGArrayList, Point aPoint2) {
        int xAvg = myRectBndryHOGArrayList.getXAvg();
        int yAvg = myRectBndryHOGArrayList.getYAvg();
        Point aPoint = new Point(xAvg, yAvg);

        if (isInDistance(aPoint, aPoint2)) {
            return true;
        }
        return false;
    }

    private boolean isInAvrgeDistance(RectBndryGlblHOGTree myRectBndryHOGArrayList, HOGPosition aHOGPosition2) {
        int xAvg = myRectBndryHOGArrayList.getXAvg();
        int yAvg = myRectBndryHOGArrayList.getYAvg();
        Point aPoint = new Point(xAvg, yAvg);

        if (isInDistance(aPoint, aHOGPosition2)) {
            return true;
        }
        return false;
    }

    private boolean isInDistance(Point aPoint1, Point aPoint2) {
        boolean inDistance = false;
        double dx = aPoint2.getX() - aPoint1.getX();
        double dy = aPoint2.getY() - aPoint1.getY();
        double aDistance = Math.sqrt(dx * dx + dy * dy);

        if (aDistance <= clusterMaxDistance) {
            inDistance = true;
        }
        return inDistance;
    }

    private boolean isInDistance(Point aPoint1, HOGPosition aHOGPosition2) {
        boolean inDistance = false;
        double dx = aHOGPosition2.getX() - aPoint1.getX();
        double dy = aHOGPosition2.getY() - aPoint1.getY();
        double aDistance = Math.sqrt(dx * dx + dy * dy);

        if (aDistance <= clusterMaxDistance) {
            inDistance = true;
        }
        return inDistance;
    }

    private boolean isInDistance(HOGPosition aHOGPosition1, HOGPosition aHOGPosition2) {
        boolean inDistance = false;
        double dx = aHOGPosition2.getX() - aHOGPosition1.getX();
        double dy = aHOGPosition2.getY() - aHOGPosition1.getY();
        double aDistance = Math.sqrt(dx * dx + dy * dy);

        if (aDistance <= clusterMaxDistance) {
            inDistance = true;
        }
        return inDistance;
    }

    private void displayData() {
        int anImageWidth = ySclFltrTmp.getImageWidth();
        int anImageHeight = ySclFltrTmp.getImageHeight();

        RectBndryGlblHOGTree aRectBndryHOGArrayList = null;

        Set aSet = aTreeMap.keySet();

        Iterator anIterator1 = aSet.iterator();
       
        Integer aGroupKey = null;

        int myPixelData[] = imagePixelData.getImagePixels();

        while (anIterator1.hasNext()) {
            aGroupKey = (Integer) anIterator1.next();

            aRectBndryHOGArrayList = (RectBndryGlblHOGTree) aTreeMap.get(aGroupKey);

            boolean aBndrySizeChck = aRectBndryHOGArrayList.bndrySizeCheck(aRectBndryHOGArrayList.getMinWidth(), aRectBndryHOGArrayList.getMinHeight());

            if (aBndrySizeChck == true) {
                aRectBndryHOGArrayList.updataCentroidHG();

                drawCentroidPnt(aRectBndryHOGArrayList);

                drawCentroidHG(aRectBndryHOGArrayList);
                drawHOG(aRectBndryHOGArrayList);                
                drawBoundary(aRectBndryHOGArrayList);
                
                globalHogTreeMapPast = AltBufferTreeMap.getAltBuffer();
                aRectBndryHOGArrayList.updateTrackIDViaGlblHOG(globalHogTreeMapPast, anImageWidth, anImageHeight);
                drawGlblHOGTrnsltn(aRectBndryHOGArrayList);
                
                plotData(aRectBndryHOGArrayList);
            }

        }
    }

    private void drawCentroidPnt(RectBndryGlblHOGTree myRectBndryHOGArrayList) {
        int anImageWidth = ySclFltrTmp.getImageWidth();
        int myPixelData[] = imagePixelData.getImagePixels();
        if (false) {
            myRectBndryHOGArrayList.drawCentroidPnt(myPixelData, anImageWidth, 0x00454857);
        }
    }

    private void drawGlblHOGTrnsltn(RectBndryGlblHOGTree myRectBndryHOGArrayList) {
        int anImageWidth = ySclFltrTmp.getImageWidth();
        int anImageHeight = ySclFltrTmp.getImageHeight();
        int myPixelData[] = imagePixelData.getImagePixels();

        if (displayTrnsltn == true) {
            myRectBndryHOGArrayList.drawGlblHOGTrnsltn(myPixelData, anImageWidth, anImageHeight, 0x008F002E);
        }
    }

    public void setDisplayTrnsltn(boolean displayTrnsltn) {
        this.displayTrnsltn = displayTrnsltn;
    }

    private AnnotateFeatureVar rtrveAnntteFtreVar(String myDate, int myFrameNumber, int myWidth, int myHeight, int myIDNmbr, int myXMin, int myYMin, int myXMax, int myYMax, double myChrctrstcScle, double myTrnsltnMgntde, double myTrnsltnPhase, double myRotationAngle, String myDescription) {
        AnnotateFeatureVar theAnnotationBoxVar = new AnnotateFeatureVar();

        int frameNumber = ySclFltrTmp.getFrameIndex();
        //theAnnotationBoxVar.setUserLogonIdValue(ThemeSet.getUserLogonIdValue());
        theAnnotationBoxVar.setDateTimeValue(myDate);
        theAnnotationBoxVar.setFrameNumberValue("" + myFrameNumber);
        theAnnotationBoxVar.setWidthValue("" + myWidth);
        theAnnotationBoxVar.setHeightValue("" + myHeight);
        theAnnotationBoxVar.setTrackNumberValue("" + myIDNmbr);
        theAnnotationBoxVar.setXMinCoordValue("" + myXMin);
        theAnnotationBoxVar.setYMinCoordValue("" + myYMin);
        theAnnotationBoxVar.setYMinCoordValue("0");
        theAnnotationBoxVar.setXMaxCoordValue("" + myXMax);
        theAnnotationBoxVar.setYMaxCoordValue("" + myYMax);
        theAnnotationBoxVar.setZMaxCoordValue("0");
        theAnnotationBoxVar.setDescriptionValue("" + myDescription);
        theAnnotationBoxVar.setChrctrstcScaleValue("" + myChrctrstcScle);
        theAnnotationBoxVar.setTrnsltnMgntdeValue("" + myTrnsltnMgntde);
        theAnnotationBoxVar.setTrnsltnPhaseValue("" + myTrnsltnPhase);
        theAnnotationBoxVar.setRotationAngleValue("" + myRotationAngle);

        //theAnnotationBoxVar.setObjectHeightValue(""+myObjectHeight);
        //theAnnotationBoxVar.setObjectWidthValue(""+myObjectWidth);        
        theAnnotationBoxVar.setUrlValue("localhost");
        return theAnnotationBoxVar;
    }

    private void drawHOG(RectBndryGlblHOGTree aRectBndryGlblHOGTree) {
        if (isDisplayHOG() == false) {
            return;
        }
        HOGPosition myHOGPosition = aRectBndryGlblHOGTree.getCntrHOGPosition();
        HistogramOG aHOG[][] = myHOGPosition.getHog();

        if (aHOG == null || aHOG[0][0] == null) {
            return;
        }

        int myPixelData[] = imagePixelData.getImagePixels();
        int aWidth = ySclFltrTmp.getImageWidth();
        int aHeight = ySclFltrTmp.getImageHeight();

        int xPos1 = (int) myHOGPosition.getX();
        int yPos1 = (int) myHOGPosition.getY();
        int binSize = aHOG[0][0].getNumberOfBins();
        float maxGrdnt = (float) aHOG[0][0].getMaxGradient();
        int rectLength = aRectBndryGlblHOGTree.getMaxLength();

        for (int i = 0; i < binSize; i++) {
            double angle = aHOG[0][0].getAngleByIndex(i);
            double gradient = aHOG[0][0].getGradientByIndex(i);

            float xPos2 = xPos1 + (float) (gradient * Math.cos(angle)) * rectLength / maxGrdnt;
            float yPos2 = yPos1 + (float) (gradient * Math.sin(angle)) * rectLength / maxGrdnt;
       
            LineCrtr.drawLine(xPos1, yPos1, xPos2, yPos2, myPixelData, aWidth, aHeight, 0x000000ff, 0x000000ff);
        }
    }

    private void drawBoundary(RectBndryGlblHOGTree aRectBndryHOGArrayList) {
        int myPixelData[] = imagePixelData.getImagePixels();

        if (getDisplayBoundary()) {
            int aColor = aRectBndryHOGArrayList.getColor();
            aRectBndryHOGArrayList.drawSquare(myPixelData, ySclFltrTmp.getImageWidth(), ySclFltrTmp.getImageHeight(), aColor);
        }
    }

    private void displayDigits(RectBndryGlblHOGTree aRectBndryHOGArrayList) {
        if (getDisplayDigit()) {
            //DigitPxls.drawDigit(myPixelData, anImageWidth, anImageHeight, x, y, aRectBndryHOGArrayList.getBoundaryID());            
        }
    }
    private void displayAnnotations(RectBndryGlblHOGTree aRectBndryHOGArrayList) {
        if (getIsAnnotateOn()) {
            //consider putting this code inside process
            //theTxtSrvrImageAnnotator.process(aDateTime, frameIndex, getImageWidth(), getImageHeight(), aRectBndryHOGArrayList.getBoundaryID(), aRectBndryHOGArrayList.getXMin(), aRectBndryHOGArrayList.getYMin(), aRectBndryHOGArrayList.getXMax(), aRectBndryHOGArrayList.getYMax(), "tracking analysis");
        }
    }

    private void plotData(RectBndryGlblHOGTree aRectBndryGlblHOGTree) {
        if (true) {
            return;
        }
        HOGPosition myHOGPosition = aRectBndryGlblHOGTree.getCntrHOGPosition();
        HistogramOG aHOG[][] = myHOGPosition.getHog();

        if (aHOG == null || aHOG[0][0] == null) {
            return;
        }

        //int xPos1 = (int) myHOGPosition.getX();
        //int yPos1 = (int) myHOGPosition.getY();
        
        if (aRectBndryGlblHOGTree.getYMin() > 50 && aRectBndryGlblHOGTree.getYMax() < ySclFltrTmp.getImageHeight() - 50) {

            double xVlcty = aRectBndryGlblHOGTree.computeXSum();
            double yVlcty = aRectBndryGlblHOGTree.computeYSum();

            double aRotationSum = aRectBndryGlblHOGTree.computeRotationSum3();
            double aScaleSum = aRectBndryGlblHOGTree.computeScaleSum();

            Contxt2DDataPlotter aDataPlotter = Contxt2DDataPlotter.getDataPlotter();
            aDataPlotter.updateXVel(xVlcty);
            aDataPlotter.updateYVel(yVlcty);
            aDataPlotter.updateRVel(aRotationSum);
            aDataPlotter.updateSVel(aScaleSum);            
            aDataPlotter.repaint();
        }

    }

    private void drawCentroidHG(RectBndryGlblHOGTree aRectBndryGlblHOGTree) {
        if (false) {
            return;
        }
        CentroidHGPstn myCentroidHGPstn = aRectBndryGlblHOGTree.getCentroidHGPstn();
        CentroidHG aCentroidHG = myCentroidHGPstn.getCentroidHG();

        double aMaxGrdnt = aCentroidHG.getMaxDstnce();
        double aRectWidth = aRectBndryGlblHOGTree.getXWidth();
        double aRectHeight = aRectBndryGlblHOGTree.getYHeight();
        double scaleFactor = Math.max(aRectWidth, aRectHeight) / aMaxGrdnt;
        if (myCentroidHGPstn == null || aCentroidHG == null) {
            return;
        }

        int myPixelData[] = imagePixelData.getImagePixels();
        int aWidth = ySclFltrTmp.getImageWidth();
        int aHeight = ySclFltrTmp.getImageHeight();

        int aCentroid[] = aCentroidHG.getCentroid();
        int xPos1 = (int) aCentroid[0];
        int yPos1 = (int) aCentroid[1];
        int binSize = aCentroidHG.getNumberOfBins();

        for (int i = 0; i < binSize; i++) {
            double angle = aCentroidHG.getAngleByIndex(i);
            double magnitude = scaleFactor * aCentroidHG.getDistMagByIndex(i);
            float xPos2 = xPos1 + (float) (magnitude * Math.cos(angle));
            float yPos2 = yPos1 + (float) (magnitude * Math.sin(angle));
            LineCrtr.drawLine(xPos1, yPos1, xPos2, yPos2, myPixelData, aWidth, aHeight, 0x00ff0000, 0x00ff0000);
        }
    }

    private void drawCentroidHOG(RectBndryGlblHOGTree aRectBndryGlblHOGTree) {

        CentroidHGPstn myCentroidHGPstn = aRectBndryGlblHOGTree.getCentroidHGPstn();
        CentroidHG aCentroidHG = myCentroidHGPstn.getCentroidHG();

        if (myCentroidHGPstn == null || aCentroidHG == null) {
            return;
        }
        int myPixelData[] = imagePixelData.getImagePixels();
        int aWidth = ySclFltrTmp.getImageWidth();
        int aHeight = ySclFltrTmp.getImageHeight();

        int xPos1 = (int) aRectBndryGlblHOGTree.retrieveCenterX();
        int yPos1 = (int) aRectBndryGlblHOGTree.retrieveCenterY();
        int binSize = aCentroidHG.getNumberOfBins();

        for (int i = 0; i < binSize; i++) {
            double angle = aCentroidHG.getAngleByIndex(i);
            double magnitude = aCentroidHG.getGrdntMagByIndex(i);
            float xPos2 = xPos1 + (float) (magnitude * Math.cos(angle));
            float yPos2 = yPos1 + (float) (magnitude * Math.sin(angle));

            LineCrtr.drawLine(xPos1, yPos1, xPos2, yPos2, myPixelData, aWidth, aHeight, 0x000000ff, 0x000000ff);
        }
    }

    private void drawHOG2(RectBndryGlblHOGTree aRectBndryGlblHOGTree) {

        CentroidHGPstn myCentroidHGPstn = aRectBndryGlblHOGTree.getCentroidHGPstn();
        CentroidHG aCentroidHG = myCentroidHGPstn.getCentroidHG();

        if (myCentroidHGPstn == null || aCentroidHG == null) {
            return;
        }
        int myPixelData[] = imagePixelData.getImagePixels();
        int aWidth = ySclFltrTmp.getImageWidth();
        int aHeight = ySclFltrTmp.getImageHeight();

        int xPos1 = (int) aRectBndryGlblHOGTree.retrieveCenterX();
        int yPos1 = (int) aRectBndryGlblHOGTree.retrieveCenterY();
        int binSize = aCentroidHG.getNumberOfBins();

        for (int i = 0; i < binSize; i++) {
            double angle = aCentroidHG.getAngleByIndex(i);
            double magnitude = aCentroidHG.getGrdntMagByIndex(i);
            float xPos2 = xPos1 + (float) (magnitude * Math.cos(angle));
            float yPos2 = yPos1 + (float) (magnitude * Math.sin(angle));
            //System.out.println("ClusterGlblTrackFltr : bin size ="+ binSize +", gradient = "+magnitude+", angle = "+angle+", xPos1 = "+xPos1+",yPos1 = "+yPos1+", xPos2 = "+xPos2+", yPos2 = "+yPos2);            
            LineCrtr.drawLine(xPos1, yPos1, xPos2, yPos2, myPixelData, aWidth, aHeight, 0x000000ff, 0x000000ff);
        }
    }

    public boolean getDisplayBoundary() {
        return displayBoundary;
    }

    public void setDisplayBoundary(boolean myDisplayBoundary) {
        this.displayBoundary = myDisplayBoundary;
    }

    /*
    public int getXPstn(int myIndex) {
        int x = myIndex % ySclFltrTmp.getImageWidth();
        return x;
    }

    public int getYPstn(int myIndex) {
        int y = myIndex / ySclFltrTmp.getImageWidth();
        return y;
    }*/

    public boolean isDisplayHOG() {
        return displayHOG;
    }

    public void setDisplayHOG(boolean myDisplayHOG) {
        this.displayHOG = myDisplayHOG;
    }

    public int rtrveRectBndryCnt() {
        int aLength = aTreeMap.keySet().toArray().length;
        return aLength;
    }

    public int rtrveCntrX(int myIndex) {
        Object anObject = aTreeMap.keySet().toArray()[myIndex];
        RectBndryGlblHOGTree aRectBndryGlblHOGTree = (RectBndryGlblHOGTree) aTreeMap.get(anObject);
        int centerX = aRectBndryGlblHOGTree.retrieveCenterX();
        return centerX;
    }

    public int rtrveCntrY(int myIndex) {
        Object anObject = aTreeMap.keySet().toArray()[myIndex];
        RectBndryGlblHOGTree aRectBndryGlblHOGTree = (RectBndryGlblHOGTree) aTreeMap.get(anObject);
        int centerY = aRectBndryGlblHOGTree.retrieveCenterY();
        return centerY;
    }

    public int rtrveWidth(int myIndex) {
        Object anObject = aTreeMap.keySet().toArray()[myIndex];
        RectBndryGlblHOGTree aRectBndryGlblHOGTree = (RectBndryGlblHOGTree) aTreeMap.get(anObject);
        int aWidth = aRectBndryGlblHOGTree.getXWidth();
        return aWidth;
    }

    public int rtrveHeight(int myIndex) {
        Object anObject = aTreeMap.keySet().toArray()[myIndex];
        RectBndryGlblHOGTree aRectBndryGlblHOGTree = (RectBndryGlblHOGTree) aTreeMap.get(anObject);
        int aHeight = aRectBndryGlblHOGTree.getYHeight();
        return aHeight;
    }

    public int rtrveMaxLength(int myIndex) {
        Object anObject = aTreeMap.keySet().toArray()[myIndex];
        RectBndryGlblHOGTree aRectBndryGlblHOGTree = (RectBndryGlblHOGTree) aTreeMap.get(anObject);
        int aLength = aRectBndryGlblHOGTree.getMaxLength();
        return aLength;
    }

    public void finish() {
        //displayData();
        //globalHogTreeMapPast = aTreeMap;
    }
}
