package org.cgtjr.client;

class AngleLine {

    private double theta;
    private double phi;

    AngleLine() {
    }

    AngleLine(float xPos, float yPos, float zPos) {
        initialize(0, 0, 0, xPos, yPos, zPos);
    }

    void initialize(float myX1, float myY1, float myZ1, float myX2, float myY2, float myZ2) {
        float myPhi = 0;
        double myTheta = 0;

        float x = myX2 - myX1;
        float y = myY2 - myY1;
        float z = myZ2 - myZ1;

        float myRadius = PntTool.getDistance(0, 0, 0, x, y, z);
        
        if (y == 0 && x >= 0) {
            theta = Math.PI / 2;
        } else if (y == 0 && x < 0) {
            theta = 3 * Math.PI / 2;
        } else if (y != 0 && x >= 0) {
            theta = Math.atan2(myRadius, y);
        } else if (y != 0 && x < 0) {
            theta = 2 * Math.PI - Math.atan2(myRadius, y);
        }
        if (z == 0 && x >= 0) {
            phi = Math.PI / 2;
        } else if (z == 0 && x < 0) {
            phi = 3 * Math.PI / 2;
        } else if (z != 0 && x >= 0) {
            phi = Math.atan2(x, z);
        } else if (z != 0 && x < 0) {
            phi = Math.PI + (-1 * Math.atan2(x, z));
        }
    }

    boolean isInBoundary(double x, double y, double z) {
        double myRadius = PntTool.getDistance(0, 0, 0, x, y, z);
        double myPhi = phi;
        double myTheta = theta;
        if (y == 0 && x >= 0) {
            myTheta = Math.PI / 2;
        } else if (y == 0 && x < 0) {
            myTheta = 3 * Math.PI / 2;
        } else if (y != 0 && x >= 0) {
            myTheta = Math.atan2(myRadius, y);
        } else if (y != 0 && x < 0) {
            myTheta = 2 * Math.PI - Math.atan2(myRadius, y);
        }
        if (z == 0 && x >= 0) {
            myPhi = Math.PI / 2;
        } else if (z == 0 && x < 0) {
            myPhi = 3 * Math.PI / 2;
        } else if (z != 0 && x >= 0) {
            myPhi = Math.atan2(x, z);
        } else if (z != 0 && x < 0) {
            myPhi = Math.PI + (-1 * Math.atan2(x, z));
        }
        return isOnLine(myRadius, myTheta, myPhi);
    }

    boolean isInRadiusBoundary(double myRadius) {
        boolean isInRBoundary = false;      
        double aRadius = 0;//getRadius();
        if (myRadius >= 0 && myRadius <= aRadius) {
            isInRBoundary = true;
        }
        return isInRBoundary;
    }

    boolean isInPhiBoundary(double myPhi) {
        boolean isInPhiBoundary = false;
        if ((myPhi >= phi) && (myPhi <= phi)) {
            isInPhiBoundary = true;
        }
        return isInPhiBoundary;
    }

    boolean isInThetaBoundary(double myTheta) {
        boolean isInThetaBoundary = false;        
        if ((myTheta >= theta) && (myTheta <= theta)) {
            isInThetaBoundary = true;
        }
        return isInThetaBoundary;
    }
    boolean isOnLine(double r, double t, double p) {
        boolean isInABoundary = false;
        if (isInRadiusBoundary(r) && isInPhiBoundary(p) && isInThetaBoundary(t)) {
            isInABoundary = true;
        }
        return isInABoundary;
    }
}