package org.cgtjr.client;

import com.google.gwt.canvas.dom.client.ImageData;

/**
 * @author clayton g thomas jr
 */
interface RndrrPrcssImgDta {
    void process(ImageData myImage);
    ImageData getOutputImage();
}
