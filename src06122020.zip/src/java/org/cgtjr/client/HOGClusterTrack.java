package org.cgtjr.client;

/**
 * 
 * @author cgthomasjr
 */
public class HOGClusterTrack extends ImageFilter 
{
    private YSclFltrTmp ySclFilter;
    private TmprlGrdntFltrTmp tmprlGrdntFilter;
    private GrdntFilterParserTmp grdntFilterParser;
    private CornerDetectGrdntTmp cornerDetectGrdntTmp;
    private HOGCornerDetectorTmp hogCornerDetectorTmp;
    private ClusterHOGTrackerTmp clusterHOGTrackerTmp;
    
    public HOGClusterTrack(){
        ySclFilter = new YSclFltrTmp();
        tmprlGrdntFilter = new TmprlGrdntFltrTmp(ySclFilter);
        grdntFilterParser = new GrdntFilterParserTmp(ySclFilter);
        cornerDetectGrdntTmp = new CornerDetectGrdntTmp(ySclFilter,tmprlGrdntFilter,grdntFilterParser);
        hogCornerDetectorTmp = new HOGCornerDetectorTmp(cornerDetectGrdntTmp);
        clusterHOGTrackerTmp = new ClusterHOGTrackerTmp(hogCornerDetectorTmp);
    }
    
    public void initialize(int myImageWidth, int myImageHeight) {
        ySclFilter.initialize(myImageWidth, myImageHeight);        
        tmprlGrdntFilter.initialize(myImageWidth, myImageHeight);
        grdntFilterParser.initialize(myImageWidth, myImageHeight);
        cornerDetectGrdntTmp.initialize(myImageWidth, myImageHeight);
        hogCornerDetectorTmp.initialize(myImageWidth, myImageHeight);
        clusterHOGTrackerTmp.initialize(myImageWidth, myImageHeight);
    }

    public void filter(int[] myValue, int i) {
        ySclFilter.filter(myValue);
        tmprlGrdntFilter.filter(ySclFilter.getGryVls());  
        grdntFilterParser.filter(ySclFilter.getGryVls());
        cornerDetectGrdntTmp.filter(grdntFilterParser.getGrdntMgntd());
        hogCornerDetectorTmp.filter(grdntFilterParser.getGrdntMgntd());
        clusterHOGTrackerTmp.filter(grdntFilterParser.getGrdntMgntd());
    }

    public void finish() {
    }


    public int[] getFltrdData() {
        return ySclFilter.getFltrdData(); //To change body of generated methods, choose Tools | Templates.
    }

    public YSclFltrTmp getySclFilter() {
        return ySclFilter;
    }

    public void setySclFilter(YSclFltrTmp myYSclFilter) {
        this.ySclFilter = myYSclFilter;
    }

    public TmprlGrdntFltrTmp getTmprlGrdntFilter() {
        return tmprlGrdntFilter;
    }

    public void setTmprlGrdntFilter(TmprlGrdntFltrTmp myTmprlGrdntFilter) {
        this.tmprlGrdntFilter = myTmprlGrdntFilter;
    }

    public GrdntFilterParserTmp getGrdntFilterParser() {
        return grdntFilterParser;
    }

    public void setGrdntFilterParser(GrdntFilterParserTmp myGrdntFilterParser) {
        this.grdntFilterParser = myGrdntFilterParser;
    }

    public CornerDetectGrdntTmp getCornerDetectGrdntTmp() {
        return cornerDetectGrdntTmp;
    }

    public void setCornerDetectGrdntTmp(CornerDetectGrdntTmp myCornerDetectGrdntTmp) {
        this.cornerDetectGrdntTmp = myCornerDetectGrdntTmp;
    }

    public HOGCornerDetectorTmp getHogCornerDetectorTmp() {
        return hogCornerDetectorTmp;
    }

    public void setHogCornerDetectorTmp(HOGCornerDetectorTmp myHOGCornerDetectorTmp) {
        this.hogCornerDetectorTmp = myHOGCornerDetectorTmp;
    }

    public ClusterHOGTrackerTmp getClusterHOGTrackerTmp() {
        return clusterHOGTrackerTmp;
    }

    public void setClusterHOGTrackerTmp(ClusterHOGTrackerTmp myClusterHOGTrackerTmp) {
        this.clusterHOGTrackerTmp = myClusterHOGTrackerTmp;
    }    
}