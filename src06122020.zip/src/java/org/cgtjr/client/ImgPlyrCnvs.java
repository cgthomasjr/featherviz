package org.cgtjr.client;

import com.google.gwt.canvas.client.Canvas;
import com.google.gwt.canvas.dom.client.Context2d;
import com.google.gwt.canvas.dom.client.ImageData;

import java.util.ArrayList;

/**
 * 
 * @author cgthomasjr
 */
class ImgPlyrCnvs
{
    private int xPadding;
    private int xLocation;
    private RndrrPrcssImgDta imgRndrr;
    private final ArrayList imgArryLst;

    private Context2d offScrnGrphcs;
    private ImageData anImage = null;
    private int initialX;
 
    private Canvas imgCanvas;
    
    ImgPlyrCnvs(ArrayList myArrayList) {
        //TODO: anImgArryLst should pass to process() instead of constructor
        imgArryLst = myArrayList;

        if (imgArryLst != null && imgArryLst.size() > 0) {
            xPadding = 0;
            anImage = (ImageData) imgArryLst.get(0);
             
            imgCanvas = Canvas.createIfSupported();
            offScrnGrphcs = imgCanvas.getContext2d();        
        }
    }
    void setInitialX(int myInitialX)
    {
        initialX = myInitialX;
    }
    void setOffScrnImg(Context2d myOffScrnImg) {
        offScrnGrphcs = myOffScrnImg;
    }    
    void setRndrr(RndrrPrcssImgDta myRndrr) {
        imgRndrr = myRndrr;
    }
    void paint(Context2d g) {
        g.drawImage(imgCanvas.getCanvasElement(),0,0);
    }
    void process() {
        //TODO: anImgArryLst should pass to process() instead of constructor
        int aSize = imgArryLst.size();

        xLocation = initialX;

        for (int i = 0; i < aSize; i++) {
            anImage = (ImageData) imgArryLst.get(i);
            imgRndrr.process(anImage);

            int imgWidth = anImage.getWidth();
            ImageData anImage2 = imgRndrr.getOutputImage();

            offScrnGrphcs.putImageData(anImage2, xLocation, 0);
            
            xLocation = xLocation + imgWidth + xPadding;
        }
    }
    void start() {

    }
    Canvas getImgCanvas(){
        return imgCanvas;
    }
}