/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cgtjr.client;

/**
 * The temporal gradient is the partial derivative of E (image) with respect to
 * time.  Motion gradient values are used to detect and extract moving pixels.  
 * Two consecutive images with identical pixel values within a specified window
 * have a temporal gradient of zero. 
 * @author cgthomasjr
 */

public class TmprlGrdntFltrTmp {

    private int prevImgData[];
    
    private int imgWidth;
    private int firstFrame[];
    private int prvsData1[];
    private int prvsData2[];
    
    private int frm1TmprlGrdntDiff;
    private int tmprlGrdntValue;
    private double tmprlGrdntThrshld = 25;
    private int temporalGradientValues[];
    private int aLength;
    private YSclFltrTmp ysclFltr;
    /**
     * The constructor TmprlGrdntFltrTmp requires a gray scaled image.
     * @param myYsclFltr this parameter is an instantiated class containing
     * the data for the gray scale image.
     */
    public TmprlGrdntFltrTmp(YSclFltrTmp myYsclFltr) {
        ysclFltr = myYsclFltr;
    }

    public void initialize(int myImageWidth, int myImageHeight) {
        this.intlzeTmprlGrndnt(myImageWidth, myImageHeight);
    }

    private void intlzeTmprlGrndnt(int myImageWidth, int myImageHeight) {
        aLength = myImageHeight * myImageWidth;
        imgWidth = myImageWidth;

        if (firstFrame == null) {
            firstFrame = new int[aLength];
        }
        if (prvsData1 == null) {
            prvsData1 = new int[aLength];
        }
        if (prvsData2 == null) {
            prvsData2 = new int[aLength];
            prevImgData = prvsData2;
        }
        if (temporalGradientValues == null) {
            temporalGradientValues = new int[aLength];
        }
    }
    /**
     * The function setTmprlGrdntThrshld provides the ability to set the temporal
     * gradient threshold.  Motion associated with values above this threshold 
     * @param myTmprlGrdntThrshld - this parameter is used to set the threshold 
     * value.  A negative value indicates pixel differences of zero are processed.
     * Future versions may only use integer values.
     */
    public void setTmprlGrdntThrshld(double myTmprlGrdntThrshld) {
        tmprlGrdntThrshld = myTmprlGrdntThrshld;
    }
    /**
     * The getTmprlGrdntThrshld functions returns the temporal gradient
     * threshold value.
     * @return This function returns the threshold gradient value.  
     */
    public double getTmprlGrdntThrshld() {
        return tmprlGrdntThrshld;
    }
    /**
     * The tmprlFilter function is responsible for iterating through the
     * array at a specified index to calculate the temporal gradient at 
     * each pixel.
     * @param dataValues
     * @param i 
     */
    public void tmprlFilter(int dataValues[], int i) {
        if (ysclFltr.getFrameIndex() > 0) {
            if (i > 8 * ysclFltr.getImageWidth() && i < aLength - 8 * ysclFltr.getImageWidth()) {
                cmptTmprlGrdntSSD(i);
            }
        }
        setPrevImgData(i);
    }
    
    /**
     * The tmprlFilter function is responsible for iterating through the
     * array at a specified index to calculate the temporal gradient at 
     * each pixel.
     * @param myDataValues 
     * The myDataValues parameter contains the image data.
     */
    public void tmprlFilter(int myDataValues[]) {
        //System.out.println("HOGCluseterTrack ... test -> "+6);
        int aLength = myDataValues.length;
        for (int j = 0; j < aLength; j++) {
            if (ysclFltr.getFrameIndex() > 0) {
                //System.out.println("TmprGrdntFltr: framenumber = " + ysclFltr.getFrameIndex() + ", j = " + j);
                if (j > 8 * ysclFltr.getImageWidth() && j < aLength - 8 * ysclFltr.getImageWidth()) {
                    cmptTmprlGrdntSSD(j);
                }
            }
            setPrevImgData(j);
        }
        fnshTmprlGrdnt();        
    }
    public void filter(int myDataValues[]) {
        tmprlFilter(myDataValues);
    }    
    private double cmptTmprlGrdntSSD(int myIndex) {
        double ssd = -Float.MAX_VALUE;
        int tmprlGrdntTmp[] = new int[9];

        tmprlGrdntTmp[0] = ysclFltr.getGryVls(myIndex - imgWidth - 1) - prevImgData[myIndex - imgWidth - 1];
        tmprlGrdntTmp[1] = ysclFltr.getGryVls(myIndex - imgWidth) - prevImgData[myIndex - imgWidth];
        tmprlGrdntTmp[2] = ysclFltr.getGryVls(myIndex - imgWidth + 1) - prevImgData[myIndex - imgWidth + 1];
        tmprlGrdntTmp[3] = ysclFltr.getGryVls(myIndex - 1) - prevImgData[myIndex - 1];
        tmprlGrdntTmp[4] = ysclFltr.getGryVls(myIndex) - prevImgData[myIndex];
        tmprlGrdntTmp[5] = ysclFltr.getGryVls(myIndex + 1) - prevImgData[myIndex + 1];
        tmprlGrdntTmp[6] = ysclFltr.getGryVls(myIndex + imgWidth - 1) - prevImgData[myIndex + imgWidth - 1];
        tmprlGrdntTmp[7] = ysclFltr.getGryVls(myIndex + imgWidth) - prevImgData[myIndex + imgWidth];
        tmprlGrdntTmp[8] = ysclFltr.getGryVls(myIndex + imgWidth + 1) - prevImgData[myIndex + imgWidth + 1];

        ssd = tmprlGrdntTmp[0] * tmprlGrdntTmp[0] + tmprlGrdntTmp[1] * tmprlGrdntTmp[1] + tmprlGrdntTmp[2] * tmprlGrdntTmp[2] + tmprlGrdntTmp[3] * tmprlGrdntTmp[3]
                + tmprlGrdntTmp[4] * tmprlGrdntTmp[4] + tmprlGrdntTmp[5] * tmprlGrdntTmp[5] + tmprlGrdntTmp[6] * tmprlGrdntTmp[6] + tmprlGrdntTmp[7] * tmprlGrdntTmp[7];
        tmprlGrdntValue = (int) Math.sqrt(ssd);
        temporalGradientValues[myIndex] = tmprlGrdntValue;
        
        if(tmprlGrdntValue > getTmprlGrdntThrshld()){
           ysclFltr.getImageDrawData().updatePixels(temporalGradientValues, myIndex);
        }
        return ssd;
    }
    private double cmptTmprlGrdntSSD(int myIndex, YSclFltrTmp myYSclFltr) {
        double ssd = -Float.MAX_VALUE;
        int tmprlGrdntTmp[] = new int[9];

        tmprlGrdntTmp[0] = myYSclFltr.getGryVls(myIndex - imgWidth - 1) - prevImgData[myIndex - imgWidth - 1];
        tmprlGrdntTmp[1] = myYSclFltr.getGryVls(myIndex - imgWidth) - prevImgData[myIndex - imgWidth];
        tmprlGrdntTmp[2] = myYSclFltr.getGryVls(myIndex - imgWidth + 1) - prevImgData[myIndex - imgWidth + 1];
        tmprlGrdntTmp[3] = myYSclFltr.getGryVls(myIndex - 1) - prevImgData[myIndex - 1];
        tmprlGrdntTmp[4] = myYSclFltr.getGryVls(myIndex) - prevImgData[myIndex];
        tmprlGrdntTmp[5] = myYSclFltr.getGryVls(myIndex + 1) - prevImgData[myIndex + 1];
        tmprlGrdntTmp[6] = myYSclFltr.getGryVls(myIndex + imgWidth - 1) - prevImgData[myIndex + imgWidth - 1];
        tmprlGrdntTmp[7] = myYSclFltr.getGryVls(myIndex + imgWidth) - prevImgData[myIndex + imgWidth];
        tmprlGrdntTmp[8] = myYSclFltr.getGryVls(myIndex + imgWidth + 1) - prevImgData[myIndex + imgWidth + 1];

        ssd = tmprlGrdntTmp[0] * tmprlGrdntTmp[0] + tmprlGrdntTmp[1] * tmprlGrdntTmp[1] + tmprlGrdntTmp[2] * tmprlGrdntTmp[2] + tmprlGrdntTmp[3] * tmprlGrdntTmp[3]
                + tmprlGrdntTmp[4] * tmprlGrdntTmp[4] + tmprlGrdntTmp[5] * tmprlGrdntTmp[5] + tmprlGrdntTmp[6] * tmprlGrdntTmp[6] + tmprlGrdntTmp[7] * tmprlGrdntTmp[7];
        tmprlGrdntValue = (int) Math.sqrt(ssd);
        temporalGradientValues[myIndex] = (short) tmprlGrdntValue;
        return ssd;
    }    
    public void setTemporalGradientValues(int myIndex, int myValue) {
        temporalGradientValues[myIndex] = (short) myValue;
    }
    public int getTemporalGradientValues(int myIndex) {
        return temporalGradientValues[myIndex];
    }

    public int[] getTemporalGradientValues() {
        return temporalGradientValues;
    }

    public void setTmprlGrdntValue(int myTmprlGrdntValue) {
        tmprlGrdntValue = myTmprlGrdntValue;
    }

    public int getTmprlGrdntValue() {
        return tmprlGrdntValue;
    }

    public void filter(int dataValues[], int i) {
    }
    private void setFirstFrameData(int myValues[], int i) {
        if (ysclFltr.getFrameIndex() == 3) {
            firstFrame[i] = myValues[i];
        }
    }
    public float getFrm1TmprGrdntDiff() {
        return frm1TmprlGrdntDiff;
    }
    @Deprecated
    public int cmpt1stFrmTmprlGrdnt(int myIndex) {
        return 0;
    }
    private void setPrevImgData(int i) {
        if (ysclFltr.getFrameIndex() % 2 == 0) {
            prvsData1[i] = ysclFltr.getGryVls(i);
        } else {
            prvsData2[i] = ysclFltr.getGryVls(i);
        }
    }
    private int[] getPrvsData() {
        if (ysclFltr.getFrameIndex() % 2 == 0) {
            return prvsData2;
        } else {
            return prvsData1;
        }
    }
    public void startPrsng() {
    }
    public void finish() {
        fnshTmprlGrdnt();
    }
    public void fnshTmprlGrdnt() {
        prevImgData = getPrvsData();
    }
}