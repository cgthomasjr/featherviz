package org.cgtjr.client;

import com.google.gwt.canvas.dom.client.ImageData;

class ImageRndrrImgDta implements RndrrPrcssImgDta
{
   private ImageFilter imgFilter;
   
   private FrameParserImgDta videoParser;

   private ImageData anImage ;
   private int startOffset;
   private int stopOffset;      

   ImageRndrrImgDta() 
   {
      videoParser = new ImgArryParser(imgFilter);              
   }
   ImageRndrrImgDta(ImageFilter myImageFilter) 
   {
      imgFilter = myImageFilter;
      videoParser = new ImgArryParser(imgFilter);         
   }   
   ImageRndrrImgDta(FrameParserImgDta myFrameParser) 
   {
      videoParser = myFrameParser;              
   }
   void setParser(FrameParserImgDta myParser)
   {
      videoParser = myParser;
   }
   void setImgFilter(ImageFilter myImageFilter){
       imgFilter = myImageFilter;
   }
   public void process(ImageData myImage) 
   {
      videoParser.setTopOffset(startOffset);
      videoParser.setBottomOffset(stopOffset);

      videoParser.setInputImage(myImage);

      videoParser.bgnFrames();
      videoParser.parse();
      videoParser.endFrames();
      anImage = videoParser.getOutputImage();

   }
   public ImageData getOutputImage()
   {
      return anImage;      
   }
    int getStartOffset() {
        return startOffset;
    }

    void setStartOffset(int startIndex) {
        this.startOffset = startIndex;
    }

    int getStopOffset() {
        return stopOffset;
    }

    void setStopOffset(int stopIndex) {
        this.stopOffset = stopIndex;
    }      
}