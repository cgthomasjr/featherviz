package org.cgtjr.client;
/**
 * 
 * @author cgthomasjr
 */
class HOGPosition {
    private HistogramOG hog[][];
    private int positionIndex = 0;
    private double x;
    private double y;
    private HOGPosition matchedHOGPosition;
    private int gridID;
    private Object trackBoundary;
    private boolean isConnected;
    
    HOGPosition(HistogramOG[][] hog, int positionIndex,int myWidth) {
        this.hog = hog;
        this.positionIndex = positionIndex;
        int aX = ImageTool.rtrvXPstn(positionIndex, myWidth);
        int aY = ImageTool.rtrvYPstn(positionIndex, myWidth);        
        setX(aX);
        setY(aY);
    }
    
    HOGPosition(HistogramOG[][] hog, int positionIndex) {
        this.hog = hog;
        this.positionIndex = positionIndex;
    }
    HOGPosition(double myX,double myY) {
        this.hog = new HistogramOG[1][1]; 
        this.hog[0][0] = new HistogramOG();         
        setX(myX);
        setY(myY);                
    }    

    HOGPosition() {
        this.hog = new HistogramOG[1][1]; 
        this.hog[0][0] = new HistogramOG();           
    }    
    
    Object getTrackBoundary() {
        return trackBoundary;
    }

    void setTrackBoundary(Object myTrackBoundary) {
        this.trackBoundary = myTrackBoundary;
    }
    
    int getGridID() {
        return gridID;
    }
    void setGridID(int myGridID) {
        this.gridID = myGridID;
    }    
    void connectHOGMatch(HOGPosition myHOGPosition){
        matchedHOGPosition = myHOGPosition;
        matchedHOGPosition.setIsConnected(true);
     
    }
    HOGPosition rtrveHOGMatch(){
        return matchedHOGPosition;
    }
    double getX() {
        return x;
    }
    void setX(double aX) {
        this.x = aX;
    }
    double getY() {
        return y;
    }
    void setY(double aY) {
        this.y = aY;
    }
    HistogramOG[][] getHog() {
        return hog;
    }
    void setHog(HistogramOG[][] hog) {
        this.hog = hog;
    }

    int getPositionIndex() {
        return positionIndex;
    }

    void setPositionIndex(int positionIndex) {
        this.positionIndex = positionIndex;
    }
    static double computePixelDistance(HOGPosition myHOGPosition1, HOGPosition myHOGPosition2,int myImageWidth) {
        int anImageWidth = myImageWidth;
        int anIndex1 = myHOGPosition1.getPositionIndex();
        int anIndex2 = myHOGPosition2.getPositionIndex();
        int x1 = ImageTool.rtrvXPstn(anIndex1, anImageWidth);
        int y1 = ImageTool.rtrvYPstn(anIndex1, anImageWidth);
        int x2 = ImageTool.rtrvXPstn(anIndex2, anImageWidth);
        int y2 = ImageTool.rtrvYPstn(anIndex2, anImageWidth);
        double aDistance = PntTool.getDistance(x1, y1, x2, y2);
        return aDistance;
    }
    void addHOG(HOGPosition myHOGPosition){
        HistogramOG aHistogramOG[][] = myHOGPosition.getHog();
        //if(hog == null || hog[0][0] == null) return;   
        hog[0][0].addHistogramOG(aHistogramOG[0][0]);
    }
    void updateCentroid(HOGPosition myHOGPosition){
        HistogramOG aHistogramOG[][] = myHOGPosition.getHog();
        //if(hog == null || hog[0][0] == null) return;   
        hog[0][0].addHistogramOG(aHistogramOG[0][0]);
    }    

    boolean getIsConnected() {
        return isConnected;
    }

    void setIsConnected(boolean myIsConnected) {
        this.isConnected = myIsConnected;
    }

    public String toString() {
        return "HOGPositioin{" + "hog=" + hog + ", positionIndex=" + positionIndex + '}';
    }    
}