package org.cgtjr.client;

/**
 * An image is represented by a rectangular pixel array from samples of a 
 * continuous function E(x, y) of image intensities.  The class GrdntFilterParserTmp
 * is responsible for performing the spatial derivatives.  Several block sizes 
 * are used including 1x1, 3x3, 9x9, and 27x27.
 * @author cgthomasjr
 */
public class GrdntFilterParserTmp
{

    private int rgbColors[];
    private int rgbValues[];

    private int grdntVrtcl[];
    private int grdntHrzntl[];
    private int grdntHVTtl;

    private int grdntMgntd[];

    private int grdntMgntdSqrdTtl;

    private int grdntMgntdTtl;
    private int grayValuesTtl;
    private int grayValuesSqrdTtl;
    private double ornttnAngle[];
    private int imageWidth;
    private int imageHeight;
    private int count;
    private int krnlHrzntl[][];
    private int krnlVrtcl[][];
    private int imageLength;

    private GrdntKrnl aGenericHVKrnl;// = new GrdntKrnl();
    private YSclFltrTmp ySclFilter;
    
    /**
     * The constructor GrdntFilterParserTmp accepts the gray scaled
     * image object as a parameter.
     * @param mySclFltr 
     */
    public GrdntFilterParserTmp(YSclFltrTmp mySclFltr) {
        ySclFilter = mySclFltr;
    }
    public void initialize(int myWidth, int myHeight) {
        this.intlzeGrdntFilter(myWidth, myHeight);
    }
    private void intlzeGrdntFilter(int myWidth, int myHeight) {
        int aHeight = myHeight;
        int aWidth = myWidth;

        imageLength = aWidth * aHeight;
        imageWidth = aWidth;
        imageHeight = aHeight;
        
        if(aGenericHVKrnl == null){
           aGenericHVKrnl = new GrdntKrnl();
           krnlHrzntl = aGenericHVKrnl.getHrzntlKrnl();
           krnlVrtcl = aGenericHVKrnl.getVrtclKrnl();
        }
        
        grdntVrtcl = new int[aWidth * aHeight];
        grdntHrzntl = new int[aWidth * aHeight];
        grdntMgntd = new int[aWidth * aHeight];
        ornttnAngle = new double[aWidth * aHeight];
           
        imageLength = aWidth * aHeight;
        imageWidth = aWidth;
        imageHeight = aHeight;   
    }

    public void filter1x1(int myIntlValues[], int i) {
        grdntFilter(myIntlValues, i);
    }

    public void filter3x3(int myIntlValues[], int i) {
        grdntFilter3x3(myIntlValues, i);
    }
    public void filter(int myIntlValues[], int i) {

    }
    public void gradientGryFilter(int myIntlValues[], int i){
        grdntFilter(myIntlValues, i);
    }    
    public void filter(int myIntlValues[]) {
        grdntFilter(myIntlValues);
    }
    public void grdntFilter(int myIntlValues[]) {
        int aLength = myIntlValues.length;
        for(int j=0;j<aLength;j++){
            grdntFilter(myIntlValues,j);
        }
    }
    /**
     * The grdntFilter function computes the spatial gradient.  The x and y
     * directional gradients are computed.  The orientation of the gradient
     * is also computed in this function.
     * @param myIntlValues
     * @param i 
     */
    public void grdntFilter(int myIntlValues[], int i) {        
        try {                         
            grdntHrzntl[i] =
                    + ySclFilter.getGryVls(i - 1) * krnlHrzntl[1][0]
                    + ySclFilter.getGryVls(i) * krnlHrzntl[1][1]
                    + ySclFilter.getGryVls(i + 1) * krnlHrzntl[1][2];
            grdntVrtcl[i] =
                    + ySclFilter.getGryVls(i - imageWidth) * krnlVrtcl[0][1]
                    + ySclFilter.getGryVls(i) * krnlVrtcl[1][1]
                    + ySclFilter.getGryVls(i + imageWidth) * krnlVrtcl[2][1];

            grdntMgntd[i] =
                    (int) Math.sqrt(Math.abs((grdntHrzntl[i] * grdntHrzntl[i]) + (grdntVrtcl[i] * grdntVrtcl[i])));

            ornttnAngle[i] = Math.atan2(grdntVrtcl[i],grdntHrzntl[i]);
            //TODO: this code requires modification
            if(grdntMgntd[i] > 10){
               ySclFilter.getImageDrawData().updatePixels(grdntMgntd, i);
            }
        } catch (ArrayIndexOutOfBoundsException aiob) {
        }        
        count++;
    }

    /**
     * The grdntFilter function computes the spatial gradient.  The x and y
     * directional gradients are computed.  The orientation of the gradient
     * is also computed in this function. 
     * @param myIntlValues
     * @param i
     * @param imageWidth
     * @param imageHeight 
     */
    private void grdntGryFilter(int myIntlValues[], int i, int imageWidth, int imageHeight) {

        try {
            grdntHrzntl[i] =
                    + grdntGryFilter(myIntlValues, i - 1) * krnlHrzntl[1][0]
                    + grdntGryFilter(myIntlValues, i) * krnlHrzntl[1][1]
                    + grdntGryFilter(myIntlValues, i + 1) * krnlHrzntl[1][2];

            grdntVrtcl[i] =
                    +grdntGryFilter(myIntlValues, i - imageWidth) * krnlVrtcl[0][1]
                    + grdntGryFilter(myIntlValues, i) * krnlVrtcl[1][1]
                    + grdntGryFilter(myIntlValues, i + imageWidth) * krnlVrtcl[2][1];
 
            grdntMgntd[i] =
                    (int) Math.sqrt(Math.abs((grdntHrzntl[i] * grdntHrzntl[i]) + (grdntVrtcl[i] * grdntVrtcl[i])));
            ornttnAngle[i] = Math.atan2(grdntHrzntl[i], grdntVrtcl[i]);
        } catch (ArrayIndexOutOfBoundsException aiob) {
        }
        count++;
    }
    public int grdntGryFilter(int myIntlValues[], int i) {
        return ySclFilter.gryFltr1x1(myIntlValues, i);
    }
    public void grdntGryFltr3x3(int myGrayValues[], int anIndex) {

        int aWidth = ySclFilter.getImageWidth();
        int aHeight = ySclFilter.getImageHeight();
        
        grdntGryFilter(myGrayValues, anIndex - aWidth - 1,aWidth,aHeight);
        grdntGryFilter(myGrayValues, anIndex - aWidth,aWidth,aHeight);
        grdntGryFilter(myGrayValues, anIndex - aWidth + 1,aWidth,aHeight);
        grdntGryFilter(myGrayValues, anIndex - 1,aWidth,aHeight);
        grdntGryFilter(myGrayValues, anIndex,aWidth,aHeight);
        grdntGryFilter(myGrayValues, anIndex + 1,aWidth,aHeight);
        grdntGryFilter(myGrayValues, anIndex + aWidth - 1,aWidth,aHeight);
        grdntGryFilter(myGrayValues, anIndex + aWidth,aWidth,aHeight);
        grdntGryFilter(myGrayValues, anIndex + aWidth + 1,aWidth,aHeight);
    }
    public void grdntFilter3x3(int myGrayValues[], int anIndex) {
        int aWidth = ySclFilter.getImageWidth();

        grdntFilter(myGrayValues, anIndex - aWidth - 1);
        grdntFilter(myGrayValues, anIndex - aWidth);
        grdntFilter(myGrayValues, anIndex - aWidth + 1);
        grdntFilter(myGrayValues, anIndex - 1);
        grdntFilter(myGrayValues, anIndex);
        grdntFilter(myGrayValues, anIndex + 1);
        grdntFilter(myGrayValues, anIndex + aWidth - 1);
        grdntFilter(myGrayValues, anIndex + aWidth);
        grdntFilter(myGrayValues, anIndex + aWidth + 1);
    }

    public void grdntFilter9x9(int myGrayValues[], int anIndex) {
        int aWidthx3 = 3 * ySclFilter.getImageWidth();
        grdntFilter3x3(myGrayValues, anIndex - aWidthx3 - 3);
        grdntFilter3x3(myGrayValues, anIndex - aWidthx3);
        grdntFilter3x3(myGrayValues, anIndex - aWidthx3 + 3);
        grdntFilter3x3(myGrayValues, anIndex - 3);
        grdntFilter3x3(myGrayValues, anIndex);
        grdntFilter3x3(myGrayValues, anIndex + 3);
        grdntFilter3x3(myGrayValues, anIndex + aWidthx3 - 3);
        grdntFilter3x3(myGrayValues, anIndex + aWidthx3);
        grdntFilter3x3(myGrayValues, anIndex + aWidthx3 + 3);
    }

    public void grdntFilter18x18(int myGrayValues[], int anIndex) {

        grdntFilter9x9(myGrayValues, anIndex);
        grdntFilter9x9(myGrayValues, anIndex);
        grdntFilter9x9(myGrayValues, anIndex);
        grdntFilter9x9(myGrayValues, anIndex);
    }

    public void grdntFilter27x27(int myGrayValues[], int anIndex) {
        int aWidthx3 = 9 * ySclFilter.getImageWidth();
        grdntFilter9x9(myGrayValues, anIndex - aWidthx3 - 9);
        grdntFilter9x9(myGrayValues, anIndex - aWidthx3);
        grdntFilter9x9(myGrayValues, anIndex - aWidthx3 + 9);
        grdntFilter9x9(myGrayValues, anIndex - 9);
        grdntFilter9x9(myGrayValues, anIndex);
        grdntFilter9x9(myGrayValues, anIndex + 9);
        grdntFilter9x9(myGrayValues, anIndex + aWidthx3 - 9);
        grdntFilter9x9(myGrayValues, anIndex + aWidthx3);
        grdntFilter9x9(myGrayValues, anIndex + aWidthx3 + 9);
    }
    public double rtrvExpcttn() {
        double aValue = Math.sqrt(grdntMgntdSqrdTtl / count - (grdntMgntdTtl * grdntMgntdTtl) / (count * count));
        return aValue;
    }

    public double rtrvExpctIllmnt() {
        double aValue1 = 6 * Math.PI * Math.PI * grayValuesSqrdTtl / count;
        double aValue2 = 48 * (grayValuesTtl * grayValuesTtl) / (count * count);
        double aValue3 = Math.sqrt(aValue1 - aValue2);
        return aValue3;
    }

    public double rtrvGrdntMgntdAvg() {
        double aValue = grdntMgntdTtl / count;
        return aValue;
    }

    public double rtrvSlant() {
        double aValue1 = grayValuesTtl / count;
        double aValue2 = rtrvExpctIllmnt();
        double cosSigma = 4 * aValue1 / aValue2;
        double sigma = Math.acos(cosSigma);
        return sigma;
    }

    public int[] getGrdnt() {
        return rgbValues;
    }
    /**
     * The function getGrdntMgntd return an array of gradient magnitudes.
     * @return 
     */
    public int[] getGrdntMgntd() {
        return grdntMgntd;
    }

    public int getGrdntMgntd(int myIndex) {
        if (!ySclFilter.isInBounds3x3(myIndex)) {
            return 0;
        }
        return grdntMgntd[myIndex];
    }

    public double getGrdntMgntdAvg3x3(int myIndex) {
        double anAvg = getGrdntMgntdTtl3x3(myIndex) / 9;
        return anAvg;
    }

    public double getGrdntMgntdAvg9x9(int myIndex) {
        double anAvg = getGrdntMgntdTtl9x9(myIndex) / 81;
        return anAvg;
    }

    public int getGrdntMgntdTtl3x3(int myIndex) {       
        int aWidth = ySclFilter.getImageWidth();
        int total = 0;
        total += getGrdntMgntd(myIndex - aWidth - 1);
        total += getGrdntMgntd(myIndex - aWidth);
        total += getGrdntMgntd(myIndex - aWidth + 1);
        total += getGrdntMgntd(myIndex - 1);
        total += getGrdntMgntd(myIndex);
        total += getGrdntMgntd(myIndex + 1);
        total += getGrdntMgntd(myIndex + aWidth - 1);
        total += getGrdntMgntd(myIndex + aWidth);
        total += getGrdntMgntd(myIndex + aWidth + 1);
        return total;
    }

    public int getGrdntMgntdTtl9x9(int myIndex) {
        int aWidth = 3 * ySclFilter.getImageWidth();
        int total = 0;
        total += getGrdntMgntdTtl3x3(myIndex - aWidth - 3);
        total += getGrdntMgntdTtl3x3(myIndex - aWidth);
        total += getGrdntMgntdTtl3x3(myIndex - aWidth + 3);
        total += getGrdntMgntdTtl3x3(myIndex - 3);
        total += getGrdntMgntdTtl3x3(myIndex);
        total += getGrdntMgntdTtl3x3(myIndex + 3);
        total += getGrdntMgntdTtl3x3(myIndex + aWidth - 3);
        total += getGrdntMgntdTtl3x3(myIndex + aWidth);
        total += getGrdntMgntdTtl3x3(myIndex + aWidth + 3);
        return total;
    }

    public void setGrdntMgntd(int myGrdntMgntd[]) {
        grdntMgntd = myGrdntMgntd;
    }
    public int[] getGrdntHrzntl() {
        return grdntHrzntl;
    }
    public int getGrdntHrzntl(int myIndex) {
        return grdntHrzntl[myIndex];
    }
    public int[] getGrdntVrtcl() {
        return grdntVrtcl;
    }
    public int getGrdntVrtcl(int myIndex) {
        return grdntVrtcl[myIndex];
    }
    public int getGrdntHVTtl() {
        return grdntHVTtl;
    }
    public double getOrntnAngle(int myIndex) {
        return ornttnAngle[myIndex];
    }
    public double[] getOrntnAngle() {
        return ornttnAngle;
    }
    public void finish() {

    }
}