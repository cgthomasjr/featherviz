package org.cgtjr.client;

import com.google.gwt.canvas.dom.client.CanvasPixelArray;
import com.google.gwt.canvas.dom.client.ImageData;
import com.google.gwt.user.client.ui.Image;


class UgotImage
{
    private Image theBufferedImage;

    UgotImage() {
    }

    UgotImage(Image anImage) {
        theBufferedImage = anImage;
    }

    static Image createImage(String anImageName) {
        Image anImage1 = null;
        return anImage1;
    }

    static Image createBufferedImage(String anImageName) {
        Image anImage1 = null;
        return createBufferedImage(anImage1);
    }
    static Image createImage(Image anImage1) throws NullPointerException {
        Image aBufferedImage = new Image();
        return aBufferedImage;
    }

    static Image createBufferedImage(Image anImage1) {
        Image aBufferedImage = new Image();
        return aBufferedImage;
    }

    static UgotImage createUgotImage(Image anImage) throws NullPointerException {
        return null;//return new UgotImage(createImage(anImage));
    }

    static UgotImage createUgotImage(Image image, int x, int y, int width, int height, int transform) {
        return null;//return new UgotImage(createImage(image,x,y,width,height,transform));
    }

    int getWidth() {
        return theBufferedImage.getWidth();
    }

    int getHeight() {
        return theBufferedImage.getHeight();
    }

    void getRGB(int[] rgbData, int offset, int scanlength, int x, int y, int width, int height) {

    }

    static void handlepixels(ImageData img, int x, int y, int w, int h, int[] pixels) {
        CanvasPixelArray data = img.getData();

        int limit = data.getLength();
        int count = 0;
        for (int i = 0; i < limit; i=i+4) {
            int aRed = data.get(i);
            int aGreen = data.get(i+1);
            int aBlue = data.get(i+2);
            int aTrnsprncy = data.get(i+3);
            pixels[count] = ColorSpectra.convertRGBToRGB(aRed,aGreen,aBlue);
            ++count;
        }
    }

    void getRGB(int x, int y) {
    }

    static Image createRGBImage(int[] rgb, int width, int height, boolean alphaProcess) {
        Image aBufferedImage = new Image();
        return aBufferedImage;
    }
    static ImageData createImageData(int[] dataArray, int width, int height, ImageData myDataImage) {
        CanvasPixelArray aCanvasPixelArray = myDataImage.getData();
        int aLength = aCanvasPixelArray.getLength();
        int limit = dataArray.length;
        
        int aCount = 0;

        for (int i = 0; i < aLength; i=i+4) {

            int aColor = dataArray[aCount];
            int aRed = ColorSpectra.rtrvRed(aColor);
            int aGreen = ColorSpectra.rtrvGreen(aColor);
            int aBlue = ColorSpectra.rtrvBlue(aColor);
            aCanvasPixelArray.set(i, aRed);
            aCanvasPixelArray.set(i+1, aGreen);
            aCanvasPixelArray.set(i+2, aBlue);
            aCanvasPixelArray.set(i+3, aCanvasPixelArray.get(i+3));
            aCount++;
        }
        return myDataImage;
    }

    Image getTheImage() {
        return theBufferedImage;
    }

    void setTheImage(Image anImage) {
        theBufferedImage = anImage;
    }

    boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
        return true;
    }
}
