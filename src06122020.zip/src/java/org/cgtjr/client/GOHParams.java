package org.cgtjr.client;

/**
 *
 * @author cgthomasjr
 */
public class GOHParams {

    private static int egnThrshld          = 1981;
    private static int tmprlGrdntThrshld   = -1;
    private static int clstrDstnce         = 95;
    private static int objctDstnce         = 600;
    private static double hogDsplyScleFctr    = 100;

    public static double getHogDsplyScleFctr() {
        return hogDsplyScleFctr;
    }

    public static void setHogDsplyScleFctr(double myHogDsplyScleFctr) {
        GOHParams.hogDsplyScleFctr = myHogDsplyScleFctr;
    }
    
    private static boolean dsplyCrnrs      = true;
    private static boolean dsplyGrdnts     = true;
    private static boolean dsplyArrws      = true;
    private static boolean dsplyBndry      = true;
    private static boolean dsplyTrnsltn    = true;   
    private static boolean dsplyHOG        = true;      
    
    private static int startOffSet;

    public static int getEgnThrshld() {
        return egnThrshld;
    }

    public static void setEgnThrshld(int myEgnThrshld) {
        egnThrshld = myEgnThrshld;
    }

    public static int getTmprlGrdntThrshld() {
        return tmprlGrdntThrshld;
    }

    public static void setTmprlGrdntThrshld(int myTmprlGrdntThrshld) {
        tmprlGrdntThrshld = myTmprlGrdntThrshld;
    }

    public static int getClstrDstnce() {
        return clstrDstnce;
    }

    public static void setClstrDstnce(int myClstrDstnce) {
        clstrDstnce = myClstrDstnce;
    }

    public static int getObjctDstnce() {
        return objctDstnce;
    }

    public static void setObjctDstnce(int myObjctDstnce) {
        objctDstnce = myObjctDstnce;
    }

    public static boolean isDsplyCrnrs() {
        return dsplyCrnrs;
    }

    public static void setDsplyCrnrs(boolean myDsplyCrnrs) {
        dsplyCrnrs = myDsplyCrnrs;
    }

    public static boolean isDsplyGrdnts() {
        return dsplyGrdnts;
    }

    public static void setDsplyGrdnts(boolean myDsplyGrdnts) {
        dsplyGrdnts = myDsplyGrdnts;
    }

    public static boolean isDsplyArrws() {
        return dsplyArrws;
    }

    public static void setDsplyArrws(boolean myDsplyArrws) {
        dsplyArrws = myDsplyArrws;
    }

    public static boolean isDsplyBndry() {
        return dsplyBndry;
    }

    public static void setDsplyBndry(boolean myDsplyBndry) {
        dsplyBndry = myDsplyBndry;
    }

    public static boolean isDsplyTrnsltn() {
        return dsplyTrnsltn;
    }

    public static void setDsplyTrnsltn(boolean myDsplyTrnsltn) {
        dsplyTrnsltn = myDsplyTrnsltn;
    }

    public static boolean isDsplyHOG() {
        return dsplyHOG;
    }

    public static void setDsplyHOG(boolean myDsplyHOG) {
        dsplyHOG = myDsplyHOG;
    }

    public static int getStartOffSet() {
        return startOffSet;
    }

    public static void setStartOffSet(int myStartOffSet) {
        startOffSet = myStartOffSet;
    }        
    
}